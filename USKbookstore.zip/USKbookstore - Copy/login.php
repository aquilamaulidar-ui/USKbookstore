<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'config/database.php';


/*
|--------------------------------------------------------------------------
| JIKA SUDAH LOGIN
|--------------------------------------------------------------------------
*/

if (isset($_SESSION['user_id'])) {

    if (
        isset($_SESSION['user_role']) &&
        $_SESSION['user_role'] === 'admin'
    ) {
        header('Location: admin/index.php');
    } else {
        header('Location: index.php');
    }

    exit;
}


/*
|--------------------------------------------------------------------------
| PROSES LOGIN
|--------------------------------------------------------------------------
*/

$error = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';


    if ($email === '' || $password === '') {

        $error = 'Email dan password wajib diisi.';

    } else {

        $userQuery = $pdo->prepare(
            "SELECT
                id,
                name,
                email,
                password,
                role
            FROM users
            WHERE email = ?
            LIMIT 1"
        );

        $userQuery->execute([$email]);

        $user = $userQuery->fetch();


        if (
            $user &&
            password_verify($password, $user['password'])
        ) {

            session_regenerate_id(true);


            /*
            |--------------------------------------------------------------------------
            | SIMPAN DATA USER KE SESSION
            |--------------------------------------------------------------------------
            */

            $_SESSION['user_id'] = (int) $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];

            $_SESSION['user_role'] =
                $user['role'] ?? 'user';


            /*
            |--------------------------------------------------------------------------
            | REDIRECT BERDASARKAN ROLE
            |--------------------------------------------------------------------------
            */

            if ($_SESSION['user_role'] === 'admin') {

                header('Location: admin/index.php');

            } else {

                header('Location: index.php');

            }

            exit;
        }


        $error = 'Email atau password salah.';
    }
}


$pageTitle = 'Login - BookStore';

require_once 'partials/header.php';

?>

<section class="auth-section">

    <div class="auth-card">

        <h1>Sign In</h1>

        <p class="auth-description">
            Masuk ke akun BookStore milikmu.
        </p>

        <?php if ($error !== ''): ?>
            <div class="alert alert-error">
                <?= htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <div class="form-group">
                <label for="email">Email</label>

                <input
                    type="email"
                    id="email"
                    name="email"
                    value="<?= htmlspecialchars($_POST['email'] ?? ''); ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="password">Password</label>

                <input
                    type="password"
                    id="password"
                    name="password"
                    required
                >
            </div>

            <button type="submit" class="submit-button">
                Login
            </button>

        </form>

        <p class="auth-link">
            Belum mempunyai akun?
            <a href="register.php">Daftar</a>
        </p>

    </div>

</section>

<?php require_once 'partials/footer.php'; ?>