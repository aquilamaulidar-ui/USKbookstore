<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config/database.php';

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = (int) $_SESSION['user_id'];
    $orderId = (int) ($_POST['order_id'] ?? 0);

    if ($orderId > 0) {
        // Pastikan pesanan benar-benar milik user yang sedang login dan statusnya sedang 'Dikirim'
        $stmt = $pdo->prepare("UPDATE orders SET status = 'Selesai' WHERE id = ? AND user_id = ? AND status = 'Dikirim'");
        $stmt->execute([$orderId, $userId]);
    }

    header("Location: order_detail.php?id=" . $orderId);
    exit;
} else {
    header('Location: index.php');
    exit;
}