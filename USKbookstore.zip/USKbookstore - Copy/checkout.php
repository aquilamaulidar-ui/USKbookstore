<?php
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];

/*
|--------------------------------------------------------------------------
| Ambil Data Profil User untuk Autofill (Nomor HP & Alamat)
|--------------------------------------------------------------------------
*/
$userQuery = $pdo->prepare("SELECT name, phone, address FROM users WHERE id = ?");
$userQuery->execute([$userId]);
$currentUser = $userQuery->fetch();

/*
|--------------------------------------------------------------------------
| Cek Mode: Beli Langsung atau Checkout dari Cart
|--------------------------------------------------------------------------
*/
$isDirectCheckout = false;
$cartItems = [];

if (isset($_GET['book_id'])) {
    // MODE BELI LANGSUNG
    $isDirectCheckout = true;
    $bookId = (int) $_GET['book_id'];

    $bookQuery = $pdo->prepare(
        "SELECT id AS book_id, title, author, price, cover, stock FROM books WHERE id = ?"
    );
    $bookQuery->execute([$bookId]);
    $book = $bookQuery->fetch();

    if ($book && $book['stock'] > 0) {
        $book['quantity'] = 1; // Default beli 1
        $book['cart_id'] = 0;
        $cartItems[] = $book;
    }
} else {
    // MODE CHECKOUT CART
    $cartQuery = $pdo->prepare(
        "SELECT cart.id AS cart_id, cart.quantity, books.id AS book_id, books.title, books.author, books.price, books.cover, books.stock
        FROM cart INNER JOIN books ON books.id = cart.book_id
        WHERE cart.user_id = ? ORDER BY cart.id DESC"
    );
    $cartQuery->execute([$userId]);
    $cartItems = $cartQuery->fetchAll();
}

if (count($cartItems) === 0) {
    header('Location: index.php');
    exit;
}

$total = 0;
$totalQuantity = 0;

foreach ($cartItems as $item) {
    $total += $item['price'] * $item['quantity'];
    $totalQuantity += $item['quantity'];
}

$shippingCost = 15000; // Ongkir flat Rp 15.000
$grandTotal = $total + $shippingCost;

if (empty($_SESSION['checkout_token'])) {
    $_SESSION['checkout_token'] = bin2hex(random_bytes(32));
}

$pageTitle = 'Checkout - BookStore';
require_once 'partials/header.php';
?>

<section class="container section">

    <div class="page-title">
        <span class="section-label">Selesaikan pesanan</span>
        <h1>Checkout</h1>
    </div>

    <div class="checkout-layout">

        <div class="checkout-form-card">
            <h2>Data Pembeli</h2>

            <?php if (isset($_SESSION['checkout_error'])): ?>
                <div class="alert alert-error">
                    <?= htmlspecialchars($_SESSION['checkout_error']); ?>
                </div>
                <?php unset($_SESSION['checkout_error']); ?>
            <?php endif; ?>

            <form action="process_checkout.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="checkout_token" value="<?= htmlspecialchars($_SESSION['checkout_token']); ?>">

                <!-- Input Hidden untuk Beli Langsung -->
                <?php if ($isDirectCheckout): ?>
                    <input type="hidden" name="direct_book_id" value="<?= $cartItems[0]['book_id']; ?>">
                    <input type="hidden" id="form_quantity" name="direct_quantity" value="1">
                <?php endif; ?>

                <div class="form-group">
                    <label for="customer_name">Nama penerima</label>
                    <input type="text" id="customer_name" name="customer_name" value="<?= htmlspecialchars($currentUser['name'] ?? $_SESSION['user_name'] ?? ''); ?>" required>
                </div>

                <div class="form-group">
                    <label for="phone">Nomor telepon / WhatsApp</label>
                    <input type="tel" id="phone" name="phone" value="<?= htmlspecialchars($currentUser['phone'] ?? ''); ?>" placeholder="Contoh: 081234567890" required>
                </div>

                <div class="form-group">
                    <label for="address">Alamat lengkap</label>
                    <textarea id="address" name="address" rows="5" placeholder="Masukkan alamat lengkap penerima" required><?= htmlspecialchars($currentUser['address'] ?? ''); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="payment_method">Metode pembayaran</label>
                    <select id="payment_method" name="payment_method" required>
                        <option value="">Pilih metode pembayaran</option>
                        <option value="Transfer Bank">Transfer Bank</option>
                        <option value="E-Wallet">E-Wallet</option>
                    </select>
                </div>

                <div id="payment-info" class="payment-info" style="display:none; margin-bottom: 15px; padding: 15px; background: #f7f6ff; border-radius: 8px;">
                    <h3>Informasi Pembayaran</h3>
                    <div id="bank-info" style="display:none;">
                        <strong>Transfer Bank</strong>
                        <p>Bank BCA<br>No. Rekening: 1234567890<br>a.n BookStore</p>
                    </div>
                    <div id="ewallet-info" style="display:none;">
                        <strong>E-Wallet</strong>
                        <p>DANA / OVO / GOPAY / SHOPEEPAY<br>No. HP: 085693258376<br>a.n BookStore</p>
                </div>
                </div>

                <div class="form-group" id="proof-group" style="display:none;">
                    <label for="payment_proof">Bukti Pembayaran</label>
                    <input type="file" id="payment_proof" name="payment_proof" accept="image/*">
                </div>

                <div style="display: flex; gap: 10px; margin-top: 20px;">
                    <button type="submit" class="submit-button" style="flex: 1;">Buat Pesanan</button>
                    <a href="index.php" class="secondary-success-button" style="flex: 1; text-align: center; line-height: 40px; text-decoration: none; border: 1px solid #d7d5e3; border-radius: 7px; color: #666; font-weight: bold;">Batal</a>
                </div>
            </form>
        </div>

        <aside class="checkout-summary">
            <h2>Ringkasan Pesanan</h2>
            <div class="checkout-book-list">
                <?php foreach ($cartItems as $item): ?>
                    <div class="checkout-book-item" style="display: grid; grid-template-columns: 65px 1fr; gap: 13px; margin-bottom: 15px;">
                        <img src="<?= htmlspecialchars($item['cover']); ?>" alt="Cover" style="width: 100%; border-radius: 5px;">
                        <div>
                            <h3 style="font-size: 14px; margin-bottom: 5px;"><?= htmlspecialchars($item['title']); ?></h3>
                            
                            <?php if ($isDirectCheckout): ?>
                                <!-- Tombol Atur Jumlah -->
                                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 5px;">
                                    <button type="button" onclick="updateQty(-1, <?= $item['price']; ?>, <?= $item['stock']; ?>)" style="width: 25px; height: 25px; border-radius: 4px; border: 1px solid #ccc; cursor: pointer; background: #fff;">-</button>
                                    <span id="display_qty" style="font-weight: bold;">1</span>
                                    <button type="button" onclick="updateQty(1, <?= $item['price']; ?>, <?= $item['stock']; ?>)" style="width: 25px; height: 25px; border-radius: 4px; border: 1px solid #ccc; cursor: pointer; background: #fff;">+</button>
                                </div>
                            <?php else: ?>
                                <p style="font-size: 13px; color: #666; margin-bottom: 5px;"><?= (int) $item['quantity']; ?> × Rp <?= number_format($item['price'], 0, ',', '.'); ?></p>
                            <?php endif; ?>

                            <strong id="display_subtotal" style="display: block; font-size: 14px;">
                                Rp <?= number_format($item['price'] * $item['quantity'], 0, ',', '.'); ?>
                            </strong>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="summary-row" style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                <span>Jumlah buku</span>
                <strong id="display_total_books"><?= $totalQuantity; ?></strong>
            </div>

            <div class="summary-row" style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                <span>Ongkos Kirim</span>
                <strong>Rp 15.000</strong>
            </div>

            <div class="summary-row summary-total" style="display: flex; justify-content: space-between; padding-top: 15px; border-top: 1px solid #e1e1e5; font-size: 18px;">
                <span>Total pembayaran</span>
                <strong id="display_total_price">Rp <?= number_format($grandTotal, 0, ',', '.'); ?></strong>
            </div>
        </aside>

    </div>
</section>

<script>
// Logika ganti metode pembayaran & validasi bukti bayar
const paymentMethod = document.getElementById('payment_method');
const paymentInfo = document.getElementById('payment-info');
const bankInfo = document.getElementById('bank-info');
const ewalletInfo = document.getElementById('ewallet-info');
const proofGroup = document.getElementById('proof-group');
const paymentProofInput = document.getElementById('payment_proof');

paymentMethod.addEventListener('change', function(){
    paymentInfo.style.display = "none";
    bankInfo.style.display = "none";
    ewalletInfo.style.display = "none";
    if(proofGroup) proofGroup.style.display = "none";
    if(paymentProofInput) paymentProofInput.removeAttribute('required');

    if(this.value === "Transfer Bank"){
        paymentInfo.style.display = "block";
        bankInfo.style.display = "block";
        if(proofGroup) proofGroup.style.display = "block";
        if(paymentProofInput) paymentProofInput.setAttribute('required', 'required');
    }
    else if(this.value === "E-Wallet"){
        paymentInfo.style.display = "block";
        ewalletInfo.style.display = "block";
        if(proofGroup) proofGroup.style.display = "block";
        if(paymentProofInput) paymentProofInput.setAttribute('required', 'required');
    }
});

// Logika tombol plus minus & kalkulasi total + ongkir
let currentQty = 1;
const fixedShippingCost = 15000;

function updateQty(change, price, maxStock) {
    let newQty = currentQty + change;
    
    if (newQty >= 1 && newQty <= maxStock) {
        currentQty = newQty;
        document.getElementById('display_qty').innerText = currentQty;
        
        let hiddenInput = document.getElementById('form_quantity');
        if (hiddenInput) hiddenInput.value = currentQty; 
        
        let subtotalBuku = currentQty * price;
        let totalKeseluruhan = subtotalBuku + fixedShippingCost;
        
        let formattedSubtotal = 'Rp ' + subtotalBuku.toLocaleString('id-ID');
        let formattedTotal = 'Rp ' + totalKeseluruhan.toLocaleString('id-ID');
        
        document.getElementById('display_subtotal').innerText = formattedSubtotal;
        document.getElementById('display_total_price').innerText = formattedTotal;
        document.getElementById('display_total_books').innerText = currentQty;
    } else if (newQty > maxStock) {
        alert('Stok buku hanya tersisa: ' + maxStock);
    }
}
</script>

<?php require_once 'partials/footer.php'; ?>