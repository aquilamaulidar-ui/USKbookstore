<?php

require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: cart.php');
    exit;
}

$cartId = (int) ($_POST['cart_id'] ?? 0);
$quantity = (int) ($_POST['quantity'] ?? 1);
$userId = (int) $_SESSION['user_id'];

if ($quantity < 1) {
    $quantity = 1;
}

$updateQuery = $pdo->prepare(
    "UPDATE cart
     SET quantity = ?
     WHERE id = ?
     AND user_id = ?"
);

$updateQuery->execute([
    $quantity,
    $cartId,
    $userId
]);

header('Location: cart.php');
exit;