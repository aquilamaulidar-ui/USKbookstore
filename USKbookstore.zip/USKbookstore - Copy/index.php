<?php

require_once 'config/database.php';

$pageTitle = 'BookStore - Home';

$categoryId = isset($_GET['category']) ? (int) $_GET['category'] : 0;
$keyword = trim($_GET['search'] ?? '');

$categoriesQuery = $pdo->query("SELECT * FROM categories ORDER BY id ASC");
$categories = $categoriesQuery->fetchAll();

$selectedCategoryName = '';
foreach ($categories as $category) {
    if ((int) $category['id'] === $categoryId) {
        $selectedCategoryName = $category['name'];
        break;
    }
}

if ($categoryId > 0 || $keyword !== '') {
    $conditions = [];
    $parameters = [];

    if ($categoryId > 0) {
        $conditions[] = 'books.category_id = :category_id';
        $parameters['category_id'] = $categoryId;
    }

    if ($keyword !== '') {
        $conditions[] = '(books.title LIKE :keyword OR books.author LIKE :keyword)';
        $parameters['keyword'] = '%' . $keyword . '%';
    }

    $booksSql = "
        SELECT
            books.*,
            categories.name AS category_name,
            COALESCE(SUM(order_items.quantity), 0) AS total_sold
        FROM books
        LEFT JOIN categories ON categories.id = books.category_id
        LEFT JOIN order_items ON books.id = order_items.book_id
        WHERE " . implode(' AND ', $conditions) . "
        GROUP BY books.id
        ORDER BY books.id DESC
    ";

    $booksQuery = $pdo->prepare($booksSql);
    $booksQuery->execute($parameters);
} else {
    // Menampilkan 3 buku rekomendasi Best Seller di Home
    $booksQuery = $pdo->query(
        "SELECT
            books.*,
            categories.name AS category_name,
            COALESCE(SUM(order_items.quantity), 0) AS total_sold
        FROM books
        LEFT JOIN categories ON categories.id = books.category_id
        LEFT JOIN order_items ON books.id = order_items.book_id
        GROUP BY books.id
        ORDER BY total_sold DESC, books.id DESC
        LIMIT 3"
    );
}

$books = $booksQuery->fetchAll();

$sectionTitle = ($categoryId > 0 || $keyword !== '') ? 'Hasil Pencarian / Kategori' : 'Rekomendasi Buku Terlaris (Best Seller)';

require_once 'partials/header.php';
?>

<!-- HERO -->
<section class="hero container">
    <div class="hero-content">
        <h1>Diskon Spesial Untuk Pengguna Baru!!</h1>
        <p>Untuk semua pilihan buku</p>
        <a href="#book-list" class="primary-button" style="color: #ffffff !important; background: #918bed !important;">
            Belanja Sekarang
        </a>
    </div>
    <div class="hero-image">
        <img src="assets/images/banner-books.jpeg" alt="Tumpukan buku">
    </div>
</section>

<!-- DAFTAR BUKU -->
<section class="container section" id="book-list">
    <div class="section-header book-section-header">
        <div>
            <h2><?= htmlspecialchars($sectionTitle); ?></h2>
        </div>
        <div class="section-header-right">
            <?php if ($categoryId > 0): ?>
                <a href="index.php#categories" class="reset-filter">Lihat Kategori Lain</a>
            <?php endif; ?>

            <form action="index.php" method="GET" class="book-search">
                <?php if ($categoryId > 0): ?>
                    <input type="hidden" name="category" value="<?= $categoryId; ?>">
                <?php endif; ?>
                <input type="search" name="search" value="<?= htmlspecialchars($keyword); ?>" placeholder="Cari buku..." autocomplete="off">
                <button type="submit" class="book-search-button" aria-label="Cari buku">
                    <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                        <circle cx="11" cy="11" r="7"></circle>
                        <path d="M20 20L16.5 16.5"></path>
                    </svg>
                </button>
            </form>
        </div>
    </div>

    <div class="book-grid">
        <?php if (count($books) > 0): ?>
            <?php foreach ($books as $book): ?>
                <article class="book-card">
                    <div class="book-cover">
                        <a href="detail.php?id=<?= (int) $book['id']; ?>">
                            <img src="<?= htmlspecialchars($book['cover']); ?>" alt="<?= htmlspecialchars($book['title']); ?>" onerror="this.src='assets/images/no-image.jpeg';">
                        </a>
                    </div>
                    <div class="book-information">
                        <span class="book-category"><?= htmlspecialchars($book['category_name'] ?? 'Tanpa kategori'); ?></span>
                        <h3>
                            <a href="detail.php?id=<?= (int) $book['id']; ?>" style="text-decoration: none; color: inherit;">
                                <?= htmlspecialchars($book['title']); ?>
                            </a>
                        </h3>   
                        <p class="book-author"><?= htmlspecialchars($book['author']); ?></p>
                        
                        <!-- Rating & Total Terjual -->
                        <div style="display: flex; justify-content: space-between; align-items: center; margin: 8px 0; font-size: 13px;">
                            <span style="color: #f39c12; font-weight: bold;">⭐ <?= number_format($book['rating'] ?? 5.0, 1); ?></span>
                            <span style="color: #746cdf; font-weight: bold;">🔥 Terjual: <?= (int) $book['total_sold']; ?></span>
                        </div>

                        <p class="book-stock">Stok: <?= (int) $book['stock']; ?></p>
                        <p class="book-price">Rp <?= number_format($book['price'], 0, ',', '.'); ?></p>

                        <div class="book-actions" style="display: flex; gap: 8px; width: 100%; align-items: center; margin-top: 10px;">
                            <?php if ((int) $book['stock'] > 0): ?>
                                <a href="checkout.php?book_id=<?= (int) $book['id']; ?>" class="order-button" style="flex: 1; text-align: center; line-height: 20px;">Pesan</a>
                                <form action="add_cart.php" method="POST" style="margin: 0;">
                                    <input type="hidden" name="book_id" value="<?= (int) $book['id']; ?>">
                                    <button type="submit" class="favorite-button" style="display: grid; place-items: center;" title="Tambah ke Keranjang">🛒</button>
                                </form>
                            <?php else: ?>
                                <button type="button" class="out-of-stock-button" style="flex: 1;" disabled>Stok Habis</button>
                            <?php endif; ?>
                            <form action="add_favorite.php" method="POST" style="margin: 0;">
                                <input type="hidden" name="book_id" value="<?= (int) $book['id']; ?>">
                                <button type="submit" class="favorite-button" title="Tambahkan ke favorite">♡</button>
                            </form>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">
                <h2>Buku tidak ditemukan</h2>
                <p>Tidak ada buku yang sesuai dengan pencarianmu.</p>
                <br>
                <a href="index.php#book-list" class="primary-button">Tampilkan Semua</a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Tombol Lihat Semua Buku -->
    <?php if ($categoryId === 0 && $keyword === ''): ?>
        <div style="text-align: center; margin-top: 30px;">
            <a href="catalog.php" style="display: inline-block; padding: 12px 25px; background: #746cdf; color: #fff; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 14px;">
                📚 Lihat Semua Buku & Rating Lengkap →
            </a>
        </div>
    <?php endif; ?>
</section>

<!-- KATEGORI -->
<section class="container section" id="categories">
    <div class="section-header">
        <div>
            <span class="section-label">Jelajahi buku</span>
            <h2>Kategori</h2>
            <p class="section-description">Pilih kategori untuk melihat seluruh bukunya.</p>
        </div>
    </div>
    <div class="category-grid">
        <?php foreach ($categories as $category): ?>
            <a href="index.php?category=<?= (int) $category['id']; ?>#book-list" class="category-card">
                <h3><?= strtoupper(htmlspecialchars($category['name'])); ?></h3>
                <div class="category-image-wrapper">
                    <img src="<?= htmlspecialchars($category['image']); ?>" alt="<?= htmlspecialchars($category['name']); ?>">
                </div>
            </a>
        <?php endforeach; ?>
    </div>
</section>

<?php require_once 'partials/footer.php'; ?>