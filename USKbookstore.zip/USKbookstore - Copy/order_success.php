<?php

require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$orderId = (int) ($_GET['id'] ?? 0);

if ($orderId <= 0) {
    header('Location: index.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Mengambil data pesanan
|--------------------------------------------------------------------------
*/

$orderQuery = $pdo->prepare(
    "SELECT *
    FROM orders
    WHERE id = ?
    AND user_id = ?
    LIMIT 1"
);

$orderQuery->execute([
    $orderId,
    $userId
]);

$order = $orderQuery->fetch();

if (!$order) {
    header('Location: index.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Mengambil detail buku dalam pesanan
|--------------------------------------------------------------------------
*/

$itemQuery = $pdo->prepare(
    "SELECT *
    FROM order_items
    WHERE order_id = ?
    ORDER BY id ASC"
);

$itemQuery->execute([$orderId]);

$orderItems = $itemQuery->fetchAll();

$pageTitle = 'Pesanan Berhasil - BookStore';

require_once 'partials/header.php';
?>

<section class="container section">

    <div class="success-card">

        <div class="success-icon">
            ✓
        </div>

        <h1>Pesanan Berhasil Dibuat</h1>

        <p class="success-description">
            Terima kasih. Pesananmu telah tersimpan di sistem.
        </p>

        <div class="order-information">

            <div class="order-info-row">
                <span>Kode pesanan</span>

                <strong>
                    <?= htmlspecialchars($order['order_code']); ?>
                </strong>
            </div>

            <div class="order-info-row">
                <span>Nama penerima</span>

                <strong>
                    <?= htmlspecialchars($order['customer_name']); ?>
                </strong>
            </div>

            <div class="order-info-row">
                <span>Nomor telepon</span>

                <strong>
                    <?= htmlspecialchars($order['phone']); ?>
                </strong>
            </div>

            <div class="order-info-row">
                <span>Metode pembayaran</span>

                <strong>
                    <?= htmlspecialchars($order['payment_method']); ?>
                </strong>
            </div>

            <div class="order-info-row">
                <span>Status</span>

                <strong>
                    <?= htmlspecialchars($order['status']); ?>
                </strong>
            </div>

            <div class="order-address">
                <span>Alamat pengiriman</span>

                <p>
                    <?= nl2br(
                        htmlspecialchars($order['address'])
                    ); ?>
                </p>
            </div>

        </div>

        <div class="success-order-items">

            <h2>Detail Buku</h2>

            <?php foreach ($orderItems as $item): ?>

                <div class="success-order-item">

                    <div>
                        <strong>
                            <?= htmlspecialchars($item['book_title']); ?>
                        </strong>

                        <p>
                            <?= (int) $item['quantity']; ?>
                            × Rp
                            <?= number_format(
                                $item['price'],
                                0,
                                ',',
                                '.'
                            ); ?>
                        </p>
                    </div>

                    <strong>
                        Rp <?= number_format(
                            $item['subtotal'],
                            0,
                            ',',
                            '.'
                        ); ?>
                    </strong>

                </div>

            <?php endforeach; ?>

        </div>

        <div class="success-total">

            <span>Total pembayaran</span>

            <strong>
                Rp <?= number_format(
                    $order['total_amount'],
                    0,
                    ',',
                    '.'
                ); ?>
            </strong>

        </div>

        <div class="success-actions">

    <a
        href="order_detail.php?id=<?= (int) $order['id']; ?>"
        class="submit-button success-button"
    >
        Lihat Detail Pesanan
    </a>

    <a href="index.php" class="secondary-success-button">
        Kembali Belanja
    </a>

</div>
    </div>

</section>

<?php require_once 'partials/footer.php'; ?>