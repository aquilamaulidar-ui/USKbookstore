<?php

require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$bookId = (int) ($_POST['book_id'] ?? 0);
$userId = (int) $_SESSION['user_id'];

if ($bookId <= 0) {
    header('Location: index.php');
    exit;
}

$insertFavorite = $pdo->prepare(
    "INSERT IGNORE INTO favorites (user_id, book_id)
     VALUES (?, ?)"
);

$insertFavorite->execute([
    $userId,
    $bookId
]);

header('Location: favorite.php');
exit;