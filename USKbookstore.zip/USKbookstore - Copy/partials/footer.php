</main>

<footer class="footer">
    <div class="container">
        <p>&copy; <?= date('Y'); ?> BookStore, Semua hak dilindungi.</p>
</div>
</footer>

</body>
</html>