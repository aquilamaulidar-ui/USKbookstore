<?php

require_once 'config/database.php';

$currentPage = basename($_SERVER['PHP_SELF']);
$pageTitle = $pageTitle ?? 'BookStore';

$cartCount = 0;

if (isset($_SESSION['user_id'])) {

    $cartQuery = $pdo->prepare(
        "SELECT SUM(quantity) AS total
         FROM cart
         WHERE user_id = ?"
    );

    $cartQuery->execute([
        $_SESSION['user_id']
    ]);

    $cartCount = $cartQuery->fetch()['total'] ?? 0;
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title><?= htmlspecialchars($pageTitle); ?></title>

    <link rel="stylesheet" href="assets/css/style2.css">
</head>

<body>

<header class="top-header">
    <div class="navbar container">

        <a href="index.php" class="brand">
            <span class="brand-icon">📖</span>

            <span>
                <strong>BookStore</strong>
                <small>Temukan bukumu</small>
            </span>
        </a>

        <nav class="main-menu">
    <a
        href="index.php"
        class="<?= $currentPage === 'index.php' ? 'active' : ''; ?>"
    >
        Home
    </a>

    <a
    href="cart.php"
    class="<?= $currentPage === 'cart.php' ? 'active' : ''; ?>"
>
   Cart
<?php if ($cartCount > 0): ?>
    <span class="cart-badge">
        <?= $cartCount; ?>
    </span>
<?php endif; ?>
    </a>

    <a
        href="favorite.php"
        class="<?= $currentPage === 'favorite.php' ? 'active' : ''; ?>"
    >
        Favorite
    </a>

    <?php if (isset($_SESSION['user_id'])): ?>
        <a
            href="orders.php"
            class="<?=
                in_array(
                    $currentPage,
                    ['orders.php', 'order_detail.php'],
                    true
                )
                    ? 'active'
                    : '';
            ?>"
        >
            Pesanan
        </a>
    <?php endif; ?>

        <a
        href="contact.php"
        class="<?= $currentPage === 'contact.php' ? 'active' : ''; ?>"
    >
        Contact
    </a>

    <a
        href="about.php"
        class="<?= $currentPage === 'about.php' ? 'active' : ''; ?>"
    >
        About Us
    </a>

</nav>

<div class="auth-menu" style="display: flex; align-items: center; justify-content: flex-end; gap: 15px;">
    <?php if (isset($_SESSION['user_id'])): ?>

        <a href="profile.php" style="text-decoration: none; color: inherit; font-weight: bold; display: inline-flex; align-items: center; gap: 5px;">
    <?= htmlspecialchars($_SESSION['user_name'] ?? 'Akun'); ?>
</a>


        <?php if (
            isset($_SESSION['user_role']) &&
            $_SESSION['user_role'] === 'admin'
        ): ?>

            <a
                href="admin/index.php"
                class="sign-button"
            >
                Admin Panel
            </a>

        <?php endif; ?>


        <a
            href="logout.php"
            class="sign-button"
        >
            Logout
        </a>

    <?php else: ?>

        <a
            href="login.php"
            class="sign-button"
        >
            Sign In
        </a>

    <?php endif; ?>

</div>

    </div>
</header>

<main></main>