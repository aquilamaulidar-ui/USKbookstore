<?php

require_once 'config/database.php';

/*
|--------------------------------------------------------------------------
| Pastikan pengguna sudah login
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];

/*
|--------------------------------------------------------------------------
| Mengambil semua pesanan milik pengguna
|--------------------------------------------------------------------------
*/

$orderQuery = $pdo->prepare(
    "SELECT
        orders.id,
        orders.order_code,
        orders.customer_name,
        orders.payment_method,
        orders.total_amount,
        orders.status,
        orders.created_at,
        COALESCE(SUM(order_items.quantity), 0) AS total_books
    FROM orders
    LEFT JOIN order_items
        ON order_items.order_id = orders.id
    WHERE orders.user_id = ?
    GROUP BY
        orders.id,
        orders.order_code,
        orders.customer_name,
        orders.payment_method,
        orders.total_amount,
        orders.status,
        orders.created_at
    ORDER BY orders.created_at DESC"
);

$orderQuery->execute([$userId]);

$orders = $orderQuery->fetchAll();

$pageTitle = 'Riwayat Pesanan - BookStore';

require_once 'partials/header.php';
?>

<section class="container section">

    <div class="page-title">
        <span class="section-label">Transaksi bukumu</span>
        <h1>Riwayat Pesanan</h1>

        <p class="page-description">
            Lihat semua pesanan yang sudah kamu buat.
        </p>
    </div>

    <?php if (count($orders) > 0): ?>

        <div class="order-history-list">

            <?php foreach ($orders as $order): ?>

                <?php
                $statusClass = 'status-processing';

                if ($order['status'] === 'Pembayaran Berhasil') {
                    $statusClass = 'status-paid';
                } elseif ($order['status'] === 'Selesai') {
                    $statusClass = 'status-completed';
                } elseif ($order['status'] === 'Dibatalkan') {
                    $statusClass = 'status-cancelled';
                }
                ?>

                <article class="order-history-card">

                    <div class="order-history-header">

                        <div>
                            <span class="order-date">
                                <?= date(
                                    'd M Y, H:i',
                                    strtotime($order['created_at'])
                                ); ?>
                            </span>

                            <h2>
                                <?= htmlspecialchars(
                                    $order['order_code']
                                ); ?>
                            </h2>
                        </div>

                        <span
                            class="order-status <?= $statusClass; ?>"
                        >
                            <?= htmlspecialchars($order['status']); ?>
                        </span>

                    </div>

                    <div class="order-history-content">

                        <div class="order-history-information">

                            <div class="history-info-item">
                                <span>Nama penerima</span>

                                <strong>
                                    <?= htmlspecialchars(
                                        $order['customer_name']
                                    ); ?>
                                </strong>
                            </div>

                            <div class="history-info-item">
                                <span>Jumlah buku</span>

                                <strong>
                                    <?= (int) $order['total_books']; ?>
                                </strong>
                            </div>

                            <div class="history-info-item">
                                <span>Pembayaran</span>

                                <strong>
                                    <?= htmlspecialchars(
                                        $order['payment_method']
                                    ); ?>
                                </strong>
                            </div>

                        </div>

                        <div class="order-history-total">

                            <span>Total pesanan</span>

                            <strong>
                                Rp <?= number_format(
                                    $order['total_amount'],
                                    0,
                                    ',',
                                    '.'
                                ); ?>
                            </strong>

                            <a
                                href="order_detail.php?id=<?= (int) $order['id']; ?>"
                                class="detail-order-button"
                            >
                                Lihat Detail
                            </a>

                        </div>

                    </div>

                </article>

            <?php endforeach; ?>

        </div>

    <?php else: ?>

        <div class="empty-state">

            <h2>Belum ada pesanan</h2>

            <p>
                Pesanan yang sudah kamu checkout akan muncul di sini.
            </p>

            <br>

            <a href="index.php" class="primary-button">
                Mulai Belanja
            </a>

        </div>

    <?php endif; ?>

</section>

<?php require_once 'partials/footer.php'; ?>