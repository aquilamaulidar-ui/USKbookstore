<?php

require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: cart.php');
    exit;
}

$cartId = (int) ($_POST['cart_id'] ?? 0);
$userId = (int) $_SESSION['user_id'];

$deleteQuery = $pdo->prepare(
    "DELETE FROM cart
     WHERE id = ?
     AND user_id = ?"
);

$deleteQuery->execute([
    $cartId,
    $userId
]);

header('Location: cart.php');
exit;