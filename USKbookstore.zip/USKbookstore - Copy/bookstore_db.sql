-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 10, 2026 at 02:49 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookstore_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `title` varchar(150) NOT NULL,
  `author` varchar(100) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `cover` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `category_id`, `title`, `author`, `price`, `stock`, `cover`, `description`, `created_at`) VALUES
(1, 4, 'Sisi Tergelap Surga', 'Brian Khrisna', 90000.00, 13, 'assets/images/books/sisi-tergelap-surga.jpg', 'Novel yang mengangkat kehidupan dan sisi tersembunyi manusia.', '2026-08-05 04:14:48'),
(2, 1, 'Malioboro at Midnight', 'Skysphire', 138000.00, 9, 'assets/images/books/malioboro-at-midnight.jpg', 'Kisah romansa dengan latar suasana Malioboro pada malam hari.', '2026-08-05 04:14:48'),
(3, 4, 'Laut Bercerita', 'Leila S. Chudori', 135000.00, 10, 'assets/images/books/laut-bercerita.jpg', 'Novel tentang perjuangan, kehilangan, dan sejarah Indonesia.', '2026-08-05 04:14:48'),
(4, 1, 'Dilan 1990', 'Pidi Baiq', 89000.00, 20, 'assets/images/books/romance/dilan-1990.jfif', 'Kisah cinta remaja antara Dilan dan Milea dengan latar Kota Bandung.', '2026-08-05 06:20:05'),
(5, 1, 'Dilan 1991', 'Pidi Baiq', 92000.00, 18, 'assets/images/books/romance/dilan-1991.jpg', 'Kelanjutan perjalanan hubungan Dilan dan Milea yang semakin penuh tantangan.', '2026-08-05 06:20:05'),
(6, 1, 'Milea: Suara dari Dilan', 'Pidi Baiq', 95000.00, 17, 'assets/images/books/romance/milea-suara-dari-dilan.jpg', 'Kisah Dilan dan Milea yang diceritakan kembali dari sudut pandang Dilan.', '2026-08-05 06:20:05'),
(7, 1, 'Mariposa', 'Luluk HF', 99000.00, 20, 'assets/images/books/romance/mariposa.jpg', 'Kisah seorang gadis yang berusaha mendapatkan hati laki-laki yang sulit didekati.', '2026-08-05 06:20:05'),
(8, 1, 'Geez dan Ann', 'Rintik Sedu', 88000.00, 16, 'assets/images/books/romance/geez-dan-ann.jpg', 'Cerita cinta tentang pertemuan, jarak, perpisahan, dan kenangan.', '2026-08-05 06:20:05'),
(9, 1, 'Antares', 'Rweinda', 105000.00, 19, 'assets/images/books/romance/antares.jpg', 'Kisah cinta remaja yang berkembang di tengah kehidupan sebuah geng motor.', '2026-08-05 06:20:05'),
(10, 1, 'Matt and Mou', 'Wulanfadi', 85000.00, 14, 'assets/images/books/romance/matt-and-mou.jpg', 'Cerita tentang persahabatan sejak kecil yang perlahan berubah menjadi cinta.', '2026-08-05 06:20:05'),
(11, 1, 'Galaksi', 'Poppi Pertiwi', 99000.00, 18, 'assets/images/books/romance/galaksi.jfif', 'Kisah romansa remaja antara pemimpin geng sekolah dan anggota paskibra.', '2026-08-05 06:20:05'),
(12, 1, 'Critical Eleven', 'Ika Natassa', 115000.00, 13, 'assets/images/books/romance/critical-eleven.jpg', 'Kisah pasangan yang menghadapi konflik besar dalam kehidupan pernikahan mereka.', '2026-08-05 06:20:05'),
(13, 2, 'Harry Potter and the Philosopher\'s Stone', 'J.K. Rowling', 135000.00, 20, 'assets/images/books/fantasi/harry-potter-1.jpg', 'Petualangan pertama Harry Potter ketika memasuki sekolah sihir Hogwarts.', '2026-08-05 06:20:45'),
(14, 2, 'Harry Potter and the Chamber of Secrets', 'J.K. Rowling', 145000.00, 18, 'assets/images/books/fantasi/harry-potter-2.jpg', 'Harry Potter kembali ke Hogwarts dan menghadapi misteri kamar rahasia.', '2026-08-05 06:20:45'),
(15, 2, 'The Hobbit', 'J.R.R. Tolkien', 125000.00, 16, 'assets/images/books/fantasi/the-hobbit.jpg', 'Petualangan Bilbo Baggins bersama para kurcaci untuk merebut kembali kerajaan mereka.', '2026-08-05 06:20:45'),
(16, 2, 'The Fellowship of the Ring', 'J.R.R. Tolkien', 155000.00, 15, 'assets/images/books/fantasi/fellowship-of-the-ring.jpeg', 'Perjalanan Frodo dan para sahabatnya untuk membawa cincin menuju Mordor.', '2026-08-05 06:20:45'),
(19, 2, 'The School for Good and Evil', 'Soman Chainani', 130000.00, 15, 'assets/images/books/fantasi/school-for-good-and-evil.jpeg', 'Dua sahabat dibawa ke sekolah tempat para pahlawan dan penjahat dongeng dilatih.', '2026-08-05 06:20:45'),
(20, 2, 'Bumi', 'Tere Liye', 105000.00, 20, 'assets/images/books/fantasi/bumi.jpg', 'Petualangan Raib dalam dunia paralel yang dipenuhi kekuatan luar biasa.', '2026-08-05 06:20:45'),
(21, 2, 'Bulan', 'Tere Liye', 108000.00, 18, 'assets/images/books/fantasi/bulan.jpg', 'Raib dan sahabatnya melanjutkan perjalanan menuju klan lain di dunia paralel.', '2026-08-05 06:20:45'),
(22, 2, 'Matahari', 'Tere Liye', 110000.00, 16, 'assets/images/books/fantasi/matahari.jpeg', 'Petualangan baru Raib, Seli, dan Ali dalam menemukan rahasia dunia paralel.', '2026-08-05 06:20:45'),
(27, 2, 'The Lion, the Witch and the Wardrobe', 'C.S. Lewis', 110000.00, 17, 'assets/images/books/fantasi/lion-witch-wardrobe.jpeg', 'Empat bersaudara memasuki dunia Narnia melalui sebuah lemari ajaib.', '2026-08-05 06:21:25'),
(28, 2, 'Percy Jackson and the Lightning Thief', 'Rick Riordan', 125000.00, 17, 'assets/images/books/fantasi/percy-jackson-lightning-thief.jpeg', 'Percy mengetahui bahwa dirinya adalah keturunan dewa Yunani dan menjalani misi berbahaya.', '2026-08-05 06:21:25'),
(33, 3, 'Atomic Habits', 'James Clear', 115000.00, 25, 'assets/images/books/motivation/atomic-habits.jpg', 'Panduan membangun kebiasaan baik melalui perubahan kecil yang dilakukan secara konsisten.', '2026-08-05 06:21:50'),
(34, 3, 'The 7 Habits of Highly Effective People', 'Stephen R. Covey', 145000.00, 18, 'assets/images/books/motivation/seven-habits.jpg', 'Pembahasan tujuh kebiasaan yang membantu meningkatkan efektivitas pribadi dan profesional.', '2026-08-05 06:21:50'),
(35, 3, 'The Psychology of Money', 'Morgan Housel', 110000.00, 22, 'assets/images/books/motivation/psychology-of-money.png', 'Pembahasan mengenai hubungan perilaku manusia dengan keputusan keuangan.', '2026-08-05 06:21:50'),
(36, 3, 'Think and Grow Rich', 'Napoleon Hill', 95000.00, 17, 'assets/images/books/motivation/think-and-grow-rich.jpg', 'Prinsip membangun pola pikir, tujuan, dan kebiasaan untuk mencapai keberhasilan.', '2026-08-05 06:21:50'),
(37, 3, 'The Power of Habit', 'Charles Duhigg', 125000.00, 16, 'assets/images/books/motivation/power-of-habit.jpg', 'Penjelasan mengenai cara kebiasaan terbentuk dan bagaimana cara mengubahnya.', '2026-08-05 06:21:50'),
(38, 3, 'Filosofi Teras', 'Henry Manampiring', 105000.00, 23, 'assets/images/books/motivation/filosofi-teras.jpg', 'Pengenalan filsafat Stoisisme untuk menghadapi masalah dan emosi dalam kehidupan sehari-hari.', '2026-08-05 06:21:50'),
(39, 3, 'Nanti Kita Cerita tentang Hari Ini', 'Marchella FP', 98000.00, 20, 'assets/images/books/motivation/nkcthi.jpg', 'Kumpulan pesan sederhana mengenai kehidupan, kegagalan, keluarga, dan penerimaan diri.', '2026-08-05 06:21:50'),
(40, 3, 'Berani Tidak Disukai', 'Ichiro Kishimi dan Fumitake Koga', 120000.00, 19, 'assets/images/books/motivation/berani-tidak-disukai.jpg', 'Percakapan filosofis mengenai keberanian menjalani hidup tanpa bergantung pada penilaian orang lain.', '2026-08-05 06:21:50'),
(41, 3, 'Ikigai', 'Hector Garcia dan Francesc Miralles', 105000.00, 18, 'assets/images/books/motivation/ikigai.jpg', 'Pembahasan mengenai cara menemukan tujuan, kebahagiaan, dan makna dalam kehidupan.', '2026-08-05 06:21:50'),
(42, 3, 'The Subtle Art of Not Giving a F*ck', 'Mark Manson', 115000.00, 19, 'assets/images/books/motivation/subtle-art.jpg', 'Pendekatan realistis untuk menentukan hal-hal yang benar-benar layak diperhatikan.', '2026-08-05 06:21:50'),
(43, 4, 'Pulang', 'Leila S. Chudori', 125000.00, 17, 'assets/images/books/adult-fiction/pulang.jpg', 'Kisah keluarga, politik, identitas, dan kerinduan orang-orang yang hidup jauh dari tanah air.', '2026-08-05 06:22:05'),
(44, 4, 'Cantik Itu Luka', 'Eka Kurniawan', 135000.00, 16, 'assets/images/books/adult-fiction/cantik-itu-luka.jpg', 'Novel yang memadukan sejarah, tragedi keluarga, kekerasan, dan realisme magis.', '2026-08-05 06:22:05'),
(45, 4, 'Seperti Dendam, Rindu Harus Dibayar Tuntas', 'Eka Kurniawan', 115000.00, 15, 'assets/images/books/adult-fiction/seperti-dendam.jpg', 'Kisah kehidupan seorang laki-laki yang dipenuhi kekerasan, cinta, dan persoalan masa lalu.', '2026-08-05 06:22:05'),
(46, 4, 'Saman', 'Ayu Utami', 105000.00, 18, 'assets/images/books/adult-fiction/saman.jpg', 'Novel mengenai persahabatan, kebebasan, politik, dan perubahan sosial.', '2026-08-05 06:22:05'),
(47, 4, 'Ronggeng Dukuh Paruk', 'Ahmad Tohari', 110000.00, 17, 'assets/images/books/adult-fiction/ronggeng-dukuh-paruk.jpg', 'Kisah kehidupan seorang ronggeng dan masyarakat sebuah desa kecil di Jawa.', '2026-08-05 06:22:05'),
(48, 4, 'Bumi Manusia', 'Pramoedya Ananta Toer', 130000.00, 22, 'assets/images/books/adult-fiction/bumi-manusia.jpg', 'Kisah Minke dalam menghadapi ketidakadilan pada masa kolonial.', '2026-08-05 06:22:05'),
(49, 4, 'Gadis Kretek', 'Ratih Kumala', 115000.00, 19, 'assets/images/books/adult-fiction/gadis-kretek.jpg', 'Cerita keluarga, cinta, dan persaingan bisnis kretek lintas generasi.', '2026-08-05 06:22:05'),
(50, 4, 'Amba', 'Laksmi Pamuntjak', 145000.00, 13, 'assets/images/books/adult-fiction/amba.jpg', 'Kisah cinta dan kehilangan dengan latar peristiwa politik Indonesia.', '2026-08-05 06:22:05'),
(51, 5, 'Into the Wild', 'Jon Krakauer', 120000.00, 16, 'assets/images/books/adventure/into-the-wild.jpg', 'Kisah perjalanan seorang pemuda yang meninggalkan kehidupan modern untuk menjelajahi alam liar.', '2026-08-05 06:22:29'),
(52, 5, 'Life of Pi', 'Yann Martel', 125000.00, 18, 'assets/images/books/adventure/life-of-pi.jpg', 'Petualangan seorang anak yang bertahan hidup di laut bersama seekor harimau.', '2026-08-05 06:22:29'),
(53, 5, 'Treasure Island', 'Robert Louis Stevenson', 95000.00, 20, 'assets/images/books/adventure/treasure-island.jpg', 'Petualangan mencari harta karun yang melibatkan bajak laut dan sebuah peta rahasia.', '2026-08-05 06:22:29'),
(54, 5, 'The Call of the Wild', 'Jack London', 90000.00, 17, 'assets/images/books/adventure/call-of-the-wild.jpg', 'Perjalanan seekor anjing yang harus bertahan hidup di kerasnya wilayah utara.', '2026-08-05 06:22:29'),
(55, 5, 'Around the World in Eighty Days', 'Jules Verne', 98000.00, 15, 'assets/images/books/adventure/around-the-world.jpg', 'Perjalanan keliling dunia dalam delapan puluh hari yang dipenuhi tantangan.', '2026-08-05 06:22:29'),
(56, 5, 'Journey to the Center of the Earth', 'Jules Verne', 105000.00, 18, 'assets/images/books/adventure/journey-center-earth.jpg', 'Ekspedisi menuju bagian terdalam bumi melalui jalur yang penuh misteri.', '2026-08-05 06:22:29'),
(57, 5, 'The Alchemist', 'Paulo Coelho', 110000.00, 20, 'assets/images/books/adventure/the-alchemist.jpg', 'Perjalanan seorang penggembala dalam mengejar impian dan menemukan makna kehidupan.', '2026-08-05 06:22:29'),
(58, 5, 'The Old Man and the Sea', 'Ernest Hemingway', 95000.00, 16, 'assets/images/books/adventure/old-man-and-the-sea.jpg', 'Perjuangan seorang nelayan tua melawan ikan besar di tengah lautan.', '2026-08-05 06:22:29'),
(59, 5, 'Robinson Crusoe', 'Daniel Defoe', 90000.00, 17, 'assets/images/books/adventure/robinson-crusoe.jpg', 'Kisah seorang pelaut yang harus bertahan hidup sendirian di sebuah pulau.', '2026-08-05 06:22:29'),
(60, 5, 'The Adventures of Tom Sawyer', 'Mark Twain', 95000.00, 10, 'assets/images/books/adventure/tom-sawyer.jpg', 'Berbagai petualangan seorang anak yang tumbuh di tepi Sungai Mississippi.', '2026-08-05 06:22:29');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `image`) VALUES
(1, 'Romance', 'assets/images/categories/category_f90e7d9c095bacb1.png'),
(2, 'Fantasi', 'assets/images/categories/category_4f9a0417ff2ce61c.jpg'),
(3, 'Motivation', 'assets/images/categories/category_fb2a438261c78b4a.png'),
(4, 'Adult Fiction', 'assets/images/categories/adult-fiction.png'),
(5, 'Adventure', 'assets/images/categories/adventure.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `user_id`, `name`, `email`, `message`, `created_at`) VALUES
(1, 3, 'aqila', 'aqila@gmail.com', 'sering nge cancel', '2026-11-10 00:44:21');

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

CREATE TABLE `favorites` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `favorites`
--

INSERT INTO `favorites` (`id`, `user_id`, `book_id`, `created_at`) VALUES
(2, 6, 1, '2026-08-20 01:37:50');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_code` varchar(50) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `payment_method` varchar(30) NOT NULL,
  `payment_proof` varchar(255) DEFAULT NULL,
  `total_amount` decimal(12,2) NOT NULL,
  `shipping_cost` decimal(10,2) NOT NULL DEFAULT 15000.00,
  `status` varchar(30) NOT NULL DEFAULT 'Menunggu Konfirmasi',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `order_code`, `customer_name`, `phone`, `address`, `payment_method`, `payment_proof`, `total_amount`, `shipping_cost`, `status`, `created_at`) VALUES
(1, 1, 'ORD-20260805-B713F3', 'lala', '080987654321', 'Jl. Kebon Jati, Jakarta Timur', 'E-Wallet', NULL, 138000.00, 15000.00, 'Pembayaran Berhasil', '2026-08-05 05:45:12'),
(2, 2, 'ORD-20260805-B79814', 'sitik ais', '08765433456', 'Jl. Pahlawan Revolusi, Nomor 01, Jakarta Timur', 'Transfer Bank', NULL, 552000.00, 15000.00, 'Pembayaran Berhasil', '2026-08-05 05:49:09'),
(3, 2, 'ORD-20260805-453476', 'sitik ais', '08765433456', 'jl.mangga nomor 2, jakarta selatan', 'COD', NULL, 135000.00, 15000.00, 'Pembayaran Berhasil', '2026-08-05 05:56:02'),
(4, 3, 'ORD-20260806-DBA4CB', 'aqila', '08888888888', 'gtauuuuuuuuuuuuuuuuu', 'Transfer Bank', NULL, 145000.00, 15000.00, 'Pembayaran Berhasil', '2026-08-06 05:19:47'),
(5, 1, 'ORD-20260807-2A16C5', 'lala', '0888888888888', 'jalan mangaaaaaa', 'Transfer Bank', NULL, 138000.00, 15000.00, 'Pembayaran Berhasil', '2026-08-07 03:59:16'),
(6, 6, 'ORD-20260820-A8B871', 'bagas', '081234567890', 'jalan aaaaaaaaaaaa', 'Transfer Bank', NULL, 228000.00, 15000.00, 'Pembayaran Berhasil', '2026-08-20 01:41:10'),
(7, 6, 'ORD-20260821-9B58B4', 'bagas', '081234567890', 'jalan aaaaaaaaaaaa', 'Transfer Bank', NULL, 273000.00, 15000.00, 'Pembayaran Berhasil', '2026-08-21 03:02:07'),
(8, 6, 'ORD-20260821-09998B', 'bagas', '081234567890', 'jalan aaaaaaaaa', 'Transfer Bank', NULL, 138000.00, 15000.00, 'Menunggu Konfirmasi', '2026-08-21 03:24:41'),
(9, 6, 'ORD-20260821-DE1444', 'bagas', '081234567890', 'jalan aaaaaaaaa', 'Transfer Bank', NULL, 105000.00, 15000.00, 'Selesai', '2026-08-21 03:35:43'),
(10, 6, 'ORD-20260821-3D6E39', 'bagas', '081234567890', 'jalan aaaaaaaaaa', 'Transfer Bank', NULL, 250000.00, 15000.00, 'Pembayaran Berhasil', '2026-08-21 03:55:28'),
(11, 6, 'ORD-20260821-B875CC', 'bagas', '081234567890', 'jalan aaaaaaaaaa', 'Transfer Bank', NULL, 115000.00, 15000.00, 'Pembayaran Berhasil', '2026-08-21 04:24:42'),
(12, 3, 'ORD-20260821-94D5D2', 'aqila', '081234567890', 'jalan aaaaaaaaaa', 'Transfer Bank', '1787286747_bukti.png', 270000.00, 15000.00, 'Pembayaran Berhasil', '2026-08-21 04:32:27'),
(13, 3, 'ORD-20260821-79BB50', 'aqila', '081234567890', 'jalan bbbbbbbbbb', 'Transfer Bank', '1787287294_bukti.png', 105000.00, 15000.00, 'Pembayaran Berhasil', '2026-08-21 04:41:34'),
(14, 3, 'ORD-20261102-683A89', 'aqila', '081234567890', 'jalan manggs', 'COD', NULL, 138000.00, 15000.00, 'Selesai', '2026-11-02 05:46:35'),
(15, 3, 'ORD-20261102-73B705', 'aqila', '081234567890', 'jalan mangga', 'Transfer Bank', NULL, 90000.00, 15000.00, 'Dibatalkan', '2026-11-02 05:47:05'),
(16, 3, 'ORD-20261102-4B9ED7', 'aqila', '081234567890', 'jalan mangga', 'Transfer Bank', NULL, 138000.00, 15000.00, 'Dibatalkan', '2026-11-02 05:48:42'),
(17, 7, 'ORD-20261102-BFE01C', 'aurel', '081234567890', 'jln masnggis', 'Transfer Bank', NULL, 135000.00, 15000.00, 'Dibatalkan', '2026-11-02 05:56:19'),
(18, 3, 'ORD-20261103-5FB5B1', 'aqila', '081234567890', 'jalan mangga', 'Transfer Bank', NULL, 135000.00, 15000.00, 'Dibatalkan', '2026-11-03 02:56:00'),
(19, 3, 'ORD-20261103-FC4E62', 'aqila', '081234567890', 'jln mangga', 'Transfer Bank', '1793675770_bukti.png', 90000.00, 15000.00, 'Selesai', '2026-11-03 03:16:10'),
(20, 3, 'ORD-20261103-9DECE9', 'aqila', '081234567890', 'jln mangga', 'Transfer Bank', '1793677134_bukti.png', 105000.00, 15000.00, 'Selesai', '2026-11-03 03:38:54'),
(21, 3, 'ORD-20261103-69D550', 'aqila', '08123456789', 'jln mangga', 'COD', NULL, 105000.00, 15000.00, 'Selesai', '2026-11-03 03:43:03'),
(22, 3, 'ORD-20261103-3F6992', 'aqila', '08123456789', 'jln mangga', 'Transfer Bank', '1793677706_bukti.png', 153000.00, 15000.00, 'Selesai', '2026-11-03 03:48:26'),
(23, 5, 'ORD-20261109-067C99', 'rui', '08123456789', 'jalan mangga nomor 7 rt01/03 cipinang jaya', 'Transfer Bank', '1794231491_bukti.png', 105000.00, 15000.00, 'Menunggu Konfirmasi', '2026-11-09 13:38:11'),
(24, 3, 'TBJ-20261110-F1E42C', 'aqila', '08123456789', 'JALAN NANAS NOMOR 3 RT02/05 Jakarta Timur', 'COD', NULL, 105000.00, 15000.00, 'Selesai', '2026-11-10 00:30:50');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `book_id` int(11) DEFAULT NULL,
  `book_title` varchar(150) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `book_id`, `book_title`, `price`, `quantity`, `subtotal`) VALUES
(1, 1, 2, 'Malioboro at Midnight', 138000.00, 1, 138000.00),
(2, 2, 2, 'Malioboro at Midnight', 138000.00, 4, 552000.00),
(3, 3, 3, 'Laut Bercerita', 135000.00, 1, 135000.00),
(4, 4, 50, 'Amba', 145000.00, 1, 145000.00),
(5, 5, 2, 'Malioboro at Midnight', 138000.00, 1, 138000.00),
(6, 6, 1, 'Sisi Tergelap Surga', 90000.00, 1, 90000.00),
(7, 6, 2, 'Malioboro at Midnight', 138000.00, 1, 138000.00),
(8, 7, 2, 'Malioboro at Midnight', 138000.00, 1, 138000.00),
(9, 7, 3, 'Laut Bercerita', 135000.00, 1, 135000.00),
(10, 8, 2, 'Malioboro at Midnight', 138000.00, 1, 138000.00),
(11, 9, 9, 'Antares', 105000.00, 1, 105000.00),
(12, 10, 28, 'Percy Jackson and the Lightning Thief', 125000.00, 2, 250000.00),
(13, 11, 42, 'The Subtle Art of Not Giving a F*ck', 115000.00, 1, 115000.00),
(14, 12, 3, 'Laut Bercerita', 135000.00, 2, 270000.00),
(15, 13, 38, 'Filosofi Teras', 105000.00, 1, 105000.00),
(16, 14, 2, 'Malioboro at Midnight', 138000.00, 1, 138000.00),
(17, 15, 1, 'Sisi Tergelap Surga', 90000.00, 1, 90000.00),
(18, 16, 2, 'Malioboro at Midnight', 138000.00, 1, 138000.00),
(19, 17, 3, 'Laut Bercerita', 135000.00, 1, 135000.00),
(20, 18, 3, 'Laut Bercerita', 135000.00, 1, 135000.00),
(21, 19, 1, 'Sisi Tergelap Surga', 90000.00, 1, 90000.00),
(22, 20, 1, 'Sisi Tergelap Surga', 90000.00, 1, 90000.00),
(23, 21, 1, 'Sisi Tergelap Surga', 90000.00, 1, 90000.00),
(24, 22, 2, 'Malioboro at Midnight', 138000.00, 1, 138000.00),
(25, 23, 1, 'Sisi Tergelap Surga', 90000.00, 1, 90000.00),
(26, 24, 1, 'Sisi Tergelap Surga', 90000.00, 1, 90000.00);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'lala', 'lala@gmail.com', '$2y$10$FbUhtRGRlingxjUxKyXG5OcLKNphbzTWAUUfgNZK3ghp6RqYwGTQq', 'user', '2026-08-05 05:00:01'),
(2, 'sitik ais', 'aissitik@gmail.com', '$2y$10$qhfuzKsUkEynIJ6FO0AzneIs8d1NAMfMgyBd9I8SqIT8LHHfFlEP2', 'user', '2026-08-05 05:47:43'),
(3, 'aqila', 'aqila@gmail.com', '$2y$10$UCCWMlOcNYrH1M5VcT8MjOpvlhtCm6CzAq6IbJVFJmsIJdx2TDKca', 'admin', '2026-08-06 04:14:36'),
(4, 'Lu Chen', 'luchen@gmail.com', '$2y$10$YDvK30pgLDLpEuRD1jDxfOToga0BJrUmYDpsQ76Bnl6J5k9qBqqWS', 'user', '2026-08-07 14:17:08'),
(5, 'rui', 'shenrui@gmail.com', '$2y$10$Wi9KnzINt9bYu/x5ab01dO4I8ExqY30pWyHAal2b3yCiSa3BYGq6G', 'user', '2026-08-20 00:19:34'),
(6, 'bagas', 'bagas@123.com', '$2y$10$XoGSeDlRQPUxVlKW/KWkd.oOR/NLkvzsQUtar0DIFn9YJNkvgxM.a', 'user', '2026-08-20 01:37:24'),
(7, 'aurel', 'aurel@gmail.com', '$2y$10$UdxfDe4IJxm3sHnW8i/ukezmaugcjM9QVTuK/QWXu6mdL.Z8QSwny', 'user', '2026-11-02 05:54:19'),
(8, 'adminbookstore', 'admin@bookstore.id', '$2y$10$g2uO5G26vXslt1inO2YNyOa7NZe5XJK/3nDtG0waUM9Qh6daYZr7W', 'admin', '2026-11-05 00:04:02'),
(9, 'aquila', 'aquila@gmail.com', '$2y$10$7dVaVvX14A5UgRZwNDaJ0.G7syuR96BZSgp2SdAvwVHjFU1t73CX.', 'user', '2026-11-10 01:40:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_book_category` (`category_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_cart` (`user_id`,`book_id`),
  ADD KEY `fk_cart_book` (`book_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_favorite` (`user_id`,`book_id`),
  ADD KEY `fk_favorite_book` (`book_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_code` (`order_code`),
  ADD KEY `fk_order_user` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_order_item_order` (`order_id`),
  ADD KEY `fk_order_item_book` (`book_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `favorites`
--
ALTER TABLE `favorites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `books`
--
ALTER TABLE `books`
  ADD CONSTRAINT `fk_book_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `fk_cart_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_cart_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `favorites`
--
ALTER TABLE `favorites`
  ADD CONSTRAINT `fk_favorite_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_favorite_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_order_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `fk_order_item_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_order_item_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
