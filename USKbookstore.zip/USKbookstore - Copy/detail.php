<?php
require_once 'config/database.php';

$bookId = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($bookId <= 0) {
    header('Location: index.php');
    exit;
}

$stmt = $pdo->prepare("
    SELECT books.*, categories.name AS category_name 
    FROM books 
    LEFT JOIN categories ON categories.id = books.category_id 
    WHERE books.id = :id
");
$stmt->execute(['id' => $bookId]);
$book = $stmt->fetch();

if (!$book) {
    header('Location: index.php');
    exit;
}

$pageTitle = htmlspecialchars($book['title']) . ' - BookStore';
require_once 'partials/header.php';
?>

<div class="container" style="margin-top: 20px;">
    <a href="javascript:history.back()" style="display: inline-flex; align-items: center; gap: 8px; text-decoration: none; color: #6c5ce7; font-weight: 600; font-size: 14px;">
        ← Kembali
    </a>
</div>

<style>
.book-detail-wrapper {
    max-width: 1000px;
    margin: 40px auto;
    background: #ffffff;
    border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
    display: grid;
    grid-template-columns: 350px 1fr;
    gap: 40px;
    padding: 40px;
    align-items: start;
}

.book-detail-cover img {
    width: 100%;
    height: auto;
    border-radius: 12px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
    object-fit: cover;
}

.book-detail-info {
    display: flex;
    flex-direction: column;
}

.book-detail-category {
    font-size: 13px;
    font-weight: 700;
    text-transform: uppercase;
    color: #6c5ce7;
    letter-spacing: 1px;
    margin-bottom: 8px;
}

.book-detail-title {
    font-size: 28px;
    font-weight: 700;
    color: #2d3436;
    margin: 0 0 10px 0;
    line-height: 1.3;
}

.book-detail-author {
    font-size: 15px;
    color: #636e72;
    margin-bottom: 16px;
}

.book-detail-author span {
    font-weight: 600;
    color: #2d3436;
}

.book-detail-price {
    font-size: 24px;
    font-weight: 800;
    color: #6c5ce7;
    margin-bottom: 8px;
}

.book-detail-stock {
    font-size: 14px;
    color: #b2bec3;
    margin-bottom: 24px;
}

.book-detail-divider {
    border: none;
    border-top: 1px solid #eee;
    margin: 0 0 20px 0;
}

.book-detail-desc-title {
    font-size: 16px;
    font-weight: 700;
    color: #2d3436;
    margin-bottom: 8px;
}

.book-detail-desc-text {
    font-size: 14px;
    line-height: 1.6;
    color: #636e72;
    margin-bottom: 30px;
    white-space: pre-line;
}

.book-detail-actions {
    display: flex;
    gap: 12px;
    align-items: center;
}

.btn-pesan {
    flex: 1;
    background: #6c5ce7;
    color: #fff;
    padding: 14px 20px;
    border-radius: 8px;
    font-weight: 600;
    text-align: center;
    text-decoration: none;
    transition: background 0.2s;
    border: none;
    cursor: pointer;
}

.btn-pesan:hover {
    background: #5b4cc4;
}

.btn-icon {
    width: 48px;
    height: 48px;
    border-radius: 8px;
    border: 1px solid #dfe6e9;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.2s;
    font-size: 18px;
}

.btn-icon:hover {
    border-color: #6c5ce7;
    color: #6c5ce7;
}

.btn-cart {
    color: #6c5ce7;
}

.btn-fav {
    color: #ff7675;
}

@media (max-width: 768px) {
    .book-detail-wrapper {
        grid-template-columns: 1fr;
        padding: 20px;
        margin: 20px;
    }
    .book-detail-cover {
        max-width: 250px;
        margin: 0 auto;
    }
}
</style>

<main class="container">
    <div class="book-detail-wrapper">
        
        <!-- Cover Buku di Kolom Kiri -->
        <div class="book-detail-cover">
            <img src="<?= htmlspecialchars($book['cover']); ?>" 
                 alt="<?= htmlspecialchars($book['title']); ?>" 
                 onerror="this.src='assets/images/no-image.jpeg';">
        </div>

        <!-- Informasi di Kolom Kanan -->
        <div class="book-detail-info">
            <span class="book-detail-category">
                <?= htmlspecialchars($book['category_name'] ?? 'Tanpa kategori'); ?>
            </span>
            
            <h1 class="book-detail-title">
                <?= htmlspecialchars($book['title']); ?>
            </h1>
            
            <div class="book-detail-author">
                Penulis: <span><?= htmlspecialchars($book['author']); ?></span>
            </div>
            
            <div class="book-detail-price">
                Rp <?= number_format($book['price'], 0, ',', '.'); ?>
            </div>
            
            <div class="book-detail-stock">
                Stok tersedia: <?= (int) $book['stock']; ?> eks
            </div>

            <hr class="book-detail-divider">

            <div class="book-detail-desc-title">Deskripsi Buku</div>
            <div class="book-detail-desc-text">
                <?= htmlspecialchars($book['description'] ?? 'Belum ada deskripsi untuk buku ini.'); ?>
            </div>

            <!-- Tombol Aksi -->
            <div class="book-detail-actions">
                <?php if ((int) $book['stock'] > 0): ?>
                    <a href="checkout.php?book_id=<?= (int) $book['id']; ?>" class="btn-pesan">
                        Pesan Sekarang
                    </a>
                    
                    <form action="add_cart.php" method="POST" style="margin: 0;">
                        <input type="hidden" name="book_id" value="<?= (int) $book['id']; ?>">
                        <button type="submit" class="btn-icon btn-cart" title="Tambah ke Keranjang">
                            🛒
                        </button>
                    </form>
                <?php else: ?>
                    <button type="button" class="btn-pesan" style="background: #dfe6e9; color: #b2bec3; cursor: not-allowed;" disabled>
                        Stok Habis
                    </button>
                <?php endif; ?>

                <form action="add_favorite.php" method="POST" style="margin: 0;">
                    <input type="hidden" name="book_id" value="<?= (int) $book['id']; ?>">
                    <button type="submit" class="btn-icon btn-fav" title="Tambah ke Favorit">
                        ♡
                    </button>
                </form>
            </div>
            
        </div>
    </div>
</main>

<?php require_once 'partials/footer.php'; ?>