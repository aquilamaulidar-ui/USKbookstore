<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config/database.php';

// Proteksi user biasa
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] === 'admin') {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$success = '';
$error = '';

// Proses Update Profil
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');

    if (empty($name) || empty($phone) || empty($address)) {
        $error = 'Semua kolom wajib diisi!';
    } else {
        $stmt = $pdo->prepare("UPDATE users SET name = ?, phone = ?, address = ? WHERE id = ?");
        if ($stmt->execute([$name, $phone, $address, $userId])) {
            $_SESSION['user_name'] = $name; // Update session nama
            $success = 'Profil berhasil diperbarui!';
        } else {
            $error = 'Gagal memperbarui profil.';
        }
    }
}

// Ambil data terbaru user
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya - BookStore</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body style="background: #f7f6ff; font-family: sans-serif; padding: 40px 20px;">
    <div style="max-width: 600px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.02);">
        <a href="index.php" style="text-decoration: none; color: #746cdf; font-weight: bold;">← Kembali ke Beranda</a>
        <h2 style="margin-top: 15px; color: #333;">Profil & Alamat Pengiriman</h2>
        <p style="color: #666; font-size: 14px; margin-bottom: 25px;">Data ini akan otomatis terisi saat Anda melakukan checkout pesanan.</p>

        <?php if (!empty($success)): ?>
            <div style="background: #e1f5fe; color: #0277bd; padding: 12px; border-radius: 6px; margin-bottom: 20px; font-size: 14px;"><?= $success; ?></div>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <div style="background: #ffebee; color: #c62828; padding: 12px; border-radius: 6px; margin-bottom: 20px; font-size: 14px;"><?= $error; ?></div>
        <?php endif; ?>

        <form action="profile.php" method="POST" style="display: flex; flex-direction: column; gap: 15px;">
            <div>
                <label style="display: block; font-weight: bold; margin-bottom: 5px; font-size: 14px; color: #444;">Nama Lengkap</label>
                <input type="text" name="name" value="<?= htmlspecialchars($user['name'] ?? ''); ?>" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box;">
            </div>
            <div>
                <label style="display: block; font-weight: bold; margin-bottom: 5px; font-size: 14px; color: #444;">Email</label>
                <input type="email" value="<?= htmlspecialchars($user['email'] ?? ''); ?>" disabled style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; background: #f1f1f1; box-sizing: border-box; cursor: not-allowed;">
            </div>
            <div>
                <label style="display: block; font-weight: bold; margin-bottom: 5px; font-size: 14px; color: #444;">Nomor WhatsApp / HP</label>
                <input type="text" name="phone" value="<?= htmlspecialchars($user['phone'] ?? ''); ?>" placeholder="Contoh: 08123456789" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box;">
            </div>
            <div>
                <label style="display: block; font-weight: bold; margin-bottom: 5px; font-size: 14px; color: #444;">Alamat Lengkap</label>
                <textarea name="address" rows="3" placeholder="Masukkan alamat pengiriman utama..." required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box; font-family: inherit;"><?= htmlspecialchars($user['address'] ?? ''); ?></textarea>
            </div>
            <button type="submit" style="background: #746cdf; color: #fff; border: none; padding: 12px; border-radius: 6px; font-weight: bold; cursor: pointer; font-size: 15px; margin-top: 10px;">Simpan Perubahan</button>
        </form>
    </div>
</body>
</html>