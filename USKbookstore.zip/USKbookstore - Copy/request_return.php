<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$orderId = (int) ($_GET['id'] ?? 0);

// Ambil data pesanan milik user
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$orderId, $userId]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: orders.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reason = trim($_POST['return_reason'] ?? '');
    
    if (empty($reason)) {
        $error = 'Alasan pengembalian wajib diisi!';
    } else {
        $proofPath = null;
        
        // Upload bukti foto kerusakan
        if (isset($_FILES['return_proof']) && $_FILES['return_proof']['error'] === UPLOAD_ERR_OK) {
            $fileTmp = $_FILES['return_proof']['tmp_name'];
            $fileName = 'return_' . bin2hex(random_bytes(6)) . '.' . pathinfo($_FILES['return_proof']['name'], PATHINFO_EXTENSION);
            $uploadDir = 'assets/images/returns/';
            
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            
            if (move_uploaded_file($fileTmp, $uploadDir . $fileName)) {
                $proofPath = $uploadDir . $fileName;
            }
        }

        // Update database: return_status diisi, dan status utama pesanan diubah jadi "Pengajuan Return"
        $update = $pdo->prepare("UPDATE orders SET status = 'Pengajuan Return', return_status = 'Menunggu Validasi Admin', return_reason = ?, return_proof = ? WHERE id = ?");
        $update->execute([$reason, $proofPath, $orderId]);

        header("Location: order_detail.php?id=" . $orderId);
        exit;
    }
}

$pageTitle = 'Ajukan Pengembalian - BookStore';
require_once 'partials/header.php';
?>

<section class="container section" style="max-width: 600px;">
    <div style="background: #fff; padding: 30px; border-radius: 12px; border: 1px solid #e1e1e5;">
        <a href="order_detail.php?id=<?= $orderId; ?>" style="text-decoration: none; color: #746cdf; font-weight: bold;">← Kembali</a>
        <h2 style="margin-top: 15px; color: #111;">Form Pengajuan Return Buku</h2>
        <p style="color: #666; font-size: 14px; margin-bottom: 20px;">Kode Pesanan: <strong><?= htmlspecialchars($order['order_code']); ?></strong></p>

        <?php if (!empty($error)): ?>
            <div style="background: #ffebee; color: #c62828; padding: 12px; border-radius: 6px; margin-bottom: 15px; font-size: 14px;"><?= $error; ?></div>
        <?php endif; ?>

        <form action="request_return.php?id=<?= $orderId; ?>" method="POST" enctype="multipart/form-data" style="display: flex; flex-direction: column; gap: 15px;">
            <div>
                <label style="display: block; font-weight: bold; margin-bottom: 5px; font-size: 14px;">Alasan Pengembalian / Kerusakan</label>
                <textarea name="return_reason" rows="4" placeholder="Jelaskan kendala buku (misal: halaman koyak, salah kirim judul, dll)..." required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box; font-family: inherit;"></textarea>
            </div>
            <div>
                <label style="display: block; font-weight: bold; margin-bottom: 5px; font-size: 14px;">Unggah Bukti Foto</label>
                <input type="file" name="return_proof" accept="image/*" required style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 6px; background: #fafafa;">
                <small style="color: #666;">Foto kondisi buku yang bermasalah.</small>
            </div>
            <button type="submit" style="background: #746cdf; color: #fff; border: none; padding: 12px; border-radius: 6px; font-weight: bold; cursor: pointer; margin-top: 10px;">Kirim Pengajuan Return</button>
        </form>
    </div>
</section>

<?php require_once 'partials/footer.php'; ?>