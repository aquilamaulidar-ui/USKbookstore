<?php

require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];

$favoriteQuery = $pdo->prepare(
    "SELECT
        favorites.id AS favorite_id,
        books.id AS book_id,
        books.title,
        books.author,
        books.price,
        books.cover
    FROM favorites
    INNER JOIN books
        ON books.id = favorites.book_id
    WHERE favorites.user_id = ?
    ORDER BY favorites.id DESC"
);

$favoriteQuery->execute([$userId]);

$favoriteItems = $favoriteQuery->fetchAll();

$pageTitle = 'Favorite - BookStore';

require_once 'partials/header.php';
?>

<section class="container section">

    <div class="page-title">
        <span class="section-label">Buku pilihanmu</span>
        <h1>Favorite</h1>
    </div>

    <div class="favorite-grid">

        <?php if (count($favoriteItems) > 0): ?>

            <?php foreach ($favoriteItems as $item): ?>

                <article class="favorite-card">

                    <img
                        src="<?= htmlspecialchars($item['cover']); ?>"
                        alt="<?= htmlspecialchars($item['title']); ?>"
                    >

                    <h3>
                        <?= htmlspecialchars($item['title']); ?>
                    </h3>

                    <p class="book-author">
                        <?= htmlspecialchars($item['author']); ?>
                    </p>

                    <p class="book-price">
                        Rp <?= number_format(
                            $item['price'],
                            0,
                            ',',
                            '.'
                        ); ?>
                    </p>

                    <div class="book-actions">

                        <form action="add_cart.php" method="POST">
                            <input
                                type="hidden"
                                name="book_id"
                                value="<?= (int) $item['book_id']; ?>"
                            >

                            <button
                                type="submit"
                                class="order-button"
                            >
                                Masukkan Cart
                            </button>
                        </form>

                        <form
                            action="delete_favorite.php"
                            method="POST"
                        >
                            <input
                                type="hidden"
                                name="favorite_id"
                                value="<?= (int) $item['favorite_id']; ?>"
                            >

                            <button
                                type="submit"
                                class="delete-button"
                            >
                                Hapus
                            </button>
                        </form>

                    </div>

                </article>

            <?php endforeach; ?>

        <?php else: ?>

            <div class="empty-state">
                Belum ada buku dalam favorite.
                <br><br>

                <a href="index.php" class="primary-button">
                    Lihat Buku
                </a>
            </div>

        <?php endif; ?>

    </div>

</section>

<?php require_once 'partials/footer.php'; ?>