<?php
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: checkout.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$submittedToken = $_POST['checkout_token'] ?? '';
$sessionToken = $_SESSION['checkout_token'] ?? '';

if ($submittedToken === '' || $sessionToken === '' || !hash_equals($sessionToken, $submittedToken)) {
    $_SESSION['checkout_error'] = 'Permintaan checkout tidak valid. Silakan coba kembali.';
    header('Location: checkout.php');
    exit;
}

$customerName = trim($_POST['customer_name'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$address = trim($_POST['address'] ?? '');
$paymentMethod = trim($_POST['payment_method'] ?? '');
$paymentProof = null;

if (isset($_FILES['payment_proof']) && $_FILES['payment_proof']['error'] === UPLOAD_ERR_OK) {
    $uploadDir = 'uploads/payment/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    $fileName = time() . '_' . basename($_FILES['payment_proof']['name']);
    $targetFile = $uploadDir . $fileName;

    if (move_uploaded_file($_FILES['payment_proof']['tmp_name'], $targetFile)) {
        $paymentProof = $fileName;
    }
}

$allowedPayments = ['COD', 'Transfer Bank', 'E-Wallet'];

if ($customerName === '' || $phone === '' || $address === '' || $paymentMethod === '') {
    $_SESSION['checkout_error'] = 'Semua data checkout wajib diisi.';
    header('Location: checkout.php');
    exit;
}

if (strlen($customerName) < 3) {
    $_SESSION['checkout_error'] = 'Nama penerima minimal terdiri dari 3 karakter.';
    header('Location: checkout.php');
    exit;
}

$cleanPhone = preg_replace('/[\s\-\+]/', '', $phone);
if (!ctype_digit($cleanPhone) || strlen($cleanPhone) < 10 || strlen($cleanPhone) > 15) {
    $_SESSION['checkout_error'] = 'Nomor telepon tidak valid.';
    header('Location: checkout.php');
    exit;
}

if (strlen($address) < 10) {
    $_SESSION['checkout_error'] = 'Alamat penerima terlalu singkat.';
    header('Location: checkout.php');
    exit;
}

if (!in_array($paymentMethod, $allowedPayments, true)) {
    $_SESSION['checkout_error'] = 'Metode pembayaran tidak valid.';
    header('Location: checkout.php');
    exit;
}

// Validasi wajib upload bukti bayar jika pilih Transfer atau E-Wallet
if (in_array($paymentMethod, ['Transfer Bank', 'E-Wallet']) && $paymentProof === null) {
    $_SESSION['checkout_error'] = 'Bukti pembayaran wajib diunggah untuk metode Transfer Bank dan E-Wallet.';
    header('Location: checkout.php');
    exit;
}

try {
    $pdo->beginTransaction();

    /*
    |--------------------------------------------------------------------------
    | Ambil Data Buku (Dari Beli Langsung ATAU Cart)
    |--------------------------------------------------------------------------
    */
    $isDirectCheckout = isset($_POST['direct_book_id']) && isset($_POST['direct_quantity']);
    $cartItems = [];

    if ($isDirectCheckout) {
        $directBookId = (int) $_POST['direct_book_id'];
        $directQty = (int) $_POST['direct_quantity'];
        
        $bookQuery = $pdo->prepare("SELECT id AS book_id, title, price, stock FROM books WHERE id = ? FOR UPDATE");
        $bookQuery->execute([$directBookId]);
        $book = $bookQuery->fetch();

        if ($book) {
            $book['quantity'] = $directQty;
            $cartItems[] = $book;
        }
    } else {
        $cartQuery = $pdo->prepare(
            "SELECT cart.quantity, books.id AS book_id, books.title, books.price, books.stock
            FROM cart INNER JOIN books ON books.id = cart.book_id
            WHERE cart.user_id = ? FOR UPDATE"
        );
        $cartQuery->execute([$userId]);
        $cartItems = $cartQuery->fetchAll();
    }

    if (count($cartItems) === 0) {
        throw new Exception('Data pesanan kosong.');
    }

    $totalAmount = 0;
    foreach ($cartItems as $item) {
        $quantity = (int) $item['quantity'];
        $stock = (int) $item['stock'];
        $price = (float) $item['price'];

        if ($quantity < 1) throw new Exception('Jumlah buku tidak valid.');
        if ($quantity > $stock) throw new Exception('Stok buku "' . $item['title'] . '" tidak mencukupi.');

        $totalAmount += $price * $quantity;
    }

    // Kalkulasi Ongkir dan Total Akhir
    $shippingCost = 15000; 
    $grandTotal = $totalAmount + $shippingCost;

    $orderCode = 'ORD-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
    $orderStatus = 'Menunggu Konfirmasi';

    // Simpan ke tabel orders (termasuk kolom shipping_cost dan total_amount yang sudah ditambah ongkir)
    $insertOrder = $pdo->prepare(
        "INSERT INTO orders (user_id, order_code, customer_name, phone, address, payment_method, payment_proof, total_amount, shipping_cost, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    $insertOrder->execute([$userId, $orderCode, $customerName, $cleanPhone, $address, $paymentMethod, $paymentProof, $grandTotal, $shippingCost, $orderStatus]);
    
    $orderId = (int) $pdo->lastInsertId();

    $insertOrderItem = $pdo->prepare("INSERT INTO order_items (order_id, book_id, book_title, price, quantity, subtotal) VALUES (?, ?, ?, ?, ?, ?)");
    $updateStock = $pdo->prepare("UPDATE books SET stock = stock - ? WHERE id = ? AND stock >= ?");

    foreach ($cartItems as $item) {
        $bookId = (int) $item['book_id'];
        $quantity = (int) $item['quantity'];
        $price = (float) $item['price'];
        $subtotal = $price * $quantity;

        $insertOrderItem->execute([$orderId, $bookId, $item['title'], $price, $quantity, $subtotal]);
        $updateStock->execute([$quantity, $bookId, $quantity]);

        if ($updateStock->rowCount() !== 1) {
            throw new Exception('Stok buku "' . $item['title'] . '" berubah atau tidak mencukupi.');
        }
    }

    // Hapus cart HANYA JIKA pesanan berasal dari cart (bukan beli langsung)
    if (!$isDirectCheckout) {
        $deleteCart = $pdo->prepare("DELETE FROM cart WHERE user_id = ?");
        $deleteCart->execute([$userId]);
    }

    $pdo->commit();
    unset($_SESSION['checkout_token']);

    header('Location: order_success.php?id=' . $orderId);
    exit;

} catch (Throwable $error) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $_SESSION['checkout_error'] = $error->getMessage();
    header('Location: checkout.php');
    exit;
}