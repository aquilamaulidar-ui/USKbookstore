<?php
require_once 'config/database.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_SESSION['user_id'] ?? 0;
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $message = trim($_POST['message']);

    if (!empty($name) && !empty($phone) && !empty($message)) {
        $stmt = $pdo->prepare("INSERT INTO contact_messages (user_id, name, phone, message) VALUES (?, ?, ?, ?)");
        $stmt->execute([$userId, $name, $phone, $message]);
        $success = "Pesan berhasil dikirim ke admin!";
    } else {
        $error = "Semua kolom wajib diisi!";
    }
}

$pageTitle = 'Contact to Admin - BookStore';
require_once 'partials/header.php';
?>

<section class="container section">
    <div class="auth-section" style="min-height: auto; padding: 20px 0;">
        <div class="auth-card" style="width: min(550px, 100%);">
            <h1>Contact to Admin</h1>
            <p class="auth-description">Kirim pesan, kendala, atau pertanyaan ke admin BookStore.</p>

            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success; ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-error"><?= $error; ?></div>
            <?php endif; ?>

            <form action="contact.php" method="POST">
                <div class="form-group">
                    <label for="name">Nama</label>
                    <input type="text" id="name" name="name" value="<?= htmlspecialchars($_SESSION['user_name'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                     <label for="phone">Nomor WhatsApp</label>
                    <input type="text" id="phone" name="phone" placeholder="Contoh: 08123456789" required>
                </div>
                <div class="form-group">
                    <label for="message">Pesan</label>
                    <textarea id="message" name="message" rows="5" placeholder="Tulis pesan atau kendala kamu di sini..." required style="width: 100%; padding: 12px; border: 1px solid #d8d8df; border-radius: 7px;"></textarea>
                </div>
                <button type="submit" class="submit-button">Kirim Pesan</button>
            </form>
        </div>
    </div>
</section>

<?php require_once 'partials/footer.php'; ?>