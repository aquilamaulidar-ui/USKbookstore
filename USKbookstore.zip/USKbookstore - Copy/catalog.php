<?php
require_once 'config/database.php';

$pageTitle = 'Semua Buku - BookStore';

// Ambil semua buku lengkap dengan data kategori dan jumlah terjual
$query = $pdo->query(
    "SELECT
        books.*,
        categories.name AS category_name,
        COALESCE(SUM(order_items.quantity), 0) AS total_sold
    FROM books
    LEFT JOIN categories ON categories.id = books.category_id
    LEFT JOIN order_items ON books.id = order_items.book_id
    GROUP BY books.id
    ORDER BY books.id DESC"
);
$allBooks = $query->fetchAll();

require_once 'partials/header.php';
?>

<section class="container section">
    <div class="section-header" style="margin-bottom: 25px;">
        <div>
            <a href="index.php" class="back-link">← Kembali ke Beranda</a>
            <h1 style="margin-top: 10px;">Semua Koleksi Buku</h1>
            <p style="color: #666;">Daftar lengkap seluruh buku, rating ulasan, dan statistik penjualan.</p>
        </div>
    </div>

    <div class="book-grid">
        <?php if (count($allBooks) > 0): ?>
            <?php foreach ($allBooks as $book): ?>
                <article class="book-card">
                    <div class="book-cover">
                        <a href="detail.php?id=<?= (int) $book['id']; ?>">
                            <img src="<?= htmlspecialchars($book['cover']); ?>" alt="<?= htmlspecialchars($book['title']); ?>" onerror="this.src='assets/images/no-image.jpeg';">
                        </a>
                    </div>
                    <div class="book-information">
                        <span class="book-category"><?= htmlspecialchars($book['category_name'] ?? 'Tanpa kategori'); ?></span>
                        <h3>
                            <a href="detail.php?id=<?= (int) $book['id']; ?>" style="text-decoration: none; color: inherit;">
                                <?= htmlspecialchars($book['title']); ?>
                            </a>
                        </h3>   
                        <p class="book-author"><?= htmlspecialchars($book['author']); ?></p>
                        
                        <div style="display: flex; justify-content: space-between; align-items: center; margin: 8px 0; font-size: 13px;">
                            <span style="color: #f39c12; font-weight: bold;">⭐ <?= number_format($book['rating'] ?? 5.0, 1); ?></span>
                            <span style="color: #746cdf; font-weight: bold;">🔥 Terjual: <?= (int) $book['total_sold']; ?></span>
                        </div>

                        <p class="book-stock">Stok: <?= (int) $book['stock']; ?></p>
                        <p class="book-price">Rp <?= number_format($book['price'], 0, ',', '.'); ?></p>

                        <div class="book-actions" style="display: flex; gap: 8px; width: 100%; align-items: center; margin-top: 10px;">
                            <?php if ((int) $book['stock'] > 0): ?>
                                <a href="checkout.php?book_id=<?= (int) $book['id']; ?>" class="order-button" style="flex: 1; text-align: center; line-height: 20px;">Pesan</a>
                                <form action="add_cart.php" method="POST" style="margin: 0;">
                                    <input type="hidden" name="book_id" value="<?= (int) $book['id']; ?>">
                                    <button type="submit" class="favorite-button" style="display: grid; place-items: center;" title="Tambah ke Keranjang">🛒</button>
                                </form>
                            <?php else: ?>
                                <button type="button" class="out-of-stock-button" style="flex: 1;" disabled>Stok Habis</button>
                            <?php endif; ?>
                            <form action="add_favorite.php" method="POST" style="margin: 0;">
                                <input type="hidden" name="book_id" value="<?= (int) $book['id']; ?>">
                                <button type="submit" class="favorite-button" title="Tambahkan ke favorite">♡</button>
                            </form>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">
                <h2>Belum ada buku tersedia</h2>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php require_once 'partials/footer.php'; ?>