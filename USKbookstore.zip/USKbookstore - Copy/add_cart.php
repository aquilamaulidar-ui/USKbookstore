<?php

require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$bookId = (int) ($_POST['book_id'] ?? 0);
$userId = (int) $_SESSION['user_id'];

if ($bookId <= 0) {
    header('Location: index.php');
    exit;
}

$checkBook = $pdo->prepare(
    "SELECT id FROM books WHERE id = ?"
);

$checkBook->execute([$bookId]);

if (!$checkBook->fetch()) {
    header('Location: index.php');
    exit;
}

$insertCart = $pdo->prepare(
    "INSERT INTO cart (user_id, book_id, quantity)
     VALUES (?, ?, 1)
     ON DUPLICATE KEY UPDATE
     quantity = quantity + 1"
);

$insertCart->execute([
    $userId,
    $bookId
]);

header('Location: ' . $_SERVER['HTTP_REFERER']);
exit;