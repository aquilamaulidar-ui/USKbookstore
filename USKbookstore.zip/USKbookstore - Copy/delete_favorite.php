<?php

require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: favorite.php');
    exit;
}

$favoriteId = (int) ($_POST['favorite_id'] ?? 0);
$userId = (int) $_SESSION['user_id'];

$deleteFavorite = $pdo->prepare(
    "DELETE FROM favorites
     WHERE id = ?
     AND user_id = ?"
);

$deleteFavorite->execute([
    $favoriteId,
    $userId
]);

header('Location: favorite.php');
exit;