<?php

require_once 'config/database.php';

/*
|--------------------------------------------------------------------------
| Pastikan pengguna sudah login
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$orderId = (int) ($_GET['id'] ?? 0);

if ($orderId <= 0) {
    header('Location: orders.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Mengambil data pesanan
|--------------------------------------------------------------------------
*/

$orderQuery = $pdo->prepare(
    "SELECT *
    FROM orders
    WHERE id = ?
    AND user_id = ?
    LIMIT 1"
);

$orderQuery->execute([
    $orderId,
    $userId
]);

$order = $orderQuery->fetch();

if (!$order) {
    header('Location: orders.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Mengambil buku dalam pesanan
|--------------------------------------------------------------------------
*/

$itemQuery = $pdo->prepare(
    "SELECT
        order_items.*,
        books.cover
    FROM order_items
    LEFT JOIN books
        ON books.id = order_items.book_id
    WHERE order_items.order_id = ?
    ORDER BY order_items.id ASC"
);

$itemQuery->execute([$orderId]);

$orderItems = $itemQuery->fetchAll();

/*
|--------------------------------------------------------------------------
| Menentukan warna status
|--------------------------------------------------------------------------
*/

$statusClass = 'status-processing';

if ($order['status'] === 'Pembayaran Berhasil') {
    $statusClass = 'status-paid';
} elseif ($order['status'] === 'Selesai' || $order['status'] === 'Refund Selesai') {
    $statusClass = 'status-completed';
} elseif ($order['status'] === 'Dibatalkan') {
    $statusClass = 'status-cancelled';
}

$pageTitle = 'Detail Pesanan - BookStore';

require_once 'partials/header.php';
?>

<section class="container section">

    <div class="detail-page-heading">

        <div>
            <a href="orders.php" class="back-link">
                ← Kembali ke Riwayat Pesanan
            </a>

            <h1>Detail Pesanan</h1>

            <p>
                <?= htmlspecialchars($order['order_code']); ?>
            </p>
        </div>

        <span class="order-status <?= $statusClass; ?>">
            <?= htmlspecialchars($order['status']); ?>
        </span>

    </div>

    <div class="order-detail-layout">

        <div class="order-detail-main">

            <div class="order-detail-card">

                <h2>Buku yang Dibeli</h2>

                <div class="order-product-list">

                    <?php foreach ($orderItems as $item): ?>

                        <article class="order-product-item">

                            <div class="order-product-cover">

                                <?php if (!empty($item['cover'])): ?>

                                    <img
                                        src="<?= htmlspecialchars(
                                            $item['cover']
                                        ); ?>"
                                        alt="<?= htmlspecialchars(
                                            $item['book_title']
                                        ); ?>"
                                    >

                                <?php else: ?>

                                    <div class="missing-cover">
                                        Tidak ada gambar
                                    </div>

                                <?php endif; ?>

                            </div>

                            <div class="order-product-information">

                                <h3>
                                    <?= htmlspecialchars(
                                        $item['book_title']
                                    ); ?>
                                </h3>

                                <p>
                                    Harga satuan:
                                    Rp <?= number_format(
                                        $item['price'],
                                        0,
                                        ',',
                                        '.'
                                    ); ?>
                                </p>

                                <p>
                                    Jumlah:
                                    <?= (int) $item['quantity']; ?>
                                </p>

                            </div>

                            <div class="order-product-subtotal">

                                <span>Subtotal</span>

                                <strong>
                                    Rp <?= number_format(
                                        $item['subtotal'],
                                        0,
                                        ',',
                                        '.'
                                    ); ?>
                                </strong>

                            </div>

                        </article>

                    <?php endforeach; ?>

                </div>

            </div>

            <div class="order-detail-card">

                <h2>Alamat Pengiriman</h2>

                <div class="shipping-information">

                    <strong>
                        <?= htmlspecialchars(
                            $order['customer_name']
                        ); ?>
                    </strong>

                    <p>
                        <?= htmlspecialchars($order['phone']); ?>
                    </p>

                    <p>
                        <?= nl2br(
                            htmlspecialchars($order['address'])
                        ); ?>
                    </p>

                </div>

            </div>

        </div>

        <aside class="order-detail-summary">

            <h2>Ringkasan</h2>

            <div class="order-summary-row">
                <span>Kode pesanan</span>

                <strong>
                    <?= htmlspecialchars($order['order_code']); ?>
                </strong>
            </div>

            <div class="order-summary-row">
                <span>Tanggal</span>

                <strong>
                    <?= date(
                        'd M Y',
                        strtotime($order['created_at'])
                    ); ?>
                </strong>
            </div>

            <div class="order-summary-row">
                <span>Waktu</span>

                <strong>
                    <?= date(
                        'H:i',
                        strtotime($order['created_at'])
                    ); ?>
                </strong>
            </div>

            <div class="order-summary-row">
                <span>Metode pembayaran</span>

                <strong>
                    <?= htmlspecialchars(
                        $order['payment_method']
                    ); ?>
                </strong>
            </div>

            <div class="order-summary-row">
                <span>Status</span>

                <strong>
                    <?= htmlspecialchars($order['status']); ?>
                </strong>
            </div>

            <div class="order-summary-row">
                <span>Subtotal Buku</span>
                <strong>
                    Rp <?= number_format(
                        $order['total_amount'] - ($order['shipping_cost'] ?? 15000),
                        0,
                        ',',
                        '.'
                    ); ?>
                </strong>
            </div>

            <div class="order-summary-row">
                <span>Ongkos Kirim</span>
                <strong>
                    Rp <?= number_format(
                        $order['shipping_cost'] ?? 15000,
                        0,
                        ',',
                        '.'
                    ); ?>
                </strong>
            </div>

            <div class="order-summary-total">
                <span>Total pembayaran</span>

                <strong>
                    Rp <?= number_format(
                        $order['total_amount'],
                        0,
                        ',',
                        '.'
                    ); ?>
                </strong>
            </div>

            <!-- Tombol Konfirmasi "Pesanan Diterima / Selesai" -->
            <?php if ($order['status'] === 'Dikirim'): ?>
                <form action="update_user_order.php" method="POST" style="margin-top: 15px;" onsubmit="return confirm('Apakah kamu yakin pesanan sudah diterima?');">
                    <input type="hidden" name="order_id" value="<?= (int) $order['id']; ?>">
                    <button type="submit" style="width: 100%; padding: 12px; background: #25d366; color: #fff; border: none; border-radius: 7px; font-weight: bold; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px;">
                        ✓ Pesanan Diterima / Selesai
                    </button>
                </form>
            <?php endif; ?>

            <!-- Fitur Return / Pengembalian (Muncul saat status 'Dikirim') -->
            <?php if ($order['status'] === 'Dikirim' && (empty($order['return_status']) || $order['return_status'] === 'Tidak Ada')): ?>
                <div style="margin-top: 15px; border-top: 1px solid #e1e1e5; padding-top: 15px;">
                    <a href="request_return.php?id=<?= $order['id']; ?>" style="display: block; text-align: center; padding: 12px; background: #fff3e0; color: #e65100; border: 1px solid #ffe0b2; border-radius: 7px; text-decoration: none; font-weight: bold; font-size: 14px;">
                        📦 Ajukan Pengembalian (Return)
                    </a>
                </div>
            <?php elseif (!empty($order['return_status']) && $order['return_status'] !== 'Tidak Ada'): ?>
                <div style="margin-top: 15px; border-top: 1px solid #e1e1e5; padding-top: 15px; background: #f9f9fb; padding: 12px; border-radius: 8px;">
                    <strong style="font-size: 13px; color: #333; display: block; margin-bottom: 5px;">Status Return: <span style="color: #746cdf;"><?= htmlspecialchars($order['return_status']); ?></span></strong>
                    <p style="font-size: 12px; color: #666; margin: 0 0 8px 0;">Alasan: <?= htmlspecialchars($order['return_reason'] ?? ''); ?></p>
                    
                    <?php if (!empty($order['return_proof'])): ?>
                        <p style="font-size: 12px; margin: 0 0 8px 0;"><a href="<?= htmlspecialchars($order['return_proof']); ?>" target="_blank" style="color: #746cdf;">Lihat Bukti Foto Kerusakan</a></p>
                    <?php endif; ?>

                    <?php if ($order['return_status'] === 'Return Disetujui (Kirim Paket)'): ?>
                        <form action="update_return_receipt.php" method="POST" style="margin-top: 10px;">
                            <input type="hidden" name="order_id" value="<?= $order['id']; ?>">
                            <input type="text" name="return_receipt" placeholder="Masukkan Nomor Resi Ekspedisi" required style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 5px; font-size: 12px; margin-bottom: 8px; box-sizing: border-box;">
                            <button type="submit" style="width: 100%; padding: 8px; background: #25d366; color: #fff; border: none; border-radius: 5px; font-weight: bold; cursor: pointer; font-size: 12px;">
                                Kirim No. Resi Pengembalian
                            </button>
                        </form>
                    <?php elseif (!empty($order['return_receipt'])): ?>
                        <p style="font-size: 12px; color: #444; margin: 0;">No. Resi Pengiriman: <strong><?= htmlspecialchars($order['return_receipt']); ?></strong></p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <a href="receipt.php?id=<?= (int) $order['id']; ?>" target="_blank" class="secondary-success-button" style="display: block; margin-top: 10px; text-align: center; text-decoration: none; padding: 12px; background: #f1efff; color: #746cdf; border: 1px solid #d7d3ff; border-radius: 7px; font-weight: bold;">
                🖨️ Cetak Struk
            </a>

            <a href="index.php" class="submit-button shop-again-button" style="margin-top: 10px; display: block; text-align: center; text-decoration: none;">
                Belanja Lagi
            </a>

        </aside>

    </div>

</section>

<?php require_once 'partials/footer.php'; ?>