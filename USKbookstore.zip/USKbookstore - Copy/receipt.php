<?php
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$orderId = (int) ($_GET['id'] ?? 0);

if ($orderId <= 0) {
    header('Location: orders.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Ambil data pesanan
|--------------------------------------------------------------------------
*/
$orderQuery = $pdo->prepare(
    "SELECT * FROM orders WHERE id = ? AND user_id = ? LIMIT 1"
);
$orderQuery->execute([$orderId, $userId]);
$order = $orderQuery->fetch();

if (!$order) {
    header('Location: orders.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Ambil item buku dalam pesanan
|--------------------------------------------------------------------------
*/
$itemQuery = $pdo->prepare(
    "SELECT * FROM order_items WHERE order_id = ? ORDER BY id ASC"
);
$itemQuery->execute([$orderId]);
$orderItems = $itemQuery->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk Pembelian - <?= htmlspecialchars($order['order_code']); ?></title>
    <style>
        body {
            font-family: 'Courier New', Courier, monospace;
            color: #000;
            background: #fff;
            margin: 0;
            padding: 20px;
        }
        .receipt-container {
            width: 350px;
            max-width: 100%;
            margin: 0 auto;
            background: #fff;
            padding: 15px;
            border: 1px dashed #999;
        }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .bold { font-weight: bold; }
        .divider {
            border-top: 1px dashed #000;
            margin: 10px 0;
        }
        .flex-between {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }
        th, td {
            padding: 5px 0;
            text-align: left;
            vertical-align: top;
        }
        th { border-bottom: 1px solid #000; }
        .no-print {
            margin-top: 20px;
            text-align: center;
        }
        .btn-print, .btn-back {
            padding: 10px 20px;
            font-family: Arial, sans-serif;
            font-weight: bold;
            text-decoration: none;
            border-radius: 5px;
            cursor: pointer;
            border: none;
            display: inline-block;
            margin: 0 5px;
        }
        .btn-print { background: #837bea; color: #fff; }
        .btn-back { background: #f1efff; color: #746cdf; border: 1px solid #d7d3ff; }

        @media print {
            .no-print { display: none; }
            body { padding: 0; }
            .receipt-container { border: none; width: 100%; padding: 0; }
        }
    </style>
</head>
<body>

<div class="receipt-container">
    <div class="text-center">
        <h2 style="margin: 0 0 5px 0;">BookStore</h2>
        <small>Temukan bukumu</small>
        <div class="divider"></div>
    </div>

    <div style="font-size: 12px; margin-bottom: 10px;">
        <div class="flex-between">
            <span>No. Pesanan:</span>
            <span class="bold"><?= htmlspecialchars($order['order_code']); ?></span>
        </div>
        <div class="flex-between">
            <span>Tanggal:</span>
            <span><?= date('d/m/Y H:i', strtotime($order['created_at'])); ?></span>
        </div>
        <div class="flex-between">
            <span>Pembeli:</span>
            <span><?= htmlspecialchars($order['customer_name']); ?></span>
        </div>
        <div class="flex-between">
            <span>Metode Bayar:</span>
            <span><?= htmlspecialchars($order['payment_method']); ?></span>
        </div>
    </div>

    <!-- Tanda Khusus Jika Pesanan Dibatalkan -->
    <?php if ($order['status'] === 'Dibatalkan'): ?>
        <div style="text-align: center; border: 2px dashed red; color: red; padding: 6px; margin: 10px 0; font-weight: bold; font-size: 12px; background: #fff5f5;">
            STATUS: PESANAN DIBATALKAN
        </div>
    <?php endif; ?>

    <div class="divider"></div>

    <table>
        <thead>
            <tr>
                <th>Item</th>
                <th class="text-center">Qty</th>
                <th class="text-right">Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($orderItems as $item): ?>
                <tr>
                    <td>
                        <?= htmlspecialchars($item['book_title']); ?><br>
                        <small style="font-size: 11px; color: #555;">@Rp <?= number_format($item['price'], 0, ',', '.'); ?></small>
                    </td>
                    <td class="text-center"><?= (int) $item['quantity']; ?></td>
                    <td class="text-right">Rp <?= number_format($item['subtotal'], 0, ',', '.'); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="divider"></div>

    <div style="font-size: 12px; margin-bottom: 5px;">
        <div class="flex-between">
            <span>Subtotal Buku:</span>
            <span>Rp <?= number_format($order['total_amount'] - $order['shipping_cost'], 0, ',', '.'); ?></span>
        </div>
        <div class="flex-between">
            <span>Ongkos Kirim:</span>
            <span>Rp <?= number_format($order['shipping_cost'], 0, ',', '.'); ?></span>
        </div>
    </div>

    <div class="divider"></div>

    <div style="font-size: 13px;">
        <div class="flex-between bold" style="font-size: 15px; margin-top: 5px;">
            <span>TOTAL:</span>
            <span>Rp <?= number_format($order['total_amount'], 0, ',', '.'); ?></span>
        </div>
    </div>

    <div class="divider"></div>
    <div class="text-center" style="font-size: 11px; margin-top: 15px;">
        <p>Terima kasih sudah berbelanja di BookStore!<br>Barang yang sudah dibeli tidak dapat ditukar.</p>
    </div>

    <!-- Tombol Aksi (Hilang otomatis saat dicetak) -->
    <div class="no-print">
        <button onclick="window.print()" class="btn-print">Cetak Struk</button>
        <a href="order_detail.php?id=<?= $orderId; ?>" class="btn-back">Kembali</a>
    </div>
</div>

</body>
</html>