<?php

require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];

$cartQuery = $pdo->prepare(
    "SELECT
        cart.id AS cart_id,
        cart.quantity,
        books.id AS book_id,
        books.title,
        books.author,
        books.price,
        books.cover,
        books.stock
    FROM cart
    INNER JOIN books
        ON books.id = cart.book_id
    WHERE cart.user_id = ?
    ORDER BY cart.id DESC"
);

$cartQuery->execute([$userId]);

$cartItems = $cartQuery->fetchAll();

$total = 0;
$totalQuantity = 0;

foreach ($cartItems as $item) {
    $subtotal = $item['price'] * $item['quantity'];

    $total += $subtotal;
    $totalQuantity += $item['quantity'];
}

$pageTitle = 'Cart - BookStore';

require_once 'partials/header.php';
?>

<section class="container section">

    <div class="page-title">
        <span class="section-label">Keranjang belanja</span>
        <h1>Cart</h1>
    </div>

    <?php if (count($cartItems) > 0): ?>

        <div class="cart-layout">

            <div class="cart-list">

                <?php foreach ($cartItems as $item): ?>

                    <article class="cart-item">

                        <img
                            src="<?= htmlspecialchars($item['cover']); ?>"
                            alt="<?= htmlspecialchars($item['title']); ?>"
                        >

                        <div>
                            <h3>
                                <?= htmlspecialchars($item['title']); ?>
                            </h3>

                            <p>
                                <?= htmlspecialchars($item['author']); ?>
                            </p>

                            <p class="book-price">
                                Rp <?= number_format(
                                    $item['price'],
                                    0,
                                    ',',
                                    '.'
                                ); ?>
                            </p>

                            <form
                                action="update_cart.php"
                                method="POST"
                                class="quantity-form"
                            >
                                <input
                                    type="hidden"
                                    name="cart_id"
                                    value="<?= (int) $item['cart_id']; ?>"
                                >

                                <input
                                    type="number"
                                    name="quantity"
                                    min="1"
                                    max="<?= (int) $item['stock']; ?>"
                                    value="<?= (int) $item['quantity']; ?>"
                                >

                                <button
                                    type="submit"
                                    class="small-button"
                                >
                                    Update
                                </button>
                            </form>
                        </div>

                        <form
                            action="delete_cart.php"
                            method="POST"
                        >
                            <input
                                type="hidden"
                                name="cart_id"
                                value="<?= (int) $item['cart_id']; ?>"
                            >

                            <button
                                type="submit"
                                class="delete-button"
                            >
                                Hapus
                            </button>
                        </form>

                    </article>

                <?php endforeach; ?>

            </div>

            <aside class="cart-summary">

                <h2>Ringkasan Pesanan</h2>

                <div class="summary-row">
                    <span>Jumlah barang</span>
                    <strong><?= $totalQuantity; ?></strong>
                </div>

                <div class="summary-row summary-total">
                    <span>Total</span>

                    <strong>
                        Rp <?= number_format(
                            $total,
                            0,
                            ',',
                            '.'
                        ); ?>
                    </strong>
                </div>

                <a
    href="checkout.php"
    class="submit-button checkout-link"
>
    Checkout
</a>

            </aside>

        </div>

    <?php else: ?>

        <div class="empty-state">
            Keranjangmu masih kosong.
            <br><br>
            <a href="index.php" class="primary-button">
                Cari Buku
            </a>
        </div>

    <?php endif; ?>

</section>

<?php require_once 'partials/footer.php'; ?>