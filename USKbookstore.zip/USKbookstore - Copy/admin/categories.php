<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';

$currentPage = basename($_SERVER['PHP_SELF']);


/* =========================================================
   PROTEKSI ADMIN
========================================================= */

if (
    !isset($_SESSION['user_id']) ||
    !isset($_SESSION['user_role']) ||
    $_SESSION['user_role'] !== 'admin'
) {
    header('Location: ../index.php');
    exit;
}


/* =========================================================
   CSRF
========================================================= */

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}


/* =========================================================
   FLASH
========================================================= */

function categoryFlash($type, $message)
{
    $_SESSION['category_flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

$flash = $_SESSION['category_flash'] ?? null;

unset($_SESSION['category_flash']);


/* =========================================================
   GAMBAR
========================================================= */

function categoryImageSrc($image)
{
    if (empty($image)) {
        return '../assets/images/no-image.jpeg';
    }

    if (preg_match('/^https?:\/\//i', $image)) {
        return $image;
    }

    return '../' . ltrim($image, '/');
}


$uploadDirectory =
    dirname(__DIR__) . '/assets/images/categories';


if (!is_dir($uploadDirectory)) {
    mkdir($uploadDirectory, 0777, true);
}


/* =========================================================
   POST
========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $csrf = $_POST['csrf_token'] ?? '';

    if (
        !$csrf ||
        !hash_equals($_SESSION['csrf_token'], $csrf)
    ) {
        die('Permintaan tidak valid.');
    }


    $action = $_POST['action'] ?? '';


    /* =====================================================
       HAPUS
    ===================================================== */

    if ($action === 'delete') {

        $id = (int) ($_POST['id'] ?? 0);


        $findCategory = $pdo->prepare(
            "SELECT *
             FROM categories
             WHERE id = ?"
        );

        $findCategory->execute([$id]);

        $category = $findCategory->fetch();


        if (!$category) {

            categoryFlash(
                'error',
                'Kategori tidak ditemukan.'
            );

            header('Location: categories.php');
            exit;
        }


        /*
         * Cek apakah kategori masih dipakai buku
         */

        $bookCountQuery = $pdo->prepare(
            "SELECT COUNT(*)
             FROM books
             WHERE category_id = ?"
        );

        $bookCountQuery->execute([$id]);

        $usedByBooks =
            (int) $bookCountQuery->fetchColumn();


        if ($usedByBooks > 0) {

            categoryFlash(
                'error',
                'Kategori tidak dapat dihapus karena masih digunakan oleh '
                . $usedByBooks
                . ' buku.'
            );

            header('Location: categories.php');
            exit;
        }


        $delete = $pdo->prepare(
            "DELETE FROM categories
             WHERE id = ?"
        );

        $delete->execute([$id]);


        /*
         * Hapus gambar hanya jika gambar hasil upload admin
         */

        if (
            !empty($category['image']) &&
            str_starts_with(
                $category['image'],
                'assets/images/categories/'
            )
        ) {

            $imageFile =
                dirname(__DIR__)
                . '/'
                . $category['image'];


            if (is_file($imageFile)) {
                unlink($imageFile);
            }
        }


        categoryFlash(
            'success',
            'Kategori berhasil dihapus.'
        );

        header('Location: categories.php');
        exit;
    }


    /* =====================================================
       TAMBAH / UPDATE
    ===================================================== */

    if (
        $action === 'add' ||
        $action === 'update'
    ) {

        $id =
            (int) ($_POST['id'] ?? 0);

        $name =
            trim($_POST['name'] ?? '');


        if ($name === '') {

            categoryFlash(
                'error',
                'Nama kategori wajib diisi.'
            );

            header('Location: categories.php');
            exit;
        }


        /*
         * Cek nama kategori duplicate
         */

        if ($action === 'add') {

            $duplicateQuery = $pdo->prepare(
                "SELECT id
                 FROM categories
                 WHERE LOWER(name) = LOWER(?)
                 LIMIT 1"
            );

            $duplicateQuery->execute([$name]);

        } else {

            $duplicateQuery = $pdo->prepare(
                "SELECT id
                 FROM categories
                 WHERE LOWER(name) = LOWER(?)
                 AND id != ?
                 LIMIT 1"
            );

            $duplicateQuery->execute([
                $name,
                $id
            ]);
        }


        if ($duplicateQuery->fetch()) {

            categoryFlash(
                'error',
                'Nama kategori tersebut sudah digunakan.'
            );

            header('Location: categories.php');
            exit;
        }


        /* =================================================
           GAMBAR LAMA
        ================================================= */

        $oldImage = null;


        if ($action === 'update') {

            $find = $pdo->prepare(
                "SELECT image
                 FROM categories
                 WHERE id = ?"
            );

            $find->execute([$id]);

            $existing =
                $find->fetch();


            if (!$existing) {

                categoryFlash(
                    'error',
                    'Kategori yang ingin diedit tidak ditemukan.'
                );

                header('Location: categories.php');
                exit;
            }


            $oldImage =
                $existing['image'];
        }


        $imagePath =
            $oldImage;


        /* =================================================
           UPLOAD GAMBAR
        ================================================= */

        if (
            isset($_FILES['image']) &&
            $_FILES['image']['error']
                !== UPLOAD_ERR_NO_FILE
        ) {

            if (
                $_FILES['image']['error']
                !== UPLOAD_ERR_OK
            ) {

                categoryFlash(
                    'error',
                    'Upload gambar gagal.'
                );

                header('Location: categories.php');
                exit;
            }


            if (
                $_FILES['image']['size']
                > 3 * 1024 * 1024
            ) {

                categoryFlash(
                    'error',
                    'Ukuran gambar maksimal 3 MB.'
                );

                header('Location: categories.php');
                exit;
            }


            $finfo =
                new finfo(FILEINFO_MIME_TYPE);


            $mime =
                $finfo->file(
                    $_FILES['image']['tmp_name']
                );


            $allowed = [

                'image/jpeg' => 'jpg',
                'image/png'  => 'png',
                'image/webp' => 'webp'

            ];


            if (!isset($allowed[$mime])) {

                categoryFlash(
                    'error',
                    'Gambar hanya boleh JPG, PNG, atau WEBP.'
                );

                header('Location: categories.php');
                exit;
            }


            $extension =
                $allowed[$mime];


            $fileName =
                'category_'
                . bin2hex(random_bytes(8))
                . '.'
                . $extension;


            $destination =
                $uploadDirectory
                . '/'
                . $fileName;


            if (
                !move_uploaded_file(
                    $_FILES['image']['tmp_name'],
                    $destination
                )
            ) {

                categoryFlash(
                    'error',
                    'Gambar gagal disimpan.'
                );

                header('Location: categories.php');
                exit;
            }


            $imagePath =
                'assets/images/categories/'
                . $fileName;
        }


        /* =================================================
           INSERT
        ================================================= */

        if ($action === 'add') {

            $insert = $pdo->prepare(
                "INSERT INTO categories
                (
                    name,
                    image
                )
                VALUES
                (
                    :name,
                    :image
                )"
            );


            $insert->execute([

                'name' => $name,
                'image' => $imagePath

            ]);


            categoryFlash(
                'success',
                'Kategori baru berhasil ditambahkan.'
            );


            header('Location: categories.php');
            exit;
        }


        /* =================================================
           UPDATE
        ================================================= */

        if ($action === 'update') {

            $update = $pdo->prepare(
                "UPDATE categories
                 SET
                    name = :name,
                    image = :image
                 WHERE id = :id"
            );


            $update->execute([

                'name' => $name,
                'image' => $imagePath,
                'id' => $id

            ]);


            /*
             * Kalau gambar diganti, hapus gambar lama
             */

            if (
                $imagePath !== $oldImage &&
                !empty($oldImage) &&
                str_starts_with(
                    $oldImage,
                    'assets/images/categories/'
                )
            ) {

                $oldFile =
                    dirname(__DIR__)
                    . '/'
                    . $oldImage;


                if (is_file($oldFile)) {
                    unlink($oldFile);
                }
            }


            categoryFlash(
                'success',
                'Kategori berhasil diperbarui.'
            );


            header('Location: categories.php');
            exit;
        }
    }
}


/* =========================================================
   EDIT
========================================================= */

$editCategory = null;


if (isset($_GET['edit'])) {

    $editId =
        (int) $_GET['edit'];


    $editQuery = $pdo->prepare(
        "SELECT *
         FROM categories
         WHERE id = ?"
    );


    $editQuery->execute([$editId]);


    $editCategory =
        $editQuery->fetch();
}


/* =========================================================
   SEARCH
========================================================= */

$keyword =
    trim($_GET['search'] ?? '');


if ($keyword !== '') {

    $categoryQuery = $pdo->prepare(
        "SELECT

            categories.*,

            COUNT(books.id)
                AS book_count

         FROM categories

         LEFT JOIN books
            ON books.category_id
                = categories.id

         WHERE categories.name LIKE :keyword

         GROUP BY categories.id

         ORDER BY categories.id DESC"
    );


    $categoryQuery->execute([

        'keyword'
            => '%' . $keyword . '%'

    ]);

} else {

    $categoryQuery = $pdo->query(
        "SELECT

            categories.*,

            COUNT(books.id)
                AS book_count

         FROM categories

         LEFT JOIN books
            ON books.category_id
                = categories.id

         GROUP BY categories.id

         ORDER BY categories.id DESC"
    );
}


$categories =
    $categoryQuery->fetchAll();

?>
<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Kategori - Admin BookStore
    </title>

    <link
        rel="stylesheet"
        href="assets/admin.css"
    >

</head>


<body>


<div class="admin-layout">


    <!-- ==================================================
         SIDEBAR
    =================================================== -->

    <aside class="sidebar">


        <div class="admin-brand">

            <div class="brand-logo">
                📖
            </div>

            <div>

                <strong>
                    BookStore
                </strong>

                <span>
                    Admin Panel
                </span>

            </div>

        </div>


        <nav class="sidebar-menu">


            <span class="menu-label">
                MENU UTAMA
            </span>


            <a
                href="index.php"
                class="<?= $currentPage === 'index.php' ? 'active' : ''; ?>"
            >

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <rect
                            x="3"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="3"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                    </svg>

                </span>

                Dashboard

            </a>


            <a href="books.php" class="<?= $currentPage === 'books.php' ? 'active' : ''; ?>">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>

                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>

                    </svg>

                </span>

                Kelola Buku

            </a>


            <a
                href="categories.php"
                class="<?= $currentPage === 'categories.php' ? 'active' : ''; ?>"
            >
                <span class="menu-icon">
                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >
                        <rect x="3" y="3" width="7" height="7" rx="1"/>
                        <rect x="14" y="3" width="7" height="7" rx="1"/>
                        <rect x="3" y="14" width="7" height="7" rx="1"/>
                        <rect x="14" y="14" width="7" height="7" rx="1"/>
                    </svg>
                </span>
                Kategori
            </a>


            <a href="orders.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M6 2h12l2 5H4l2-5z"/>

                        <path d="M5 7v15h14V7"/>

                        <path d="M9 11h6"/>

                    </svg>

                </span>

                Pesanan

            </a>


            <a href="users.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <circle
                            cx="12"
                            cy="8"
                            r="4"
                        />

                        <path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>

                    </svg>

                </span>

                User

            </a>

            <a href="admin_revenue.php">
                <span class="menu-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
                    </svg>
                </span>
                Pendapatan
            </a>

<a href="messages.php" class="<?= $currentPage === 'messages.php' ? 'active' : ''; ?>">
                <span class="menu-icon">
                    ✉
                </span>
                Pesan User
            </a>

            <span class="menu-label second-label">
                WEBSITE
            </span>


            <a href="../index.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <circle
                            cx="12"
                            cy="12"
                            r="9"
                        />

                        <path d="M3 12h18"/>

                        <path d="M12 3c3 3 3 15 0 18"/>

                        <path d="M12 3c-3 3-3 15 0 18"/>

                    </svg>

                </span>

                Lihat Website

            </a>


            <a
                href="../logout.php"
                class="logout-menu"
            >

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M10 17l5-5-5-5"/>

                        <path d="M15 12H3"/>

                        <path d="M14 3h7v18h-7"/>

                    </svg>

                </span>

                Logout

            </a>


        </nav>

    </aside>


    <!-- ==================================================
         MAIN
    =================================================== -->

    <main class="admin-main">


        <!-- HEADER -->

        <header class="admin-header">


            <div>

                <p class="header-label">
                    ADMIN PANEL
                </p>

                <h1>
                    Kategori
                </h1>

            </div>


            <div class="admin-user">


                <div class="admin-avatar">

                    <?= strtoupper(
                        substr(
                            $_SESSION['user_name']
                                ?? 'A',
                            0,
                            1
                        )
                    ); ?>

                </div>


                <div class="admin-user-info">

                    <strong>
                        <?= htmlspecialchars(
                            $_SESSION['user_name']
                                ?? 'Admin'
                        ); ?>
                    </strong>

                    <span>
                        Administrator
                    </span>

                </div>


            </div>


        </header>


        <!-- FLASH -->

        <?php if ($flash): ?>

            <div
                class="admin-alert admin-alert-<?= htmlspecialchars(
                    $flash['type']
                ); ?>"
            >

                <?= htmlspecialchars(
                    $flash['message']
                ); ?>

            </div>

        <?php endif; ?>


        <!-- PAGE HEADING -->

        <section class="books-page-heading">


            <div>

                <h2>
                    Kelola Kategori
                </h2>

                <p>
                    Atur kategori buku yang tersedia
                    pada BookStore.
                </p>

            </div>


            <a
                href="categories.php?action=add#category-form"
                class="admin-primary-button"
            >
                + Tambah Kategori
            </a>


        </section>


        <!-- SEARCH -->

        <form
            action="categories.php"
            method="GET"
            class="admin-book-search"
        >


            <svg
                viewBox="0 0 24 24"
                width="18"
                height="18"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
            >

                <circle
                    cx="11"
                    cy="11"
                    r="7"
                ></circle>

                <path
                    d="M20 20L16.5 16.5"
                ></path>

            </svg>


            <input
                type="search"
                name="search"
                value="<?= htmlspecialchars(
                    $keyword
                ); ?>"
                placeholder="Cari kategori..."
            >


            <?php if ($keyword !== ''): ?>

                <a href="categories.php">
                    Reset
                </a>

            <?php endif; ?>


            <button type="submit">
                Cari
            </button>


        </form>


        <!-- CONTENT -->

        <div class="category-admin-layout">


            <!-- CATEGORY LIST -->

            <section class="admin-table-card">


                <div class="admin-table-heading">

                    <div>

                        <h3>
                            Semua Kategori
                        </h3>

                        <span>
                            <?= count($categories); ?>
                            kategori ditemukan
                        </span>

                    </div>

                </div>


                <div class="category-admin-grid">


                    <?php if (count($categories) > 0): ?>


                        <?php foreach (
                            $categories as $category
                        ): ?>


                            <article class="admin-category-card">


                                <div class="admin-category-image">

                                    <img
                                        src="<?= htmlspecialchars(
                                            categoryImageSrc(
                                                $category['image']
                                            )
                                        ); ?>"
                                        alt="<?= htmlspecialchars(
                                            $category['name']
                                        ); ?>"
                                        onerror="this.src='../assets/images/no-image.jpeg';"
                                    >

                                </div>


                                <div class="admin-category-info">


                                    <span class="category-small-label">
                                        KATEGORI
                                    </span>


                                    <h3>
                                        <?= htmlspecialchars(
                                            $category['name']
                                        ); ?>
                                    </h3>


                                    <p>

                                        <?= (int) $category['book_count']; ?>

                                        buku menggunakan kategori ini

                                    </p>


                                    <div class="category-card-actions">


                                        <a
                                            href="categories.php?edit=<?= (int) $category['id']; ?>#category-form"
                                            class="table-edit-button"
                                        >
                                            Edit
                                        </a>


                                        <form
                                            action="categories.php"
                                            method="POST"
                                            onsubmit="return confirm('Yakin ingin menghapus kategori ini?');"
                                        >

                                            <input
                                                type="hidden"
                                                name="csrf_token"
                                                value="<?= htmlspecialchars(
                                                    $_SESSION['csrf_token']
                                                ); ?>"
                                            >

                                            <input
                                                type="hidden"
                                                name="action"
                                                value="delete"
                                            >

                                            <input
                                                type="hidden"
                                                name="id"
                                                value="<?= (int) $category['id']; ?>"
                                            >


                                            <button
                                                type="submit"
                                                class="table-delete-button"
                                            >
                                                Hapus
                                            </button>


                                        </form>


                                    </div>


                                </div>


                            </article>


                        <?php endforeach; ?>


                    <?php else: ?>


                        <div class="category-empty">

                            <span>📚</span>

                            <h3>
                                Kategori tidak ditemukan
                            </h3>

                        </div>


                    <?php endif; ?>


                </div>


            </section>


            <!-- FORM -->

            <aside
                class="book-form-card"
                id="category-form"
            >


                <div class="book-form-heading">


                    <div>

                        <span>

                            <?= $editCategory
                                ? 'EDIT KATEGORI'
                                : 'KATEGORI BARU'; ?>

                        </span>


                        <h3>

                            <?= $editCategory
                                ? 'Edit Kategori'
                                : 'Tambah Kategori'; ?>

                        </h3>

                    </div>


                    <?php if ($editCategory): ?>

                        <a href="categories.php">
                            Batal
                        </a>

                    <?php endif; ?>


                </div>


                <form
                    action="categories.php"
                    method="POST"
                    enctype="multipart/form-data"
                    class="admin-book-form"
                >


                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= htmlspecialchars(
                            $_SESSION['csrf_token']
                        ); ?>"
                    >


                    <input
                        type="hidden"
                        name="action"
                        value="<?= $editCategory
                            ? 'update'
                            : 'add'; ?>"
                    >


                    <?php if ($editCategory): ?>

                        <input
                            type="hidden"
                            name="id"
                            value="<?= (int) $editCategory['id']; ?>"
                        >

                    <?php endif; ?>


                    <!-- NAMA -->

                    <div class="admin-form-group">

                        <label for="name">
                            Nama Kategori
                        </label>

                        <input
                            type="text"
                            id="name"
                            name="name"
                            value="<?= htmlspecialchars(
                                $editCategory['name']
                                    ?? ''
                            ); ?>"
                            placeholder="Contoh: Horror"
                            required
                        >

                    </div>


                    <!-- GAMBAR -->

                    <div class="admin-form-group">

                        <label for="image">
                            Gambar Kategori
                        </label>


                        <?php if (
                            $editCategory &&
                            !empty($editCategory['image'])
                        ): ?>

                            <div class="current-category-image">

                                <img
                                    src="<?= htmlspecialchars(
                                        categoryImageSrc(
                                            $editCategory['image']
                                        )
                                    ); ?>"
                                    alt="Gambar kategori"
                                >

                                <span>
                                    Gambar saat ini
                                </span>

                            </div>

                        <?php endif; ?>


                        <input
                            type="file"
                            id="image"
                            name="image"
                            accept=".jpg,.jpeg,.png,.webp"
                        >


                        <small>
                            JPG, PNG, atau WEBP.
                            Maksimal 3 MB.
                        </small>

                    </div>


                    <!-- SUBMIT -->

                    <button
                        type="submit"
                        class="admin-submit-book"
                    >

                        <?= $editCategory
                            ? 'Simpan Perubahan'
                            : '+ Tambah Kategori'; ?>

                    </button>


                </form>


            </aside>


        </div>


    </main>


</div>


</body>

</html>