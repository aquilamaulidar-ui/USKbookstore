<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';


/* =========================================================
   PROTEKSI ADMIN
========================================================= */

if (
    !isset($_SESSION['user_id']) ||
    !isset($_SESSION['user_role']) ||
    $_SESSION['user_role'] !== 'admin'
) {
    header('Location: ../index.php');
    exit;
}


/* =========================================================
   CSRF
========================================================= */

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}


/* =========================================================
   FLASH MESSAGE
========================================================= */

function setFlash($type, $message)
{
    $_SESSION['admin_flash'] = [
        'type' => $type,
        'message' => $message
    ];
}


$flash = $_SESSION['admin_flash'] ?? null;

unset($_SESSION['admin_flash']);


/* =========================================================
   COVER
========================================================= */

function getCoverSrc($cover)
{
    if (empty($cover)) {
        return '../assets/images/no-image.jpeg';
    }

    if (preg_match('/^https?:\/\//i', $cover)) {
        return $cover;
    }

    return '../' . ltrim($cover, '/');
}


$uploadDirectory =
    dirname(__DIR__) . '/assets/images/books';


if (!is_dir($uploadDirectory)) {
    mkdir($uploadDirectory, 0777, true);
}


/* =========================================================
   AMBIL KATEGORI
========================================================= */

$categoryQuery = $pdo->query(
    "SELECT id, name
     FROM categories
     ORDER BY name ASC"
);

$categories = $categoryQuery->fetchAll();


/* =========================================================
   TAMBAH / EDIT / HAPUS
========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $csrf = $_POST['csrf_token'] ?? '';

    if (
        empty($csrf) ||
        !hash_equals($_SESSION['csrf_token'], $csrf)
    ) {
        die('Permintaan tidak valid.');
    }


    $action = $_POST['action'] ?? '';


    /* =====================================================
       HAPUS
    ===================================================== */

    if ($action === 'delete') {

        $id = (int) ($_POST['id'] ?? 0);


        $find = $pdo->prepare(
            "SELECT cover
             FROM books
             WHERE id = ?"
        );

        $find->execute([$id]);

        $book = $find->fetch();


        if (!$book) {

            setFlash(
                'error',
                'Buku tidak ditemukan.'
            );

            header('Location: books.php');
            exit;
        }


        try {

            $delete = $pdo->prepare(
                "DELETE FROM books
                 WHERE id = ?"
            );

            $delete->execute([$id]);


            /*
             * Hapus cover hanya jika cover berada
             * di folder upload admin.
             */

            if (
                !empty($book['cover']) &&
                str_starts_with(
                    $book['cover'],
                    'assets/images/books/'
                )
            ) {

                $coverFile =
                    dirname(__DIR__)
                    . '/'
                    . $book['cover'];

                if (is_file($coverFile)) {
                    unlink($coverFile);
                }
            }


            setFlash(
                'success',
                'Buku berhasil dihapus.'
            );

        } catch (PDOException $e) {

            setFlash(
                'error',
                'Buku tidak dapat dihapus. Kemungkinan buku sudah digunakan pada data pesanan.'
            );
        }


        header('Location: books.php');
        exit;
    }


    /* =====================================================
       TAMBAH / UPDATE
    ===================================================== */

    if (
        $action === 'add' ||
        $action === 'update'
    ) {

        $id = (int) ($_POST['id'] ?? 0);

        $title =
            trim($_POST['title'] ?? '');

        $author =
            trim($_POST['author'] ?? '');

        $categoryId =
            (int) ($_POST['category_id'] ?? 0);

        $price =
            (float) ($_POST['price'] ?? 0);

        $stock =
            (int) ($_POST['stock'] ?? 0);

        $description =
            trim($_POST['description'] ?? '');


        /* VALIDASI */

        if ($title === '') {

            setFlash(
                'error',
                'Judul buku wajib diisi.'
            );

            header('Location: books.php');
            exit;
        }


        if ($author === '') {

            setFlash(
                'error',
                'Nama penulis wajib diisi.'
            );

            header('Location: books.php');
            exit;
        }


        if ($price < 0) {

            setFlash(
                'error',
                'Harga tidak boleh kurang dari 0.'
            );

            header('Location: books.php');
            exit;
        }


        if ($stock < 0) {

            setFlash(
                'error',
                'Stok tidak boleh kurang dari 0.'
            );

            header('Location: books.php');
            exit;
        }


        /*
         * Category boleh NULL
         */

        if ($categoryId <= 0) {
            $categoryId = null;
        }


        /* =================================================
           AMBIL COVER LAMA UNTUK UPDATE
        ================================================= */

        $oldCover = null;


        if ($action === 'update') {

            $findBook = $pdo->prepare(
                "SELECT cover
                 FROM books
                 WHERE id = ?"
            );

            $findBook->execute([$id]);

            $existingBook =
                $findBook->fetch();


            if (!$existingBook) {

                setFlash(
                    'error',
                    'Buku yang ingin diedit tidak ditemukan.'
                );

                header('Location: books.php');
                exit;
            }


            $oldCover =
                $existingBook['cover'];
        }


        $coverPath =
            $oldCover;


        /* =================================================
           UPLOAD COVER
        ================================================= */

        if (
            isset($_FILES['cover']) &&
            $_FILES['cover']['error']
                !== UPLOAD_ERR_NO_FILE
        ) {

            if (
                $_FILES['cover']['error']
                !== UPLOAD_ERR_OK
            ) {

                setFlash(
                    'error',
                    'Upload cover gagal.'
                );

                header('Location: books.php');
                exit;
            }


            if (
                $_FILES['cover']['size']
                > 3 * 1024 * 1024
            ) {

                setFlash(
                    'error',
                    'Ukuran cover maksimal 3 MB.'
                );

                header('Location: books.php');
                exit;
            }


            $finfo =
                new finfo(FILEINFO_MIME_TYPE);


            $mime =
                $finfo->file(
                    $_FILES['cover']['tmp_name']
                );


            $allowedTypes = [

                'image/jpeg' => 'jpg',
                'image/png'  => 'png',
                'image/webp' => 'webp'

            ];


            if (!isset($allowedTypes[$mime])) {

                setFlash(
                    'error',
                    'Cover hanya boleh JPG, PNG, atau WEBP.'
                );

                header('Location: books.php');
                exit;
            }


            $extension =
                $allowedTypes[$mime];


            $fileName =
                'book_'
                . bin2hex(random_bytes(8))
                . '.'
                . $extension;


            $destination =
                $uploadDirectory
                . '/'
                . $fileName;


            if (
                !move_uploaded_file(
                    $_FILES['cover']['tmp_name'],
                    $destination
                )
            ) {

                setFlash(
                    'error',
                    'Cover gagal disimpan.'
                );

                header('Location: books.php');
                exit;
            }


            $coverPath =
                'assets/images/books/'
                . $fileName;
        }


        /* =================================================
           INSERT
        ================================================= */

        if ($action === 'add') {

            $insert = $pdo->prepare(
                "INSERT INTO books
                (
                    category_id,
                    title,
                    author,
                    price,
                    stock,
                    cover,
                    description
                )
                VALUES
                (
                    :category_id,
                    :title,
                    :author,
                    :price,
                    :stock,
                    :cover,
                    :description
                )"
            );


            $insert->execute([

                'category_id'
                    => $categoryId,

                'title'
                    => $title,

                'author'
                    => $author,

                'price'
                    => $price,

                'stock'
                    => $stock,

                'cover'
                    => $coverPath,

                'description'
                    => $description

            ]);


            setFlash(
                'success',
                'Buku baru berhasil ditambahkan.'
            );


            header('Location: books.php');
            exit;
        }


        /* =================================================
           UPDATE
        ================================================= */

        if ($action === 'update') {

            $update = $pdo->prepare(
                "UPDATE books SET

                    category_id = :category_id,
                    title = :title,
                    author = :author,
                    price = :price,
                    stock = :stock,
                    cover = :cover,
                    description = :description

                 WHERE id = :id"
            );


            $update->execute([

                'category_id'
                    => $categoryId,

                'title'
                    => $title,

                'author'
                    => $author,

                'price'
                    => $price,

                'stock'
                    => $stock,

                'cover'
                    => $coverPath,

                'description'
                    => $description,

                'id'
                    => $id

            ]);


            /*
             * Jika upload cover baru,
             * hapus cover lama.
             */

            if (
                $coverPath !== $oldCover &&
                !empty($oldCover) &&
                str_starts_with(
                    $oldCover,
                    'assets/images/books/'
                )
            ) {

                $oldFile =
                    dirname(__DIR__)
                    . '/'
                    . $oldCover;


                if (is_file($oldFile)) {
                    unlink($oldFile);
                }
            }


            setFlash(
                'success',
                'Data buku berhasil diperbarui.'
            );


            header('Location: books.php');
            exit;
        }
    }
}


/* =========================================================
   EDIT DATA
========================================================= */

$editBook = null;


if (isset($_GET['edit'])) {

    $editId =
        (int) $_GET['edit'];


    $editQuery =
        $pdo->prepare(
            "SELECT *
             FROM books
             WHERE id = ?"
        );


    $editQuery->execute([$editId]);


    $editBook =
        $editQuery->fetch();
}


/* =========================================================
   SEARCH
========================================================= */

$keyword =
    trim($_GET['search'] ?? '');


if ($keyword !== '') {

    $booksQuery =
        $pdo->prepare(
            "SELECT

                books.*,
                categories.name AS category_name

             FROM books

             LEFT JOIN categories
                ON categories.id
                    = books.category_id

             WHERE
                books.title LIKE :keyword
                OR books.author LIKE :keyword
                OR categories.name LIKE :keyword

             ORDER BY books.id DESC"
        );


    $booksQuery->execute([
        'keyword'
            => '%' . $keyword . '%'
    ]);

} else {

    $booksQuery =
        $pdo->query(
            "SELECT

                books.*,
                categories.name AS category_name

             FROM books

             LEFT JOIN categories
                ON categories.id
                    = books.category_id

             ORDER BY books.id DESC"
        );
}


$books =
    $booksQuery->fetchAll();


$currentPage =
    basename($_SERVER['PHP_SELF']);

?>
<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Kelola Buku - Admin BookStore
    </title>

    <link
        rel="stylesheet"
        href="assets/admin.css"
    >

</head>


<body>


<div class="admin-layout">


    <!-- ==================================================
         SIDEBAR
    =================================================== -->

    <aside class="sidebar">


        <div class="admin-brand">

            <div class="brand-logo">
                📖
            </div>

            <div>

                <strong>
                    BookStore
                </strong>

                <span>
                    Admin Panel
                </span>

            </div>

        </div>


        <nav class="sidebar-menu">


            <span class="menu-label">
                MENU UTAMA
            </span>


            <a
                href="index.php"
                class="<?= $currentPage === 'index.php' ? 'active' : ''; ?>"
            >

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <rect
                            x="3"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="3"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                    </svg>

                </span>

                Dashboard

            </a>


            <a href="books.php" class="<?= $currentPage === 'books.php' ? 'active' : ''; ?>">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>

                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>

                    </svg>

                </span>

                Kelola Buku

            </a>


            <a href="categories.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <rect
                            x="3"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="3"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                    </svg>

                </span>

                Kategori

            </a>


            <a href="orders.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M6 2h12l2 5H4l2-5z"/>

                        <path d="M5 7v15h14V7"/>

                        <path d="M9 11h6"/>

                    </svg>

                </span>

                Pesanan

            </a>


            <a href="users.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <circle
                            cx="12"
                            cy="8"
                            r="4"
                        />

                        <path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>

                    </svg>

                </span>

                User

            </a>

            <a href="admin_revenue.php">
                <span class="menu-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
                    </svg>
                </span>
                Pendapatan
            </a>

<a href="messages.php" class="<?= $currentPage === 'messages.php' ? 'active' : ''; ?>">
                <span class="menu-icon">
                    ✉
                </span>
                Pesan User
            </a>

            <span class="menu-label second-label">
                WEBSITE
            </span>


            <a href="../index.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <circle
                            cx="12"
                            cy="12"
                            r="9"
                        />

                        <path d="M3 12h18"/>

                        <path d="M12 3c3 3 3 15 0 18"/>

                        <path d="M12 3c-3 3-3 15 0 18"/>

                    </svg>

                </span>

                Lihat Website

            </a>


            <a
                href="../logout.php"
                class="logout-menu"
            >

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M10 17l5-5-5-5"/>

                        <path d="M15 12H3"/>

                        <path d="M14 3h7v18h-7"/>

                    </svg>

                </span>

                Logout

            </a>


        </nav>

    </aside>


    <!-- ==================================================
         MAIN
    =================================================== -->

    <main class="admin-main">


        <!-- HEADER -->

        <header class="admin-header">


            <div>

                <p class="header-label">
                    ADMIN PANEL
                </p>

                <h1>
                    Kelola Buku
                </h1>

            </div>


            <div class="admin-user">


                <div class="admin-avatar">

                    <?= strtoupper(
                        substr(
                            $_SESSION['user_name']
                                ?? 'A',
                            0,
                            1
                        )
                    ); ?>

                </div>


                <div class="admin-user-info">

                    <strong>
                        <?= htmlspecialchars(
                            $_SESSION['user_name']
                                ?? 'Admin'
                        ); ?>
                    </strong>

                    <span>
                        Administrator
                    </span>

                </div>


            </div>


        </header>


        <!-- ==================================================
             FLASH
        =================================================== -->

        <?php if ($flash): ?>

            <div
                class="admin-alert admin-alert-<?= htmlspecialchars(
                    $flash['type']
                ); ?>"
            >

                <?= htmlspecialchars(
                    $flash['message']
                ); ?>

            </div>

        <?php endif; ?>


        <!-- ==================================================
             PAGE HEADING
        =================================================== -->

        <section class="books-page-heading">


            <div>

                <h2>
                    Daftar Buku
                </h2>

                <p>
                    Kelola seluruh buku yang tampil
                    pada BookStore.
                </p>

            </div>


            <a
                href="books.php?action=add#book-form"
                class="admin-primary-button"
            >
                + Tambah Buku
            </a>


        </section>


        <!-- ==================================================
             SEARCH
        =================================================== -->

        <form
            action="books.php"
            method="GET"
            class="admin-book-search"
        >

            <svg
                viewBox="0 0 24 24"
                width="18"
                height="18"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
            >

                <circle
                    cx="11"
                    cy="11"
                    r="7"
                ></circle>

                <path
                    d="M20 20L16.5 16.5"
                ></path>

            </svg>


            <input
                type="search"
                name="search"
                value="<?= htmlspecialchars(
                    $keyword
                ); ?>"
                placeholder="Cari judul, penulis, atau kategori..."
            >


            <?php if ($keyword !== ''): ?>

                <a href="books.php">
                    Reset
                </a>

            <?php endif; ?>


            <button type="submit">
                Cari
            </button>

        </form>


        <!-- ==================================================
             CONTENT
        =================================================== -->

        <div class="books-admin-layout">


            <!-- =============================================
                 TABLE
            ============================================== -->

            <section class="admin-table-card">


                <div class="admin-table-heading">

                    <div>

                        <h3>
                            Semua Buku
                        </h3>

                        <span>
                            <?= count($books); ?>
                            buku ditemukan
                        </span>

                    </div>

                </div>


                <div class="admin-table-wrapper">


                    <table class="admin-books-table">


                        <thead>

                            <tr>

                                <th>
                                    Buku
                                </th>

                                <th>
                                    Kategori
                                </th>

                                <th>
                                    Harga
                                </th>

                                <th>
                                    Stok
                                </th>

                                <th>
                                    Aksi
                                </th>

                            </tr>

                        </thead>


                        <tbody>


                        <?php if (count($books) > 0): ?>


                            <?php foreach ($books as $book): ?>


                                <tr>


                                    <!-- BUKU -->

                                    <td>

                                        <div class="table-book-info">


                                            <img
                                                src="<?= htmlspecialchars(
                                                    getCoverSrc(
                                                        $book['cover']
                                                    )
                                                ); ?>"
                                                alt="<?= htmlspecialchars(
                                                    $book['title']
                                                ); ?>"
                                                onerror="this.src='../assets/images/no-image.jpeg';"
                                            >


                                            <div>

                                                <strong>
                                                    <?= htmlspecialchars(
                                                        $book['title']
                                                    ); ?>
                                                </strong>

                                                <span>
                                                    <?= htmlspecialchars(
                                                        $book['author']
                                                    ); ?>
                                                </span>

                                            </div>


                                        </div>

                                    </td>


                                    <!-- CATEGORY -->

                                    <td>

                                        <span class="category-badge">

                                            <?= htmlspecialchars(
                                                $book['category_name']
                                                    ?? 'Tanpa kategori'
                                            ); ?>

                                        </span>

                                    </td>


                                    <!-- PRICE -->

                                    <td>

                                        <strong class="table-price">

                                            Rp <?= number_format(
                                                $book['price'],
                                                0,
                                                ',',
                                                '.'
                                            ); ?>

                                        </strong>

                                    </td>


                                    <!-- STOCK -->

                                    <td>

                                        <?php if (
                                            (int) $book['stock']
                                            > 0
                                        ): ?>

                                            <span class="stock-badge stock-ready">

                                                <?= (int) $book['stock']; ?>

                                            </span>

                                        <?php else: ?>

                                            <span class="stock-badge stock-empty">

                                                Habis

                                            </span>

                                        <?php endif; ?>

                                    </td>


                                    <!-- ACTION -->

                                    <td>

                                        <div class="table-actions">


                                            <a
                                                href="books.php?edit=<?= (int) $book['id']; ?>#book-form"
                                                class="table-edit-button"
                                            >
                                                Edit
                                            </a>


                                            <form
                                                action="books.php"
                                                method="POST"
                                                onsubmit="return confirm('Yakin ingin menghapus buku ini?');"
                                            >

                                                <input
                                                    type="hidden"
                                                    name="csrf_token"
                                                    value="<?= htmlspecialchars(
                                                        $_SESSION['csrf_token']
                                                    ); ?>"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="action"
                                                    value="delete"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="id"
                                                    value="<?= (int) $book['id']; ?>"
                                                >

                                                <button
                                                    type="submit"
                                                    class="table-delete-button"
                                                >
                                                    Hapus
                                                </button>

                                            </form>


                                        </div>

                                    </td>


                                </tr>


                            <?php endforeach; ?>


                        <?php else: ?>


                            <tr>

                                <td
                                    colspan="5"
                                    class="admin-table-empty"
                                >

                                    Buku tidak ditemukan.

                                </td>

                            </tr>


                        <?php endif; ?>


                        </tbody>


                    </table>


                </div>

            </section>


            <!-- =============================================
                 FORM ADD / EDIT
            ============================================== -->

            <aside
                class="book-form-card"
                id="book-form"
            >


                <div class="book-form-heading">


                    <div>

                        <span>
                            <?= $editBook
                                ? 'EDIT BUKU'
                                : 'BUKU BARU'; ?>
                        </span>

                        <h3>

                            <?= $editBook
                                ? 'Edit Buku'
                                : 'Tambah Buku'; ?>

                        </h3>

                    </div>


                    <?php if ($editBook): ?>

                        <a href="books.php">
                            Batal
                        </a>

                    <?php endif; ?>


                </div>


                <form
                    action="books.php"
                    method="POST"
                    enctype="multipart/form-data"
                    class="admin-book-form"
                >


                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= htmlspecialchars(
                            $_SESSION['csrf_token']
                        ); ?>"
                    >


                    <input
                        type="hidden"
                        name="action"
                        value="<?= $editBook
                            ? 'update'
                            : 'add'; ?>"
                    >


                    <?php if ($editBook): ?>

                        <input
                            type="hidden"
                            name="id"
                            value="<?= (int) $editBook['id']; ?>"
                        >

                    <?php endif; ?>


                    <!-- TITLE -->

                    <div class="admin-form-group">

                        <label for="title">
                            Judul Buku
                        </label>

                        <input
                            type="text"
                            id="title"
                            name="title"
                            value="<?= htmlspecialchars(
                                $editBook['title']
                                    ?? ''
                            ); ?>"
                            placeholder="Masukkan judul buku"
                            required
                        >

                    </div>


                    <!-- AUTHOR -->

                    <div class="admin-form-group">

                        <label for="author">
                            Penulis
                        </label>

                        <input
                            type="text"
                            id="author"
                            name="author"
                            value="<?= htmlspecialchars(
                                $editBook['author']
                                    ?? ''
                            ); ?>"
                            placeholder="Nama penulis"
                            required
                        >

                    </div>


                    <!-- CATEGORY -->

                    <div class="admin-form-group">

                        <label for="category_id">
                            Kategori
                        </label>

                        <select
                            id="category_id"
                            name="category_id"
                        >

                            <option value="">
                                Pilih kategori
                            </option>


                            <?php foreach (
                                $categories as $category
                            ): ?>

                                <option
                                    value="<?= (int) $category['id']; ?>"
                                    <?= (
                                        $editBook &&
                                        (int) $editBook['category_id']
                                            === (int) $category['id']
                                    )
                                        ? 'selected'
                                        : ''; ?>
                                >

                                    <?= htmlspecialchars(
                                        $category['name']
                                    ); ?>

                                </option>

                            <?php endforeach; ?>


                        </select>

                    </div>


                    <!-- PRICE + STOCK -->

                    <div class="admin-form-row">


                        <div class="admin-form-group">

                            <label for="price">
                                Harga
                            </label>

                            <input
                                type="number"
                                id="price"
                                name="price"
                                min="0"
                                step="1"
                                value="<?= htmlspecialchars(
                                    $editBook['price']
                                        ?? ''
                                ); ?>"
                                placeholder="0"
                                required
                            >

                        </div>


                        <div class="admin-form-group">

                            <label for="stock">
                                Stok
                            </label>

                            <input
                                type="number"
                                id="stock"
                                name="stock"
                                min="0"
                                value="<?= htmlspecialchars(
                                    $editBook['stock']
                                        ?? '0'
                                ); ?>"
                                required
                            >

                        </div>


                    </div>


                    <!-- DESCRIPTION -->

                    <div class="admin-form-group">

                        <label for="description">
                            Deskripsi
                        </label>

                        <textarea
                            id="description"
                            name="description"
                            rows="5"
                            placeholder="Deskripsi buku..."
                        ><?= htmlspecialchars(
                            $editBook['description']
                                ?? ''
                        ); ?></textarea>

                    </div>


                    <!-- COVER -->

                    <div class="admin-form-group">

                        <label for="cover">
                            Cover Buku
                        </label>


                        <?php if (
                            $editBook &&
                            !empty($editBook['cover'])
                        ): ?>

                            <div class="current-cover">

                                <img
                                    src="<?= htmlspecialchars(
                                        getCoverSrc(
                                            $editBook['cover']
                                        )
                                    ); ?>"
                                    alt="Cover buku"
                                >

                                <span>
                                    Cover saat ini
                                </span>

                            </div>

                        <?php endif; ?>


                        <input
                            type="file"
                            id="cover"
                            name="cover"
                            accept=".jpg,.jpeg,.png,.webp"
                        >

                        <small>
                            JPG, PNG, atau WEBP.
                            Maksimal 3 MB.
                        </small>

                    </div>


                    <!-- SUBMIT -->

                    <button
                        type="submit"
                        class="admin-submit-book"
                    >

                        <?= $editBook
                            ? 'Simpan Perubahan'
                            : '+ Tambah Buku'; ?>

                    </button>


                </form>


            </aside>


        </div>


    </main>


</div>


</body>

</html>