<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';

$currentPage = basename($_SERVER['PHP_SELF']);


/* =========================================================
   PROTEKSI ADMIN
========================================================= */

if (
    !isset($_SESSION['user_id']) ||
    !isset($_SESSION['user_role']) ||
    $_SESSION['user_role'] !== 'admin'
) {
    header('Location: ../index.php');
    exit;
}


/* =========================================================
   CSRF
========================================================= */

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}


/* =========================================================
   FLASH
========================================================= */

function userFlash($type, $message)
{
    $_SESSION['user_flash'] = [
        'type' => $type,
        'message' => $message
    ];
}


$flash = $_SESSION['user_flash'] ?? null;

unset($_SESSION['user_flash']);


/* =========================================================
   ROLE
========================================================= */

$allowedRoles = [
    'user',
    'admin'
];


/* =========================================================
   POST ACTION
========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $csrf = $_POST['csrf_token'] ?? '';

    if (
        empty($csrf) ||
        !hash_equals(
            $_SESSION['csrf_token'],
            $csrf
        )
    ) {
        die('Permintaan tidak valid.');
    }


    $action = $_POST['action'] ?? '';


    /* =====================================================
       UPDATE ROLE
    ===================================================== */

    if ($action === 'update_role') {

        $userId =
            (int) ($_POST['user_id'] ?? 0);

        $role =
            trim($_POST['role'] ?? '');


        if (
            $userId <= 0 ||
            !in_array(
                $role,
                $allowedRoles,
                true
            )
        ) {

            userFlash(
                'error',
                'Data role tidak valid.'
            );

            header('Location: users.php');
            exit;
        }


        /* Cari user */

        $findUser = $pdo->prepare(
            "SELECT
                id,
                name,
                email,
                role
             FROM users
             WHERE id = ?
             LIMIT 1"
        );

        $findUser->execute([
            $userId
        ]);

        $targetUser =
            $findUser->fetch();


        if (!$targetUser) {

            userFlash(
                'error',
                'User tidak ditemukan.'
            );

            header('Location: users.php');
            exit;
        }


        /*
         * Admin yang sedang login
         * tidak boleh menurunkan role dirinya sendiri.
         */

        if (
            $userId === (int) $_SESSION['user_id'] &&
            $role !== 'admin'
        ) {

            userFlash(
                'error',
                'Kamu tidak dapat mengubah akun admin milikmu sendiri menjadi user.'
            );

            header(
                'Location: users.php?view='
                . $userId
            );

            exit;
        }


        /*
         * Jangan sampai tidak ada admin sama sekali.
         */

        if (
            $targetUser['role'] === 'admin' &&
            $role === 'user'
        ) {

            $adminCount =
                (int) $pdo
                    ->query(
                        "SELECT COUNT(*)
                         FROM users
                         WHERE role = 'admin'"
                    )
                    ->fetchColumn();


            if ($adminCount <= 1) {

                userFlash(
                    'error',
                    'Admin terakhir tidak dapat diubah menjadi user.'
                );

                header(
                    'Location: users.php?view='
                    . $userId
                );

                exit;
            }
        }


        /* UPDATE */

        $update = $pdo->prepare(
            "UPDATE users
             SET role = ?
             WHERE id = ?"
        );

        $update->execute([
            $role,
            $userId
        ]);


        userFlash(
            'success',
            'Role user berhasil diperbarui.'
        );


        header(
            'Location: users.php?view='
            . $userId
        );

        exit;
    }


    /* =====================================================
       DELETE USER
    ===================================================== */

    if ($action === 'delete_user') {

        $userId =
            (int) ($_POST['user_id'] ?? 0);


        if ($userId <= 0) {

            userFlash(
                'error',
                'User tidak valid.'
            );

            header('Location: users.php');
            exit;
        }


        /*
         * Admin tidak boleh hapus akun sendiri.
         */

        if (
            $userId ===
            (int) $_SESSION['user_id']
        ) {

            userFlash(
                'error',
                'Kamu tidak dapat menghapus akunmu sendiri.'
            );

            header('Location: users.php');
            exit;
        }


        /* Cari user */

        $findUser = $pdo->prepare(
            "SELECT
                id,
                name,
                role
             FROM users
             WHERE id = ?
             LIMIT 1"
        );

        $findUser->execute([
            $userId
        ]);

        $targetUser =
            $findUser->fetch();


        if (!$targetUser) {

            userFlash(
                'error',
                'User tidak ditemukan.'
            );

            header('Location: users.php');
            exit;
        }


        /*
         * Kalau admin, pastikan bukan admin terakhir.
         */

        if ($targetUser['role'] === 'admin') {

            $adminCount =
                (int) $pdo
                    ->query(
                        "SELECT COUNT(*)
                         FROM users
                         WHERE role = 'admin'"
                    )
                    ->fetchColumn();


            if ($adminCount <= 1) {

                userFlash(
                    'error',
                    'Admin terakhir tidak dapat dihapus.'
                );

                header('Location: users.php');
                exit;
            }
        }


        /*
         * Jangan hapus user kalau sudah punya order,
         * supaya riwayat transaksi tetap aman.
         */

        $orderCountQuery =
            $pdo->prepare(
                "SELECT COUNT(*)
                 FROM orders
                 WHERE user_id = ?"
            );


        $orderCountQuery->execute([
            $userId
        ]);


        $orderCount =
            (int) $orderCountQuery
                ->fetchColumn();


        if ($orderCount > 0) {

            userFlash(
                'error',
                'User tidak dapat dihapus karena memiliki '
                . $orderCount
                . ' pesanan.'
            );

            header(
                'Location: users.php?view='
                . $userId
            );

            exit;
        }


        /*
         * Coba hapus.
         * Jika masih ada relasi dari tabel lain
         * seperti favorite/cart, database akan menolak.
         */

        try {

            $delete = $pdo->prepare(
                "DELETE FROM users
                 WHERE id = ?"
            );

            $delete->execute([
                $userId
            ]);


            userFlash(
                'success',
                'User berhasil dihapus.'
            );

        } catch (PDOException $e) {

            userFlash(
                'error',
                'User belum dapat dihapus karena masih memiliki data terkait.'
            );
        }


        header('Location: users.php');
        exit;
    }
}


/* =========================================================
   STATISTIK
========================================================= */

$totalUsers =
    (int) $pdo
        ->query(
            "SELECT COUNT(*)
             FROM users"
        )
        ->fetchColumn();


$totalAdmins =
    (int) $pdo
        ->query(
            "SELECT COUNT(*)
             FROM users
             WHERE role = 'admin'"
        )
        ->fetchColumn();


$totalCustomers =
    (int) $pdo
        ->query(
            "SELECT COUNT(*)
             FROM users
             WHERE role = 'user'"
        )
        ->fetchColumn();


$usersWithOrders =
    (int) $pdo
        ->query(
            "SELECT COUNT(DISTINCT user_id)
             FROM orders"
        )
        ->fetchColumn();


/* =========================================================
   SEARCH + FILTER
========================================================= */

$keyword =
    trim($_GET['search'] ?? '');


$roleFilter =
    trim($_GET['role'] ?? '');


$conditions = [];
$params = [];


/* SEARCH */

if ($keyword !== '') {

    $conditions[] = "
        (
            users.name LIKE :keyword
            OR users.email LIKE :keyword
        )
    ";

    $params['keyword'] =
        '%' . $keyword . '%';
}


/* ROLE FILTER */

if (
    $roleFilter !== '' &&
    in_array(
        $roleFilter,
        $allowedRoles,
        true
    )
) {

    $conditions[] =
        "users.role = :role";

    $params['role'] =
        $roleFilter;
}


/* =========================================================
   QUERY USERS
========================================================= */

$sql = "
    SELECT

        users.id,
        users.name,
        users.email,
        users.role,
        users.created_at,

        (
            SELECT COUNT(*)
            FROM orders
            WHERE orders.user_id = users.id
        ) AS order_count,

        (
            SELECT COALESCE(
                SUM(orders.total_amount),
                0
            )
            FROM orders
            WHERE orders.user_id = users.id
            AND orders.status != 'Dibatalkan'
        ) AS total_spent,

        (
            SELECT MAX(orders.created_at)
            FROM orders
            WHERE orders.user_id = users.id
        ) AS last_order

    FROM users
";


if (count($conditions) > 0) {

    $sql .= "
        WHERE "
        . implode(
            ' AND ',
            $conditions
        );
}


$sql .= "
    ORDER BY users.id DESC
";


$userQuery =
    $pdo->prepare($sql);


$userQuery->execute(
    $params
);


$users =
    $userQuery->fetchAll();


/* =========================================================
   DETAIL USER
========================================================= */

$selectedUser = null;
$recentOrders = [];


if (isset($_GET['view'])) {

    $viewId =
        (int) $_GET['view'];


    $detailQuery =
        $pdo->prepare(
            "SELECT

                users.id,
                users.name,
                users.email,
                users.role,
                users.created_at,

                (
                    SELECT COUNT(*)
                    FROM orders
                    WHERE orders.user_id = users.id
                ) AS order_count,

                (
                    SELECT COALESCE(
                        SUM(orders.total_amount),
                        0
                    )
                    FROM orders
                    WHERE orders.user_id = users.id
                    AND orders.status != 'Dibatalkan'
                ) AS total_spent,

                (
                    SELECT MAX(orders.created_at)
                    FROM orders
                    WHERE orders.user_id = users.id
                ) AS last_order

             FROM users

             WHERE users.id = ?

             LIMIT 1"
        );


    $detailQuery->execute([
        $viewId
    ]);


    $selectedUser =
        $detailQuery->fetch();


    if ($selectedUser) {

        $recentOrdersQuery =
            $pdo->prepare(
                "SELECT
                    id,
                    order_code,
                    total_amount,
                    status,
                    created_at
                 FROM orders
                 WHERE user_id = ?
                 ORDER BY id DESC
                 LIMIT 5"
            );


        $recentOrdersQuery->execute([
            $viewId
        ]);


        $recentOrders =
            $recentOrdersQuery
                ->fetchAll();
    }
}


/* =========================================================
   STATUS CLASS
========================================================= */

function adminUserRoleClass($role)
{
    return $role === 'admin'
        ? 'user-role-admin'
        : 'user-role-customer';
}


function userOrderStatusClass($status)
{
    return match ($status) {

        'Pembayaran Berhasil'
            => 'admin-status-paid',

        'Diproses'
            => 'admin-status-processing',

        'Selesai'
            => 'admin-status-completed',

        'Dibatalkan'
            => 'admin-status-cancelled',

        default
            => 'admin-status-default'
    };
}

?>
<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        User - Admin BookStore
    </title>

    <link
        rel="stylesheet"
        href="assets/admin.css"
    >

</head>


<body>


<div class="admin-layout">


    <!-- ==================================================
         SIDEBAR
    =================================================== -->

    <aside class="sidebar">


        <div class="admin-brand">

            <div class="brand-logo">
                📖
            </div>

            <div>

                <strong>
                    BookStore
                </strong>

                <span>
                    Admin Panel
                </span>

            </div>

        </div>


        <nav class="sidebar-menu">


            <span class="menu-label">
                MENU UTAMA
            </span>


            <a
                href="index.php"
                class="<?= $currentPage === 'index.php' ? 'active' : ''; ?>"
            >

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <rect
                            x="3"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="3"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                    </svg>

                </span>

                Dashboard

            </a>


            <a href="books.php" class="<?= $currentPage === 'books.php' ? 'active' : ''; ?>">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>

                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>

                    </svg>

                </span>

                Kelola Buku

            </a>


            <a href="categories.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <rect
                            x="3"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="3"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                    </svg>

                </span>

                Kategori

            </a>


            <a href="orders.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M6 2h12l2 5H4l2-5z"/>

                        <path d="M5 7v15h14V7"/>

                        <path d="M9 11h6"/>

                    </svg>

                </span>

                Pesanan

            </a>


            <a href="users.php" class="<?= $currentPage === 'users.php' ? 'active' : ''; ?>">
                <span class="menu-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="8" r="4"/>
                        <path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>
                    </svg>
                </span>
                User
            </a>

            <a href="admin_revenue.php">
                <span class="menu-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
                    </svg>
                </span>
                Pendapatan
            </a>

<a href="messages.php" class="<?= $currentPage === 'messages.php' ? 'active' : ''; ?>">
                <span class="menu-icon">
                    ✉
                </span>
                Pesan User
            </a>

            <span class="menu-label second-label">
                WEBSITE
            </span>


            <a href="../index.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <circle
                            cx="12"
                            cy="12"
                            r="9"
                        />

                        <path d="M3 12h18"/>

                        <path d="M12 3c3 3 3 15 0 18"/>

                        <path d="M12 3c-3 3-3 15 0 18"/>

                    </svg>

                </span>

                Lihat Website

            </a>


            <a
                href="../logout.php"
                class="logout-menu"
            >

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M10 17l5-5-5-5"/>

                        <path d="M15 12H3"/>

                        <path d="M14 3h7v18h-7"/>

                    </svg>

                </span>

                Logout

            </a>


        </nav>


    </aside>


    <!-- ==================================================
         MAIN
    =================================================== -->

    <main class="admin-main">


        <!-- HEADER -->

        <header class="admin-header">


            <div>

                <p class="header-label">
                    ADMIN PANEL
                </p>

                <h1>
                    User
                </h1>

            </div>


            <div class="admin-user">


                <div class="admin-avatar">

                    <?= strtoupper(
                        substr(
                            $_SESSION['user_name']
                                ?? 'A',
                            0,
                            1
                        )
                    ); ?>

                </div>


                <div class="admin-user-info">

                    <strong>

                        <?= htmlspecialchars(
                            $_SESSION['user_name']
                                ?? 'Admin'
                        ); ?>

                    </strong>

                    <span>
                        Administrator
                    </span>

                </div>


            </div>


        </header>


        <!-- FLASH -->

        <?php if ($flash): ?>

            <div
                class="admin-alert admin-alert-<?= htmlspecialchars(
                    $flash['type']
                ); ?>"
            >

                <?= htmlspecialchars(
                    $flash['message']
                ); ?>

            </div>

        <?php endif; ?>


        <!-- HEADING -->

        <section class="books-page-heading">


            <div>

                <h2>
                    Kelola Pengguna
                </h2>

                <p>
                    Lihat akun customer dan
                    atur hak akses administrator.
                </p>

            </div>


        </section>


        <!-- ==================================================
             STATISTICS
        =================================================== -->

        <section class="user-stat-grid">


            <article class="user-stat-card">

                <span>
                    Total Akun
                </span>

                <strong>
                    <?= $totalUsers; ?>
                </strong>

            </article>


            <article class="user-stat-card">

                <span>
                    Customer
                </span>

                <strong>
                    <?= $totalCustomers; ?>
                </strong>

            </article>


            <article class="user-stat-card">

                <span>
                    Administrator
                </span>

                <strong>
                    <?= $totalAdmins; ?>
                </strong>

            </article>


            <article class="user-stat-card">

                <span>
                    Pernah Belanja
                </span>

                <strong>
                    <?= $usersWithOrders; ?>
                </strong>

            </article>


        </section>


        <!-- ==================================================
             SEARCH
        =================================================== -->

        <form
            action="users.php"
            method="GET"
            class="admin-user-filter"
        >


            <div class="admin-user-search">


                <svg
                    viewBox="0 0 24 24"
                    width="18"
                    height="18"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                >

                    <circle
                        cx="11"
                        cy="11"
                        r="7"
                    ></circle>

                    <path
                        d="M20 20L16.5 16.5"
                    ></path>

                </svg>


                <input
                    type="search"
                    name="search"
                    value="<?= htmlspecialchars(
                        $keyword
                    ); ?>"
                    placeholder="Cari nama atau email..."
                >


            </div>


            <select name="role">

                <option value="">
                    Semua Role
                </option>

                <option
                    value="user"
                    <?= $roleFilter === 'user'
                        ? 'selected'
                        : ''; ?>
                >
                    User
                </option>

                <option
                    value="admin"
                    <?= $roleFilter === 'admin'
                        ? 'selected'
                        : ''; ?>
                >
                    Admin
                </option>

            </select>


            <button type="submit">
                Filter
            </button>


            <?php if (
                $keyword !== '' ||
                $roleFilter !== ''
            ): ?>

                <a href="users.php">
                    Reset
                </a>

            <?php endif; ?>


        </form>


        <!-- ==================================================
             LAYOUT
        =================================================== -->

        <div
            class="<?= $selectedUser
                ? 'users-admin-layout has-detail'
                : 'users-admin-layout'; ?>"
        >


            <!-- USER TABLE -->

            <section class="admin-table-card">


                <div class="admin-table-heading">


                    <div>

                        <h3>
                            Daftar Pengguna
                        </h3>

                        <span>

                            <?= count($users); ?>

                            akun ditemukan

                        </span>

                    </div>


                </div>


                <div class="admin-table-wrapper">


                    <table class="admin-users-table">


                        <thead>

                            <tr>

                                <th>
                                    User
                                </th>

                                <th>
                                    Role
                                </th>

                                <th>
                                    Pesanan
                                </th>

                                <th>
                                    Total Belanja
                                </th>

                                <th>
                                    Terdaftar
                                </th>

                                <th>
                                    Aksi
                                </th>

                            </tr>

                        </thead>


                        <tbody>


                        <?php if (
                            count($users) > 0
                        ): ?>


                            <?php foreach (
                                $users as $user
                            ): ?>


                                <tr
                                    class="<?= (
                                        $selectedUser &&
                                        (int) $selectedUser['id']
                                            === (int) $user['id']
                                    )
                                        ? 'selected-user-row'
                                        : ''; ?>"
                                >


                                    <!-- USER -->

                                    <td>

                                        <div class="user-table-profile">


                                            <div class="user-table-avatar">

                                                <?= strtoupper(
                                                    substr(
                                                        $user['name'],
                                                        0,
                                                        1
                                                    )
                                                ); ?>

                                            </div>


                                            <div>

                                                <strong>

                                                    <?= htmlspecialchars(
                                                        $user['name']
                                                    ); ?>

                                                </strong>

                                                <span>

                                                    <?= htmlspecialchars(
                                                        $user['email']
                                                    ); ?>

                                                </span>

                                            </div>


                                        </div>

                                    </td>


                                    <!-- ROLE -->

                                    <td>

                                        <span
                                            class="user-role-badge <?= adminUserRoleClass(
                                                $user['role']
                                            ); ?>"
                                        >

                                            <?= $user['role'] === 'admin'
                                                ? 'Admin'
                                                : 'User'; ?>

                                        </span>

                                    </td>


                                    <!-- ORDER -->

                                    <td>

                                        <strong class="user-order-count">

                                            <?= (int) $user['order_count']; ?>

                                        </strong>

                                    </td>


                                    <!-- SPENT -->

                                    <td>

                                        <strong class="user-total-spent">

                                            Rp <?= number_format(
                                                $user['total_spent'],
                                                0,
                                                ',',
                                                '.'
                                            ); ?>

                                        </strong>

                                    </td>


                                    <!-- DATE -->

                                    <td>

                                        <span class="user-register-date">

                                            <?= date(
                                                'd M Y',
                                                strtotime(
                                                    $user['created_at']
                                                )
                                            ); ?>

                                        </span>

                                    </td>


                                    <!-- DETAIL -->

                                    <td>

                                        <a
                                            href="users.php?view=<?= (int) $user['id']; ?>"
                                            class="user-detail-button"
                                        >
                                            Detail
                                        </a>

                                    </td>


                                </tr>


                            <?php endforeach; ?>


                        <?php else: ?>


                            <tr>

                                <td
                                    colspan="6"
                                    class="admin-table-empty"
                                >
                                    User tidak ditemukan.
                                </td>

                            </tr>


                        <?php endif; ?>


                        </tbody>


                    </table>


                </div>


            </section>


            <!-- =================================================
                 DETAIL USER
            ================================================== -->

            <?php if ($selectedUser): ?>


                <aside class="admin-user-detail">


                    <!-- HEADING -->

                    <div class="admin-user-detail-heading">


                        <div>

                            <span>
                                DETAIL USER
                            </span>

                            <h3>
                                Informasi Akun
                            </h3>

                        </div>


                        <a href="users.php">
                            ×
                        </a>


                    </div>


                    <!-- PROFILE -->

                    <div class="user-detail-profile">


                        <div class="user-detail-avatar">

                            <?= strtoupper(
                                substr(
                                    $selectedUser['name'],
                                    0,
                                    1
                                )
                            ); ?>

                        </div>


                        <div>

                            <h3>

                                <?= htmlspecialchars(
                                    $selectedUser['name']
                                ); ?>

                            </h3>

                            <p>

                                <?= htmlspecialchars(
                                    $selectedUser['email']
                                ); ?>

                            </p>

                            <span
                                class="user-role-badge <?= adminUserRoleClass(
                                    $selectedUser['role']
                                ); ?>"
                            >

                                <?= $selectedUser['role'] === 'admin'
                                    ? 'Administrator'
                                    : 'Customer'; ?>

                            </span>

                        </div>


                    </div>


                    <!-- STATS -->

                    <div class="user-detail-stats">


                        <div>

                            <span>
                                Pesanan
                            </span>

                            <strong>

                                <?= (int) $selectedUser['order_count']; ?>

                            </strong>

                        </div>


                        <div>

                            <span>
                                Total Belanja
                            </span>

                            <strong>

                                Rp <?= number_format(
                                    $selectedUser['total_spent'],
                                    0,
                                    ',',
                                    '.'
                                ); ?>

                            </strong>

                        </div>


                    </div>


                    <!-- INFO -->

                    <div class="user-detail-section">


                        <h4>
                            Informasi
                        </h4>


                        <div class="admin-order-info-row">

                            <span>
                                ID User
                            </span>

                            <strong>

                                #<?= (int) $selectedUser['id']; ?>

                            </strong>

                        </div>


                        <div class="admin-order-info-row">

                            <span>
                                Terdaftar
                            </span>

                            <strong>

                                <?= date(
                                    'd M Y H:i',
                                    strtotime(
                                        $selectedUser['created_at']
                                    )
                                ); ?>

                            </strong>

                        </div>


                        <div class="admin-order-info-row">

                            <span>
                                Pesanan Terakhir
                            </span>

                            <strong>

                                <?php if (
                                    $selectedUser['last_order']
                                ): ?>

                                    <?= date(
                                        'd M Y',
                                        strtotime(
                                            $selectedUser['last_order']
                                        )
                                    ); ?>

                                <?php else: ?>

                                    Belum ada

                                <?php endif; ?>

                            </strong>

                        </div>


                    </div>


                    <!-- ROLE -->

                    <div class="user-detail-section">


                        <h4>
                            Hak Akses
                        </h4>


                        <form
                            action="users.php"
                            method="POST"
                            class="user-role-form"
                        >


                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= htmlspecialchars(
                                    $_SESSION['csrf_token']
                                ); ?>"
                            >


                            <input
                                type="hidden"
                                name="action"
                                value="update_role"
                            >


                            <input
                                type="hidden"
                                name="user_id"
                                value="<?= (int) $selectedUser['id']; ?>"
                            >


                            <select name="role">

                                <option
                                    value="user"
                                    <?= $selectedUser['role'] === 'user'
                                        ? 'selected'
                                        : ''; ?>
                                >
                                    User
                                </option>

                                <option
                                    value="admin"
                                    <?= $selectedUser['role'] === 'admin'
                                        ? 'selected'
                                        : ''; ?>
                                >
                                    Administrator
                                </option>

                            </select>


                            <button type="submit">
                                Simpan Role
                            </button>


                        </form>


                    </div>


                    <!-- RECENT ORDERS -->

                    <div class="user-detail-section">


                        <h4>
                            Pesanan Terbaru
                        </h4>


                        <?php if (
                            count($recentOrders) > 0
                        ): ?>


                            <div class="user-recent-orders">


                                <?php foreach (
                                    $recentOrders as $order
                                ): ?>


                                    <a
                                        href="orders.php?view=<?= (int) $order['id']; ?>"
                                        class="user-recent-order"
                                    >


                                        <div>

                                            <strong>

                                                <?= htmlspecialchars(
                                                    $order['order_code']
                                                ); ?>

                                            </strong>

                                            <span>

                                                <?= date(
                                                    'd M Y',
                                                    strtotime(
                                                        $order['created_at']
                                                    )
                                                ); ?>

                                            </span>

                                        </div>


                                        <div>

                                            <span
                                                class="admin-order-status <?= userOrderStatusClass(
                                                    $order['status']
                                                ); ?>"
                                            >

                                                <?= htmlspecialchars(
                                                    $order['status']
                                                ); ?>

                                            </span>

                                            <strong>

                                                Rp <?= number_format(
                                                    $order['total_amount'],
                                                    0,
                                                    ',',
                                                    '.'
                                                ); ?>

                                            </strong>

                                        </div>


                                    </a>


                                <?php endforeach; ?>


                            </div>


                        <?php else: ?>


                            <div class="user-no-orders">

                                User ini belum pernah melakukan pesanan.

                            </div>


                        <?php endif; ?>


                    </div>


                    <!-- DELETE -->

                    <?php if (
                        (int) $selectedUser['id']
                        !== (int) $_SESSION['user_id']
                    ): ?>


                        <div class="user-danger-zone">


                            <h4>
                                Hapus Akun
                            </h4>

                            <p>
                                Akun hanya dapat dihapus jika
                                belum memiliki pesanan.
                            </p>


                            <form
                                action="users.php"
                                method="POST"
                                onsubmit="return confirm('Yakin ingin menghapus user ini? Tindakan ini tidak dapat dibatalkan.');"
                            >


                                <input
                                    type="hidden"
                                    name="csrf_token"
                                    value="<?= htmlspecialchars(
                                        $_SESSION['csrf_token']
                                    ); ?>"
                                >


                                <input
                                    type="hidden"
                                    name="action"
                                    value="delete_user"
                                >


                                <input
                                    type="hidden"
                                    name="user_id"
                                    value="<?= (int) $selectedUser['id']; ?>"
                                >


                                <button type="submit">
                                    Hapus User
                                </button>


                            </form>


                        </div>


                    <?php endif; ?>


                </aside>


            <?php endif; ?>


        </div>


    </main>


</div>


</body>

</html>