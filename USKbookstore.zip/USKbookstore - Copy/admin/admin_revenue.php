<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

$currentPage = basename($_SERVER['PHP_SELF']);

/* =========================================================
   PROTEKSI ADMIN
========================================================= */
if (
    !isset($_SESSION['user_id']) ||
    !isset($_SESSION['user_role']) ||
    $_SESSION['user_role'] !== 'admin'
) {
    header('Location: ../index.php');
    exit;
}

$filter = $_GET['filter'] ?? 'monthly';

// Query pendapatan berdasarkan filter waktu (Mingguan, Bulanan, Tahunan)
if ($filter === 'weekly') {
    $titleFilter = "Pendapatan 7 Hari Terakhir";
    $query = $pdo->query(
        "SELECT DATE(created_at) AS period, SUM(total_amount) AS total_revenue, COUNT(*) AS total_orders 
         FROM orders 
         GROUP BY DATE(created_at) 
         DESC"
    );
} elseif ($filter === 'yearly') {
    $titleFilter = "Pendapatan Per Tahun";
    $query = $pdo->query(
        "SELECT YEAR(created_at) AS period, SUM(total_amount) AS total_revenue, COUNT(*) AS total_orders 
         FROM orders 
         GROUP BY YEAR(created_at) 
         DESC"
    );
} else {
    $filter = 'monthly';
    $titleFilter = "Pendapatan Per Bulan";
    $query = $pdo->query(
        "SELECT DATE_FORMAT(created_at, '%Y-%m') AS period, SUM(total_amount) AS total_revenue, COUNT(*) AS total_orders 
         FROM orders 
         GROUP BY DATE_FORMAT(created_at, '%Y-%m') 
         DESC"
    );
}

$reports = $query->fetchAll();

$grandTotalRevenue = 0;
$grandTotalOrders = 0;
foreach ($reports as $row) {
    $grandTotalRevenue += (float)$row['total_revenue'];
    $grandTotalOrders += (int)$row['total_orders'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Pendapatan - Admin BookStore</title>
    <link rel="stylesheet" href="assets/admin.css">
    <style>
        /* CSS Khusus untuk merapikan saat dicetak / simpan ke PDF */
        @media print {
            .sidebar, .admin-header, .admin-order-filter, .no-print {
                display: none !important;
            }
            .admin-layout {
                display: block !important;
            }
            .admin-main {
                padding: 0 !important;
            }
            body {
                background: #ffffff !important;
                color: #000000 !important;
            }
            .admin-table-card, .order-stat-card {
                border: 1px solid #ccc !important;
                box-shadow: none !important;
                break-inside: avoid;
            }
            .print-header {
                display: block !important;
                margin-bottom: 20px;
                text-align: center;
            }
        }
        .print-header {
            display: none;
        }
    </style>
</head>
<body>

<div class="admin-layout">

    <!-- ==================================================
         SIDEBAR
    =================================================== -->
    <aside class="sidebar no-print">
        <div class="admin-brand">
            <div class="brand-logo">📖</div>
            <div>
                <strong>BookStore</strong>
                <span>Admin Panel</span>
            </div>
        </div>

        <nav class="sidebar-menu">


            <span class="menu-label">
                MENU UTAMA
            </span>


            <a
                href="index.php"
                class="<?= $currentPage === 'index.php' ? 'active' : ''; ?>"
            >

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <rect
                            x="3"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="3"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                    </svg>

                </span>

                Dashboard

            </a>


            <a href="books.php" class="<?= $currentPage === 'books.php' ? 'active' : ''; ?>">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>

                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>

                    </svg>

                </span>

                Kelola Buku

            </a>


            <a href="categories.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <rect
                            x="3"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="3"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                    </svg>

                </span>

                Kategori

            </a>


            <a href="orders.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M6 2h12l2 5H4l2-5z"/>

                        <path d="M5 7v15h14V7"/>

                        <path d="M9 11h6"/>

                    </svg>

                </span>

                Pesanan

            </a>


            <a href="users.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <circle
                            cx="12"
                            cy="8"
                            r="4"
                        />

                        <path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>

                    </svg>

                </span>

                User

            </a>

            <a href="admin_revenue.php" class="<?= $currentPage === 'admin_revenue.php' ? 'active' : ''; ?>">
                <span class="menu-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
                    </svg>
                </span>
                Pendapatan
            </a>

<a href="messages.php" class="<?= $currentPage === 'messages.php' ? 'active' : ''; ?>">
                <span class="menu-icon">
                    ✉
                </span>
                Pesan User
            </a>

            <span class="menu-label second-label">
                WEBSITE
            </span>


            <a href="../index.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <circle
                            cx="12"
                            cy="12"
                            r="9"
                        />

                        <path d="M3 12h18"/>

                        <path d="M12 3c3 3 3 15 0 18"/>

                        <path d="M12 3c-3 3-3 15 0 18"/>

                    </svg>

                </span>

                Lihat Website

            </a>


            <a
                href="../logout.php"
                class="logout-menu"
            >

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M10 17l5-5-5-5"/>

                        <path d="M15 12H3"/>

                        <path d="M14 3h7v18h-7"/>

                    </svg>

                </span>

                Logout

            </a>


        </nav>
    </aside>

    <!-- ==================================================
         MAIN
    =================================================== -->
    <main class="admin-main">

        <!-- HEADER -->
        <header class="admin-header">
            <div>
                <p class="header-label">ADMIN PANEL</p>
                <h1>Laporan Pendapatan</h1>
            </div>

            <div class="admin-user">
                <div class="admin-avatar">
                    <?= strtoupper(substr($_SESSION['user_name'] ?? 'A', 0, 1)); ?>
                </div>
                <div class="admin-user-info">
                    <strong><?= htmlspecialchars($_SESSION['user_name'] ?? 'Admin'); ?></strong>
                    <span>Administrator</span>
                </div>
            </div>
        </header>

        <!-- KOP LAPORAN KHUSUS CETAK PDF -->
        <div class="print-header">
            <h2>BOOKSTORE ADMIN PANEL</h2>
            <h3>Laporan Rekapitulasi Pendapatan (<?= $titleFilter; ?>)</h3>
            <p style="font-size: 11px; color: #555; margin-top: 5px;">Dicetak pada: <?= date('d-m-Y H:i:s'); ?> oleh Admin</p>
            <hr style="border: 0; border-top: 1px solid #000; margin-top: 10px;">
        </div>

        <!-- HEADING -->
        <section class="books-page-heading no-print">
            <div>
                <h2>Rekap Keuangan</h2>
                <p>Pantau laporan pendapatan toko buku secara mingguan, bulanan, dan tahunan.</p>
            </div>
            <!-- Tombol Cetak PDF -->
            <button onclick="window.print()" class="admin-primary-button" style="cursor: pointer; border: none; display: flex; align-items: center; gap: 6px;">
                🖨️ Cetak / Simpan PDF
            </button>
        </section>

        <!-- ==================================================
             TOMBOL FILTER WAKTU
        =================================================== -->
        <div class="admin-order-filter no-print" style="margin-bottom: 18px;">
            <a href="admin_revenue.php?filter=weekly" class="order-detail-admin-button" style="text-decoration: none; padding: 10px 18px; font-size: 11px; background: <?= $filter === 'weekly' ? '#817be0' : '#ffffff'; ?>; color: <?= $filter === 'weekly' ? '#ffffff' : '#756ed7'; ?>; border: 1px solid #dfdee6;">Mingguan</a>
            <a href="admin_revenue.php?filter=monthly" class="order-detail-admin-button" style="text-decoration: none; padding: 10px 18px; font-size: 11px; background: <?= $filter === 'monthly' ? '#817be0' : '#ffffff'; ?>; color: <?= $filter === 'monthly' ? '#ffffff' : '#756ed7'; ?>; border: 1px solid #dfdee6;">Bulanan</a>
            <a href="admin_revenue.php?filter=yearly" class="order-detail-admin-button" style="text-decoration: none; padding: 10px 18px; font-size: 11px; background: <?= $filter === 'yearly' ? '#817be0' : '#ffffff'; ?>; color: <?= $filter === 'yearly' ? '#ffffff' : '#756ed7'; ?>; border: 1px solid #dfdee6;">Tahunan</a>
        </div>

        <!-- ==================================================
             STATISTICS CARDS
        =================================================== -->
        <section class="order-stat-grid">
            <article class="order-stat-card">
                <span>Total Pendapatan (<?= $titleFilter; ?>)</span>
                <strong style="color: #2e7d32;">Rp <?= number_format($grandTotalRevenue, 0, ',', '.'); ?></strong>
            </article>
            <article class="order-stat-card">
                <span>Total Pesanan Sukses</span>
                <strong><?= number_format($grandTotalOrders, 0, ',', '.'); ?> Pesanan</strong>
            </article>
        </section>

        <!-- ==================================================
             TABEL RINCIAN LAPORAN
        =================================================== -->
        <section class="admin-table-card">
            <div class="admin-table-heading">
                <div>
                    <h3>Rincian <?= $titleFilter; ?></h3>
                    <span>Menampilkan rekapitulasi data keuangan toko berdasarkan database</span>
                </div>
            </div>

            <div class="admin-table-wrapper">
                <table class="admin-orders-table">
                    <thead>
                        <tr>
                            <th>Periode</th>
                            <th style="text-align: center;">Jumlah Pesanan</th>
                            <th style="text-align: right;">Total Pendapatan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($reports) > 0): ?>
                            <?php foreach ($reports as $row): ?>
                                <tr>
                                    <td><strong><?= htmlspecialchars($row['period']); ?></strong></td>
                                    <td style="text-align: center;"><?= number_format($row['total_orders'], 0, ',', '.'); ?> Pesanan</td>
                                    <td style="text-align: right;"><strong style="color: #2e7d32;">Rp <?= number_format($row['total_revenue'], 0, ',', '.'); ?></strong></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3" class="admin-table-empty">Belum ada data pendapatan untuk filter ini.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <!-- Tanda Tangan Khusus Cetak -->
        <div style="display: none;" class="print-header" style="margin-top: 40px; float: right; text-align: center; width: 200px;">
            <p>Administrator,</p>
            <br><br><br>
            <p><b><?= htmlspecialchars($_SESSION['user_name'] ?? 'Admin'); ?></b></p>
        </div>

    </main>
</div>

</body>
</html>