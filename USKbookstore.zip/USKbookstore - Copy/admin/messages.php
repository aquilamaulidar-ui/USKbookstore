<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';

$currentPage = basename($_SERVER['PHP_SELF']);

// Proteksi Admin
if (
    !isset($_SESSION['user_id']) ||
    !isset($_SESSION['user_role']) ||
    $_SESSION['user_role'] !== 'admin'
) {
    header('Location: ../index.php');
    exit;
}

// Proses Hapus Pesan
if (isset($_GET['delete_id'])) {
    $deleteId = (int) $_GET['delete_id'];
    $stmt = $pdo->prepare("DELETE FROM contact_messages WHERE id = ?");
    $stmt->execute([$deleteId]);
    header('Location: messages.php');
    exit;
}

// Ambil pesan dari database
$query = $pdo->query("SELECT * FROM contact_messages ORDER BY created_at DESC");
$messages = $query->fetchAll();

$pageTitle = 'Pesan User - Admin BookStore';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle; ?></title>
    <link rel="stylesheet" href="assets/admin.css">
</head>
<body>

<div class="admin-layout">

    <!-- SIDEBAR -->
    <aside class="sidebar" style="overflow-y: auto; max-height: 100vh;">
        <div class="admin-brand">
            <div class="brand-logo">📖</div>
            <div>
                <strong>BookStore</strong>
                <span>Admin Panel</span>
            </div>
        </div>

        <nav class="sidebar-menu">


            <span class="menu-label">
                MENU UTAMA
            </span>


            <a
                href="index.php"
                class="<?= $currentPage === 'index.php' ? 'active' : ''; ?>"
            >

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <rect
                            x="3"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="3"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                    </svg>

                </span>

                Dashboard

            </a>


            <a href="books.php" class="<?= $currentPage === 'books.php' ? 'active' : ''; ?>">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>

                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>

                    </svg>

                </span>

                Kelola Buku

            </a>


            <a href="categories.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <rect
                            x="3"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="3"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                    </svg>

                </span>

                Kategori

            </a>


            <a href="orders.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M6 2h12l2 5H4l2-5z"/>

                        <path d="M5 7v15h14V7"/>

                        <path d="M9 11h6"/>

                    </svg>

                </span>

                Pesanan

            </a>


            <a href="users.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <circle
                            cx="12"
                            cy="8"
                            r="4"
                        />

                        <path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>

                    </svg>

                </span>

                User

            </a>

            <a href="admin_revenue.php">
                <span class="menu-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
                    </svg>
                </span>
                Pendapatan
            </a>

<a href="messages.php" class="<?= $currentPage === 'messages.php' ? 'active' : ''; ?>">
                <span class="menu-icon">
                    ✉
                </span>
                Pesan User
            </a>

            <span class="menu-label second-label">
                WEBSITE
            </span>


            <a href="../index.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <circle
                            cx="12"
                            cy="12"
                            r="9"
                        />

                        <path d="M3 12h18"/>

                        <path d="M12 3c3 3 3 15 0 18"/>

                        <path d="M12 3c-3 3-3 15 0 18"/>

                    </svg>

                </span>

                Lihat Website

            </a>


            <a
                href="../logout.php"
                class="logout-menu"
            >

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M10 17l5-5-5-5"/>

                        <path d="M15 12H3"/>

                        <path d="M14 3h7v18h-7"/>

                    </svg>

                </span>

                Logout

            </a>


        </nav>
    </aside>

    <!-- MAIN -->
    <main class="admin-main">
        
        <header class="admin-header">
            <div>
                <p class="header-label">ADMIN PANEL</p>
                <h1>Pesan Masuk</h1>
            </div>
            <div class="admin-user">
                <div class="admin-avatar">
                    <?= strtoupper(substr($_SESSION['user_name'] ?? 'A', 0, 1)); ?>
                </div>
                <div class="admin-user-info">
                    <strong><?= htmlspecialchars($_SESSION['user_name'] ?? 'Admin'); ?></strong>
                    <span>Administrator</span>
                </div>
            </div>
        </header>

        <section class="books-page-heading">
            <div>
                <h2>Kelola Pesan User</h2>
                <p>Baca pesan dari user dan balas langsung via WhatsApp.</p>
            </div>
        </section>

        <div style="padding: 0 30px 40px 30px;">
            <?php if (count($messages) > 0): ?>
                <div style="display: flex; flex-direction: column; gap: 20px;">
                    <?php foreach ($messages as $msg): ?>
                        <?php 
                            // Membersihkan dan memformat nomor HP user agar sesuai dengan format wa.me (62...)
                            $rawPhone = $msg['phone'] ?? '';
                            $cleanPhone = preg_replace('/[^0-9]/', '', $rawPhone);
                            if (str_starts_with($cleanPhone, '0')) {
                                $cleanPhone = '62' . substr($cleanPhone, 1);
                            }
                            
                            $waMessage = urlencode("Halo " . $msg['name'] . ", kami dari Admin BookStore menanggapi pesan Anda: \"" . $msg['message'] . "\"\n\nBalasan:");
                        ?>
                        <div style="background: #fff; padding: 25px; border-radius: 12px; border: 1px solid #e1e1e5; box-shadow: 0 2px 4px rgba(0,0,0,0.02);">
                            
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; border-bottom: 1px solid #f1f1f5; padding-bottom: 12px;">
                                <div>
                                    <strong style="font-size: 16px; color: #111;"><?= htmlspecialchars($msg['name']); ?></strong>
                                    <span style="color: #666; font-size: 14px; margin-left: 8px;">(No. WA: <?= htmlspecialchars($rawPhone); ?>)</span>
                                </div>
                                <span style="color: #888; font-size: 13px;"><?= date('d M Y, H:i', strtotime($msg['created_at'])); ?></span>
                            </div>
                            
                            <p style="color: #444; line-height: 1.6; margin: 0 0 20px 0; white-space: pre-line;">
                                <?= htmlspecialchars($msg['message']); ?>
                            </p>

                            <!-- Tombol Aksi (WhatsApp & Hapus) -->
                            <div style="display: flex; gap: 10px; justify-content: flex-end; align-items: center;">
                                <a href="https://wa.me/<?= $cleanPhone; ?>?text=<?= $waMessage; ?>" 
                                   target="_blank"
                                   style="background: #25d366; color: #fff; padding: 8px 16px; border-radius: 6px; text-decoration: none; font-size: 13px; font-weight: bold; display: flex; align-items: center; gap: 6px;">
                                   💬 Balas via WhatsApp
                                </a>

                                <a href="messages.php?delete_id=<?= $msg['id']; ?>" 
                                   onclick="return confirm('Yakin ingin menghapus pesan ini?');" 
                                   style="background: #ff4d4d; color: #fff; padding: 8px 16px; border-radius: 6px; text-decoration: none; font-size: 13px; font-weight: bold;">
                                   🗑️ Hapus
                                </a>
                            </div>

                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div style="background: #fff; text-align: center; padding: 60px; border-radius: 12px; border: 1px solid #e1e1e5;">
                    <h3 style="color: #444; margin-bottom: 8px;">Belum ada pesan</h3>
                    <p style="color: #666; margin: 0;">Pesan dari pengguna akan muncul di sini.</p>
                </div>
            <?php endif; ?>
        </div>

    </main>

</div>

</body>
</html>