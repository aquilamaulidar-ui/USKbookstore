<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';


if (
    !isset($_SESSION['user_id']) ||
    !isset($_SESSION['user_role']) ||
    $_SESSION['user_role'] !== 'admin'
) {
    header('Location: ../index.php');
    exit;
}


/*
|--------------------------------------------------------------------------
| DATA DASHBOARD
|--------------------------------------------------------------------------
*/

$totalBooks = 0;
$totalCategories = 0;
$totalUsers = 0;
$totalOrders = 0;


/* TOTAL BUKU */

try {

    $query = $pdo->query("
        SELECT COUNT(*) AS total
        FROM books
    ");

    $result = $query->fetch();

    $totalBooks = (int) ($result['total'] ?? 0);

} catch (PDOException $e) {

    $totalBooks = 0;

}


/* TOTAL KATEGORI */

try {

    $query = $pdo->query("
        SELECT COUNT(*) AS total
        FROM categories
    ");

    $result = $query->fetch();

    $totalCategories = (int) ($result['total'] ?? 0);

} catch (PDOException $e) {

    $totalCategories = 0;

}


/* TOTAL USER */

try {

    $query = $pdo->query("
        SELECT COUNT(*) AS total
        FROM users
    ");

    $result = $query->fetch();

    $totalUsers = (int) ($result['total'] ?? 0);

} catch (PDOException $e) {

    $totalUsers = 0;

}


/* TOTAL PESANAN */

try {

    $query = $pdo->query("
        SELECT COUNT(*) AS total
        FROM orders
    ");

    $result = $query->fetch();

    $totalOrders = (int) ($result['total'] ?? 0);

} catch (PDOException $e) {

    $totalOrders = 0;

}


/*
|--------------------------------------------------------------------------
| BUKU TERBARU
|--------------------------------------------------------------------------
*/

$latestBooks = [];

try {

    $query = $pdo->query("
        SELECT
            books.id,
            books.title,
            books.author,
            books.price,
            books.stock,
            books.cover,
            categories.name AS category_name
        FROM books

        LEFT JOIN categories
            ON categories.id = books.category_id

        ORDER BY books.id DESC

        LIMIT 5
    ");

    $latestBooks = $query->fetchAll();

} catch (PDOException $e) {

    $latestBooks = [];

}


$currentPage = basename($_SERVER['PHP_SELF']);

?>
<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Admin Dashboard - BookStore</title>

    <link
        rel="stylesheet"
        href="assets/admin.css"
    >

</head>

<body>


<div class="admin-layout">


    <!-- ========================================
         SIDEBAR
    ========================================= -->

    <aside class="sidebar">


        <div class="admin-brand">

            <div class="brand-logo">
                📖
            </div>

            <div>

                <strong>
                    BookStore
                </strong>

                <span>
                    Admin Panel
                </span>

            </div>

        </div>


        <nav class="sidebar-menu">


            <span class="menu-label">
                MENU UTAMA
            </span>


            <a
                href="index.php"
                class="<?= $currentPage === 'index.php' ? 'active' : ''; ?>"
            >

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <rect
                            x="3"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="3"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                    </svg>

                </span>

                Dashboard

            </a>


            <a href="books.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>

                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>

                    </svg>

                </span>

                Kelola Buku

            </a>


            <a href="categories.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <rect
                            x="3"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="3"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                    </svg>

                </span>

                Kategori

            </a>


            <a href="orders.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M6 2h12l2 5H4l2-5z"/>

                        <path d="M5 7v15h14V7"/>

                        <path d="M9 11h6"/>

                    </svg>

                </span>

                Pesanan

            </a>


            <a href="users.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <circle
                            cx="12"
                            cy="8"
                            r="4"
                        />

                        <path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>

                    </svg>

                </span>

                User

            </a>

            <a href="admin_revenue.php">
                <span class="menu-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
                    </svg>
                </span>
                Pendapatan
            </a>

<a href="messages.php" class="<?= $currentPage === 'messages.php' ? 'active' : ''; ?>">
                <span class="menu-icon">
                    ✉
                </span>
                Pesan User
            </a>

            <span class="menu-label second-label">
                WEBSITE
            </span>


            <a href="../index.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <circle
                            cx="12"
                            cy="12"
                            r="9"
                        />

                        <path d="M3 12h18"/>

                        <path d="M12 3c3 3 3 15 0 18"/>

                        <path d="M12 3c-3 3-3 15 0 18"/>

                    </svg>

                </span>

                Lihat Website

            </a>


            <a
                href="../logout.php"
                class="logout-menu"
            >

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M10 17l5-5-5-5"/>

                        <path d="M15 12H3"/>

                        <path d="M14 3h7v18h-7"/>

                    </svg>

                </span>

                Logout

            </a>


        </nav>


    </aside>


    <!-- ========================================
         MAIN
    ========================================= -->

    <main class="admin-main">


        <!-- HEADER -->

        <header class="admin-header">


            <div>

                <p class="header-label">
                    ADMIN PANEL
                </p>

                <h1>
                    Dashboard
                </h1>

            </div>


            <div class="admin-user">


                <div class="admin-avatar">

                    <?= strtoupper(
                        substr(
                            $_SESSION['user_name'] ?? 'A',
                            0,
                            1
                        )
                    ); ?>

                </div>


                <div class="admin-user-info">

                    <strong>
                        <?= htmlspecialchars(
                            $_SESSION['user_name'] ?? 'Admin'
                        ); ?>
                    </strong>

                    <span>
                        Administrator
                    </span>

                </div>


            </div>


        </header>


        <!-- ========================================
             WELCOME
        ========================================= -->

        <section class="welcome-card">


            <div>

                <span class="welcome-label">
                    BOOKSTORE ADMIN
                </span>

                <h2>
                    Selamat datang,
                    <?= htmlspecialchars(
                        $_SESSION['user_name'] ?? 'Admin'
                    ); ?> 👋
                </h2>

                <p>
                    Kelola buku, kategori, pesanan,
                    dan pengguna BookStore melalui dashboard ini.
                </p>

            </div>


            <div class="welcome-decoration">

                <span>📚</span>

            </div>


        </section>


        <!-- ========================================
             STATISTICS
        ========================================= -->

        <section class="stat-grid">


            <!-- BUKU -->

            <article class="stat-card">


                <div class="stat-icon purple">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>

                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>

                    </svg>

                </div>


                <div>

                    <span class="stat-title">
                        Total Buku
                    </span>

                    <strong class="stat-number">
                        <?= number_format($totalBooks); ?>
                    </strong>

                    <a href="books.php">
                        Kelola buku →
                    </a>

                </div>


            </article>


            <!-- CATEGORY -->

            <article class="stat-card">


                <div class="stat-icon blue">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <rect
                            x="3"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="3"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                    </svg>

                </div>


                <div>

                    <span class="stat-title">
                        Kategori
                    </span>

                    <strong class="stat-number">
                        <?= number_format($totalCategories); ?>
                    </strong>

                    <a href="categories.php">
                        Kelola kategori →
                    </a>

                </div>


            </article>


            <!-- ORDER -->

            <article class="stat-card">


                <div class="stat-icon orange">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M6 2h12l2 5H4l2-5z"/>

                        <path d="M5 7v15h14V7"/>

                    </svg>

                </div>


                <div>

                    <span class="stat-title">
                        Pesanan
                    </span>

                    <strong class="stat-number">
                        <?= number_format($totalOrders); ?>
                    </strong>

                    <a href="orders.php">
                        Lihat pesanan →
                    </a>

                </div>


            </article>


            <!-- USERS -->

            <article class="stat-card">


                <div class="stat-icon green">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <circle
                            cx="12"
                            cy="8"
                            r="4"
                        />

                        <path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>

                    </svg>

                </div>


                <div>

                    <span class="stat-title">
                        Pengguna
                    </span>

                    <strong class="stat-number">
                        <?= number_format($totalUsers); ?>
                    </strong>

                    <a href="users.php">
                        Lihat pengguna →
                    </a>

                </div>


            </article>


        </section>


        <!-- ========================================
             CONTENT
        ========================================= -->

        <section class="dashboard-content">


            <!-- BUKU TERBARU -->

            <div class="dashboard-card latest-books">


                <div class="card-heading">


                    <div>

                        <h2>
                            Buku Terbaru
                        </h2>

                        <p>
                            Buku yang terakhir ditambahkan.
                        </p>

                    </div>


                    <a
                        href="books.php"
                        class="view-all"
                    >
                        Lihat Semua
                    </a>


                </div>


                <?php if (count($latestBooks) > 0): ?>


                    <div class="book-admin-list">


                        <?php foreach ($latestBooks as $book): ?>


                            <div class="admin-book-item">


                                <div class="admin-book-cover">

                                    <img
                                        src="../<?= htmlspecialchars($book['cover']); ?>"
                                        alt="<?= htmlspecialchars($book['title']); ?>"
                                        onerror="this.src='../assets/images/no-image.jpeg';"
                                    >

                                </div>


                                <div class="admin-book-info">

                                    <span>
                                        <?= htmlspecialchars(
                                            $book['category_name']
                                            ?? 'Tanpa Kategori'
                                        ); ?>
                                    </span>

                                    <h3>
                                        <?= htmlspecialchars(
                                            $book['title']
                                        ); ?>
                                    </h3>

                                    <p>
                                        <?= htmlspecialchars(
                                            $book['author']
                                        ); ?>
                                    </p>

                                </div>


                                <div class="admin-stock">

                                    <span>
                                        Stok
                                    </span>

                                    <strong>
                                        <?= (int) $book['stock']; ?>
                                    </strong>

                                </div>


                                <div class="admin-price">

                                    <span>
                                        Harga
                                    </span>

                                    <strong>
                                        Rp <?= number_format(
                                            $book['price'],
                                            0,
                                            ',',
                                            '.'
                                        ); ?>
                                    </strong>

                                </div>


                                <a
                                    href="books.php?edit=<?= (int) $book['id']; ?>"
                                    class="edit-book"
                                >
                                    Edit
                                </a>


                            </div>


                        <?php endforeach; ?>


                    </div>


                <?php else: ?>


                    <div class="empty-dashboard">

                        <span>
                            📚
                        </span>

                        <h3>
                            Belum ada buku
                        </h3>

                        <p>
                            Tambahkan buku pertama ke BookStore.
                        </p>

                    </div>


                <?php endif; ?>


            </div>


            <!-- QUICK ACTION -->

            <aside class="dashboard-card quick-actions">


                <div class="card-heading">

                    <div>

                        <h2>
                            Aksi Cepat
                        </h2>

                        <p>
                            Kelola toko lebih cepat.
                        </p>

                    </div>

                </div>


                <div class="quick-action-list">


                    <a href="books.php?action=add">

                        <div class="quick-icon">
                            +
                        </div>

                        <div>

                            <strong>
                                Tambah Buku
                            </strong>

                            <span>
                                Tambahkan buku baru
                            </span>

                        </div>

                        <b>›</b>

                    </a>


                    <a href="categories.php?action=add">

                        <div class="quick-icon">
                            #
                        </div>

                        <div>

                            <strong>
                                Tambah Kategori
                            </strong>

                            <span>
                                Buat kategori baru
                            </span>

                        </div>

                        <b>›</b>

                    </a>

                    <a href="admin_revenue.php">
    <div class="quick-icon">
        📊
    </div>
    <div>
        <strong>Laporan Pendapatan</strong>
        <span>Cek rekap keuangan toko</span>
    </div>
    <b>›</b>
</a>


                    <a href="orders.php">

                        <div class="quick-icon">
                            ✓
                        </div>

                        <div>

                            <strong>
                                Cek Pesanan
                            </strong>

                            <span>
                                Kelola status pesanan
                            </span>

                        </div>

                        <b>›</b>

                    </a>


                    <a href="../index.php">

                        <div class="quick-icon">
                            ↗
                        </div>

                        <div>

                            <strong>
                                Lihat Website
                            </strong>

                            <span>
                                Buka tampilan user
                            </span>

                        </div>

                        <b>›</b>

                    </a>


                </div>


            </aside>


        </section>


    </main>


</div>


</body>

</html>