<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $orderId = (int) ($_POST['order_id'] ?? 0);
    $action = trim($_POST['admin_return_action'] ?? '');

    if ($orderId > 0 && !empty($action)) {
        // Jika admin memilih Refund Selesai, ubah return_status DAN status utama pesanan jadi "Refund Selesai" secara otomatis
        if ($action === 'Refund Selesai (Dana Dikembalikan)') {
            $stmt = $pdo->prepare("UPDATE orders SET return_status = ?, status = 'Refund Selesai' WHERE id = ?");
            $stmt->execute([$action, $orderId]);
        } else {
            // Untuk aksi lain (seperti setujui kirim paket atau tolak)
            $stmt = $pdo->prepare("UPDATE orders SET return_status = ? WHERE id = ?");
            $stmt->execute([$action, $orderId]);
        }
    }

    header("Location: orders.php?view=" . $orderId);
    exit;
} else {
    header('Location: orders.php');
    exit;
}