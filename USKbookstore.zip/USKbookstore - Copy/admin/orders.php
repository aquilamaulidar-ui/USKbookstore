<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';

$currentPage = basename($_SERVER['PHP_SELF']);


/* =========================================================
   PROTEKSI ADMIN
========================================================= */

if (
    !isset($_SESSION['user_id']) ||
    !isset($_SESSION['user_role']) ||
    $_SESSION['user_role'] !== 'admin'
) {
    header('Location: ../index.php');
    exit;
}


/* =========================================================
   CSRF
========================================================= */

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}


/* =========================================================
   FLASH MESSAGE
========================================================= */

function orderFlash($type, $message)
{
    $_SESSION['order_flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

$flash = $_SESSION['order_flash'] ?? null;

unset($_SESSION['order_flash']);


/* =========================================================
   STATUS PESANAN
========================================================= */

$allowedStatuses = [
    'Menunggu Konfirmasi',
    'Pembayaran Berhasil',
    'Diproses',
    'Dikirim',
    'Selesai',
    'Dibatalkan',
    'Pengajuan Return',
    'Return Selesai'
];


function orderStatusClass($status)
{
    return match ($status) {

        'Menunggu Konfirmasi'
            => 'admin-status-pending',

        'Diproses'
            => 'admin-status-processing',

        'Dikirim'
            => 'admin-status-shipping',

        'Selesai'
            => 'admin-status-completed',

        'Dibatalkan'
            => 'admin-status-cancelled',

        default
            => 'admin-status-default'
    };
}


/* =========================================================
   UPDATE STATUS
========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $csrf =
        $_POST['csrf_token'] ?? '';


    if (
        empty($csrf) ||
        !hash_equals(
            $_SESSION['csrf_token'],
            $csrf
        )
    ) {
        die('Permintaan tidak valid.');
    }


    $action =
        $_POST['action'] ?? '';


    if ($action === 'update_status') {

        $orderId =
            (int) ($_POST['order_id'] ?? 0);

        $status =
            trim($_POST['status'] ?? '');


        if (
            $orderId <= 0 ||
            !in_array(
                $status,
                $allowedStatuses,
                true
            )
        ) {

            orderFlash(
                'error',
                'Status pesanan tidak valid.'
            );

            header('Location: orders.php');
            exit;
        }


        /* CEK ORDER */

        $findOrder =
            $pdo->prepare(
                "SELECT id
                 FROM orders
                 WHERE id = ?"
            );


        $findOrder->execute([
            $orderId
        ]);


        if (!$findOrder->fetch()) {

            orderFlash(
                'error',
                'Pesanan tidak ditemukan.'
            );

            header('Location: orders.php');
            exit;
        }


        /* UPDATE */

        $update =
            $pdo->prepare(
                "UPDATE orders
                 SET status = ?
                 WHERE id = ?"
            );


        $update->execute([
            $status,
            $orderId
        ]);


        orderFlash(
            'success',
            'Status pesanan berhasil diperbarui.'
        );


        header(
            'Location: orders.php?view='
            . $orderId
        );

        exit;
    }
}


/* =========================================================
   STATISTIK
========================================================= */

$totalOrders =
    (int) $pdo
        ->query(
            "SELECT COUNT(*)
             FROM orders"
        )
        ->fetchColumn();


$pendingOrders =
    (int) $pdo
        ->query(
            "SELECT COUNT(*)
             FROM orders
             WHERE status = 'Pembayaran Berhasil'"
        )
        ->fetchColumn();


$processingOrders =
    (int) $pdo
        ->query(
            "SELECT COUNT(*)
             FROM orders
             WHERE status = 'Diproses'"
        )
        ->fetchColumn();


$completedOrders =
    (int) $pdo
        ->query(
            "SELECT COUNT(*)
             FROM orders
             WHERE status = 'Selesai'"
        )
        ->fetchColumn();


/* =========================================================
   SEARCH + FILTER
========================================================= */

$keyword =
    trim($_GET['search'] ?? '');

$statusFilter =
    trim($_GET['status'] ?? '');


$conditions = [];
$params = [];


if ($keyword !== '') {

    $conditions[] = "
        (
            orders.order_code LIKE :keyword
            OR orders.customer_name LIKE :keyword
            OR orders.phone LIKE :keyword
            OR users.email LIKE :keyword
        )
    ";

    $params['keyword'] =
        '%' . $keyword . '%';
}


if (
    $statusFilter !== '' &&
    in_array(
        $statusFilter,
        $allowedStatuses,
        true
    )
) {

    $conditions[] =
        "orders.status = :status";

    $params['status'] =
        $statusFilter;
}


$sql = "
    SELECT

        orders.*,

        users.email AS user_email,

        (
            SELECT COUNT(*)
            FROM order_items
            WHERE order_items.order_id = orders.id
        ) AS item_count

    FROM orders

    LEFT JOIN users
        ON users.id = orders.user_id
";


if (count($conditions) > 0) {

    $sql .= "
        WHERE "
        . implode(
            ' AND ',
            $conditions
        );
}


$sql .= "
    ORDER BY orders.id DESC
";


$orderQuery =
    $pdo->prepare($sql);


$orderQuery->execute(
    $params
);


$orders =
    $orderQuery->fetchAll();


/* =========================================================
   DETAIL ORDER
========================================================= */

$selectedOrder = null;
$orderItems = [];


if (isset($_GET['view'])) {

    $viewId =
        (int) $_GET['view'];


    $detailQuery =
        $pdo->prepare(
            "SELECT

                orders.*,

                users.email AS user_email

             FROM orders

             LEFT JOIN users
                ON users.id = orders.user_id

             WHERE orders.id = ?

             LIMIT 1"
        );


    $detailQuery->execute([
        $viewId
    ]);


    $selectedOrder =
        $detailQuery->fetch();


    if ($selectedOrder) {

        $itemsQuery =
            $pdo->prepare(
                "SELECT

                    order_items.*,

                    books.cover AS book_cover

                 FROM order_items

                 LEFT JOIN books
                    ON books.id = order_items.book_id

                 WHERE order_items.order_id = ?

                 ORDER BY order_items.id ASC"
            );


        $itemsQuery->execute([
            $viewId
        ]);


        $orderItems =
            $itemsQuery->fetchAll();
    }
}

?>
<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Pesanan - Admin BookStore
    </title>

    <link
        rel="stylesheet"
        href="assets/admin.css"
    >

</head>


<body>


<div class="admin-layout">


    <!-- ==================================================
         SIDEBAR
    =================================================== -->

    <aside class="sidebar">


        <div class="admin-brand">

            <div class="brand-logo">
                📖
            </div>

            <div>

                <strong>
                    BookStore
                </strong>

                <span>
                    Admin Panel
                </span>

            </div>

        </div>


        <nav class="sidebar-menu">


            <span class="menu-label">
                MENU UTAMA
            </span>


            <a
                href="index.php"
                class="<?= $currentPage === 'index.php' ? 'active' : ''; ?>"
            >

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <rect
                            x="3"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="3"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                    </svg>

                </span>

                Dashboard

            </a>


            <a href="books.php" class="<?= $currentPage === 'books.php' ? 'active' : ''; ?>">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>

                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>

                    </svg>

                </span>

                Kelola Buku

            </a>


            <a href="categories.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <rect
                            x="3"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="3"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="3"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                        <rect
                            x="14"
                            y="14"
                            width="7"
                            height="7"
                            rx="1"
                        />

                    </svg>

                </span>

                Kategori

            </a>


            <a href="orders.php" class="<?= $currentPage === 'orders.php' ? 'active' : ''; ?>">
                <span class="menu-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M6 2h12l2 5H4l2-5z"/>
                        <path d="M5 7v15h14V7"/>
                        <path d="M9 11h6"/>
                    </svg>
                </span>
                Pesanan
            </a>


            <a href="users.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <circle
                            cx="12"
                            cy="8"
                            r="4"
                        />

                        <path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>

                    </svg>

                </span>

                User

            </a>

            <a href="admin_revenue.php">
                <span class="menu-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
                    </svg>
                </span>
                Pendapatan
            </a>

<a href="messages.php" class="<?= $currentPage === 'messages.php' ? 'active' : ''; ?>">
                <span class="menu-icon">
                    ✉
                </span>
                Pesan User
            </a>

            <span class="menu-label second-label">
                WEBSITE
            </span>


            <a href="../index.php">

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <circle
                            cx="12"
                            cy="12"
                            r="9"
                        />

                        <path d="M3 12h18"/>

                        <path d="M12 3c3 3 3 15 0 18"/>

                        <path d="M12 3c-3 3-3 15 0 18"/>

                    </svg>

                </span>

                Lihat Website

            </a>


            <a
                href="../logout.php"
                class="logout-menu"
            >

                <span class="menu-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <path d="M10 17l5-5-5-5"/>

                        <path d="M15 12H3"/>

                        <path d="M14 3h7v18h-7"/>

                    </svg>

                </span>

                Logout

            </a>


        </nav>


    </aside>


    <!-- ==================================================
         MAIN
    =================================================== -->

    <main class="admin-main">


        <!-- HEADER -->

        <header class="admin-header">


            <div>

                <p class="header-label">
                    ADMIN PANEL
                </p>

                <h1>
                    Pesanan
                </h1>

            </div>


            <div class="admin-user">


                <div class="admin-avatar">

                    <?= strtoupper(
                        substr(
                            $_SESSION['user_name']
                                ?? 'A',
                            0,
                            1
                        )
                    ); ?>

                </div>


                <div class="admin-user-info">

                    <strong>

                        <?= htmlspecialchars(
                            $_SESSION['user_name']
                                ?? 'Admin'
                        ); ?>

                    </strong>

                    <span>
                        Administrator
                    </span>

                </div>


            </div>


        </header>


        <!-- ==================================================
             FLASH
        =================================================== -->

        <?php if ($flash): ?>

            <div
                class="admin-alert admin-alert-<?= htmlspecialchars(
                    $flash['type']
                ); ?>"
            >

                <?= htmlspecialchars(
                    $flash['message']
                ); ?>

            </div>

        <?php endif; ?>


        <!-- ==================================================
             HEADING
        =================================================== -->

        <section class="books-page-heading">


            <div>

                <h2>
                    Kelola Pesanan
                </h2>

                <p>
                    Lihat pesanan customer dan
                    perbarui status pengiriman.
                </p>

            </div>


        </section>


        <!-- ==================================================
             STATISTICS
        =================================================== -->

        <section class="order-stat-grid">


            <article class="order-stat-card">

                <span>
                    Total Pesanan
                </span>

                <strong>
                    <?= $totalOrders; ?>
                </strong>

            </article>


            <article class="order-stat-card">

                <span>
                    Pembayaran Berhasil
                </span>

                <strong>
                    <?= $pendingOrders; ?>
                </strong>

            </article>


            <article class="order-stat-card">

                <span>
                    Sedang Diproses
                </span>

                <strong>
                    <?= $processingOrders; ?>
                </strong>

            </article>


            <article class="order-stat-card">

                <span>
                    Selesai
                </span>

                <strong>
                    <?= $completedOrders; ?>
                </strong>

            </article>


        </section>


        <!-- ==================================================
             SEARCH + FILTER
        =================================================== -->

        <form
            action="orders.php"
            method="GET"
            class="admin-order-filter"
        >


            <div class="admin-order-search">


                <svg
                    viewBox="0 0 24 24"
                    width="18"
                    height="18"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                >

                    <circle
                        cx="11"
                        cy="11"
                        r="7"
                    ></circle>

                    <path
                        d="M20 20L16.5 16.5"
                    ></path>

                </svg>


                <input
                    type="search"
                    name="search"
                    value="<?= htmlspecialchars(
                        $keyword
                    ); ?>"
                    placeholder="Cari kode order, nama, email, atau telepon..."
                >


            </div>


            <select name="status">

                <option value="">
                    Semua Status
                </option>


                <?php foreach (
                    $allowedStatuses as $status
                ): ?>

                    <option
                        value="<?= htmlspecialchars(
                            $status
                        ); ?>"
                        <?= $statusFilter === $status
                            ? 'selected'
                            : ''; ?>
                    >

                        <?= htmlspecialchars(
                            $status
                        ); ?>

                    </option>

                <?php endforeach; ?>


            </select>


            <button type="submit">
                Filter
            </button>


            <?php if (
                $keyword !== '' ||
                $statusFilter !== ''
            ): ?>

                <a href="orders.php">
                    Reset
                </a>

            <?php endif; ?>


        </form>


        <!-- ==================================================
             ORDER LAYOUT
        =================================================== -->

        <div
            class="<?= $selectedOrder
                ? 'orders-admin-layout has-detail'
                : 'orders-admin-layout'; ?>"
        >


            <!-- =============================================
                 ORDER LIST
            ============================================== -->

            <section class="admin-table-card">


                <div class="admin-table-heading">


                    <div>

                        <h3>
                            Semua Pesanan
                        </h3>

                        <span>

                            <?= count($orders); ?>
                            pesanan ditemukan

                        </span>

                    </div>


                </div>


                <div class="admin-table-wrapper">


                    <table class="admin-orders-table">


                        <thead>

                            <tr>

                                <th>
                                    Order
                                </th>

                                <th>
                                    Customer
                                </th>

                                <th>
                                    Total
                                </th>

                                <th>
                                    Status
                                </th>

                                <th>
                                    Tanggal
                                </th>

                                <th>
                                    Aksi
                                </th>

                            </tr>

                        </thead>


                        <tbody>


                        <?php if (
                            count($orders) > 0
                        ): ?>


                            <?php foreach (
                                $orders as $order
                            ): ?>


                                <tr
                                    class="<?= (
                                        $selectedOrder &&
                                        (int) $selectedOrder['id']
                                            === (int) $order['id']
                                    )
                                        ? 'selected-order-row'
                                        : ''; ?>"
                                >


                                    <!-- ORDER -->

                                    <td>

                                        <div class="order-code-cell">

                                            <strong>
                                                <?= htmlspecialchars(
                                                    $order['order_code']
                                                ); ?>
                                            </strong>

                                            <span>

                                                <?= (int) $order['item_count']; ?>

                                                item

                                            </span>

                                        </div>

                                    </td>


                                    <!-- CUSTOMER -->

                                    <td>

                                        <div class="order-customer-cell">

                                            <strong>

                                                <?= htmlspecialchars(
                                                    $order['customer_name']
                                                ); ?>

                                            </strong>

                                            <span>

                                                <?= htmlspecialchars(
                                                    $order['user_email']
                                                        ?? '-'
                                                ); ?>

                                            </span>

                                        </div>

                                    </td>


                                    <!-- TOTAL -->

                                    <td>

                                        <strong class="order-table-total">

                                            Rp <?= number_format(
                                                $order['total_amount'],
                                                0,
                                                ',',
                                                '.'
                                            ); ?>

                                        </strong>

                                    </td>


                                    <!-- STATUS -->

                                    <td>

                                        <span
                                            class="admin-order-status <?= orderStatusClass(
                                                $order['status']
                                            ); ?>"
                                        >

                                            <?= htmlspecialchars(
                                                $order['status']
                                            ); ?>

                                        </span>

                                    </td>


                                    <!-- DATE -->

                                    <td>

                                        <span class="order-table-date">

                                            <?= date(
                                                'd M Y',
                                                strtotime(
                                                    $order['created_at']
                                                )
                                            ); ?>

                                        </span>

                                    </td>


                                    <!-- ACTION -->

                                    <td>

                                        <a
                                            href="orders.php?view=<?= (int) $order['id']; ?>"
                                            class="order-detail-admin-button"
                                        >
                                            Detail
                                        </a>

                                    </td>


                                </tr>


                            <?php endforeach; ?>


                        <?php else: ?>


                            <tr>

                                <td
                                    colspan="6"
                                    class="admin-table-empty"
                                >

                                    Pesanan tidak ditemukan.

                                </td>

                            </tr>


                        <?php endif; ?>


                        </tbody>


                    </table>


                </div>


            </section>


            <!-- =============================================
                 DETAIL
            ============================================== -->

            <?php if ($selectedOrder): ?>


                <aside class="admin-order-detail">


                    <div class="admin-order-detail-heading">


                        <div>

                            <span>
                                DETAIL PESANAN
                            </span>

                            <h3>

                                <?= htmlspecialchars(
                                    $selectedOrder['order_code']
                                ); ?>

                            </h3>

                        </div>


                        <a href="orders.php">
                            ×
                        </a>


                    </div>


                    <!-- STATUS -->

                    <div class="admin-order-detail-status">

                        <span
                            class="admin-order-status <?= orderStatusClass(
                                $selectedOrder['status']
                            ); ?>"
                        >

                            <?= htmlspecialchars(
                                $selectedOrder['status']
                            ); ?>

                        </span>

                    </div>


                    <!-- CUSTOMER -->

                    <div class="order-detail-section">


                        <h4>
                            Customer
                        </h4>


                        <div class="admin-order-info-row">

                            <span>
                                Nama
                            </span>

                            <strong>

                                <?= htmlspecialchars(
                                    $selectedOrder['customer_name']
                                ); ?>

                            </strong>

                        </div>


                        <div class="admin-order-info-row">

                            <span>
                                Email
                            </span>

                            <strong>

                                <?= htmlspecialchars(
                                    $selectedOrder['user_email']
                                        ?? '-'
                                ); ?>

                            </strong>

                        </div>


                        <div class="admin-order-info-row">

                            <span>
                                Telepon
                            </span>

                            <strong>

                                <?= htmlspecialchars(
                                    $selectedOrder['phone']
                                ); ?>

                            </strong>

                        </div>


                    </div>


                    <!-- ADDRESS -->

                    <div class="order-detail-section">

                        <h4>
                            Alamat Pengiriman
                        </h4>

                        <p class="admin-order-address">

                            <?= nl2br(
                                htmlspecialchars(
                                    $selectedOrder['address']
                                )
                            ); ?>

                        </p>

                    </div>


                    <!-- PAYMENT -->

                    <div class="order-detail-section">


                        <h4>
                            Pembayaran
                        </h4>


                        <div class="admin-order-info-row">

                            <span>
                                Metode
                            </span>

                            <strong>

                                <?= htmlspecialchars(
                                    $selectedOrder['payment_method']
                                ); ?>

                            </strong>

                        </div>

                        <div class="admin-order-info-row">

    <span>
        Bukti Pembayaran
    </span>

    <strong>

        <?php if (!empty($selectedOrder['payment_proof'])): ?>

            <a 
                href="../uploads/payment/<?= htmlspecialchars($selectedOrder['payment_proof']); ?>"
                target="_blank"
            >
                Lihat Bukti Transfer
            </a>

        <?php else: ?>

            Tidak Ada

        <?php endif; ?>

    </strong>

</div>


                        <div class="admin-order-info-row">

                            <span>
                                Tanggal
                            </span>

                            <strong>

                                <?= date(
                                    'd M Y H:i',
                                    strtotime(
                                        $selectedOrder['created_at']
                                    )
                                ); ?>

                            </strong>

                        </div>


                    </div>


                    <!-- ITEMS -->

                    <div class="order-detail-section">


                        <h4>
                            Produk
                        </h4>


                        <div class="admin-order-products">


                            <?php foreach (
                                $orderItems as $item
                            ): ?>


                                <div class="admin-order-product">


                                    <div class="admin-order-product-cover">


                                        <?php if (
                                            !empty(
                                                $item['book_cover']
                                            )
                                        ): ?>

                                            <img
                                                src="../<?= htmlspecialchars(
                                                    ltrim(
                                                        $item['book_cover'],
                                                        '/'
                                                    )
                                                ); ?>"
                                                alt="<?= htmlspecialchars(
                                                    $item['book_title']
                                                ); ?>"
                                                onerror="this.src='../assets/images/no-image.jpeg';"
                                            >

                                        <?php else: ?>

                                            <img
                                                src="../assets/images/no-image.jpeg"
                                                alt="Cover tidak tersedia"
                                            >

                                        <?php endif; ?>


                                    </div>


                                    <div class="admin-order-product-info">


                                        <strong>

                                            <?= htmlspecialchars(
                                                $item['book_title']
                                            ); ?>

                                        </strong>


                                        <span>

                                            <?= (int) $item['quantity']; ?>

                                            × Rp <?= number_format(
                                                $item['price'],
                                                0,
                                                ',',
                                                '.'
                                            ); ?>

                                        </span>


                                    </div>


                                    <strong class="admin-order-product-subtotal">

                                        Rp <?= number_format(
                                            $item['subtotal'],
                                            0,
                                            ',',
                                            '.'
                                        ); ?>

                                    </strong>


                                </div>


                            <?php endforeach; ?>


                        </div>


                    </div>


                    <!-- TOTAL -->

                    <div class="admin-order-total">

                        <span>
                            Total Pesanan
                        </span>

                        <strong>

                            Rp <?= number_format(
                                $selectedOrder['total_amount'],
                                0,
                                ',',
                                '.'
                            ); ?>

                        </strong>

                    </div>


                    <!-- PANEL KELOLA RETURN / PENGEMBALIAN BARANG -->
                    <?php if (!empty($selectedOrder['return_status']) && $selectedOrder['return_status'] !== 'Tidak Ada'): ?>
                        <div class="order-detail-section" style="background: #fff8e1; border: 1px solid #ffe0b2; padding: 15px; border-radius: 8px; margin-top: 15px;">
                            <h4 style="color: #f57f17; margin-bottom: 8px;">Permintaan Return / Pengembalian</h4>
                            <p style="font-size: 13px; margin: 0 0 5px 0;"><strong>Status:</strong> <?= htmlspecialchars($selectedOrder['return_status']); ?></p>
                            <p style="font-size: 13px; margin: 0 0 5px 0;"><strong>Alasan:</strong> <?= htmlspecialchars($selectedOrder['return_reason'] ?? ''); ?></p>
                            
                            <?php if (!empty($selectedOrder['return_proof'])): ?>
                                <p style="font-size: 13px; margin: 0 0 5px 0;"><a href="../<?= htmlspecialchars($selectedOrder['return_proof']); ?>" target="_blank">Lihat Foto Bukti Kerusakan</a></p>
                            <?php endif; ?>

                            <?php if (!empty($selectedOrder['return_receipt'])): ?>
                                <p style="font-size: 13px; margin: 0 0 10px 0;"><strong>No. Resi Retur User:</strong> <?= htmlspecialchars($selectedOrder['return_receipt']); ?></p>
                            <?php endif; ?>

                            <form action="update_return_admin.php" method="POST" style="margin-top: 10px; display: flex; flex-direction: column; gap: 8px;">
                                <input type="hidden" name="order_id" value="<?= $selectedOrder['id']; ?>">
                                <select name="admin_return_action" required style="padding: 8px; border-radius: 5px; border: 1px solid #ccc; font-size: 13px;">
                                    <option value="">Pilih Aksi Return</option>
                                    <option value="Return Disetujui (Kirim Paket)">Setujui Return (Minta User Kirim Paket)</option>
                                    <option value="Refund Selesai (Dana Dikembalikan)">Paket Diterima & Selesai (Refund Uang)</option>
                                    <option value="Return Ditolak">Tolak Pengajuan Return</option>
                                </select>
                                <button type="submit" style="padding: 8px; background: #333; color: #fff; border: none; border-radius: 5px; font-weight: bold; cursor: pointer; font-size: 13px;">
                                    Proses Status Return
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>


                    <!-- UPDATE STATUS -->

                    <form
                        action="orders.php"
                        method="POST"
                        class="admin-status-form"
                        style="margin-top: 15px;"
                    >


                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= htmlspecialchars(
                                $_SESSION['csrf_token']
                            ); ?>"
                        >


                        <input
                            type="hidden"
                            name="action"
                            value="update_status"
                        >


                        <input
                            type="hidden"
                            name="order_id"
                            value="<?= (int) $selectedOrder['id']; ?>"
                        >


                        <label for="status">
                            Ubah Status Pesanan
                        </label>


                        <select
                            id="status"
                            name="status"
                        >


                            <?php foreach (
                                $allowedStatuses as $status
                            ): ?>

                                <option
                                    value="<?= htmlspecialchars(
                                        $status
                                    ); ?>"
                                    <?= $selectedOrder['status'] === $status
                                        ? 'selected'
                                        : ''; ?>
                                >

                                    <?= htmlspecialchars(
                                        $status
                                    ); ?>

                                </option>

                            <?php endforeach; ?>


                        </select>


                        <button type="submit">
                            Simpan Status
                        </button>


                    </form>


                </aside>


            <?php endif; ?>


        </div>


    </main>


</div>


</body>

</html>