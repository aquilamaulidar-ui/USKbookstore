<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = (int) $_SESSION['user_id'];
    $orderId = (int) ($_POST['order_id'] ?? 0);
    $receipt = trim($_POST['return_receipt'] ?? '');

    if ($orderId > 0 && !empty($receipt)) {
        $stmt = $pdo->prepare("UPDATE orders SET return_status = 'Menunggu Pengecekan Paket', return_receipt = ? WHERE id = ? AND user_id = ?");
        $stmt->execute([$receipt, $orderId, $userId]);
    }

    header("Location: order_detail.php?id=" . $orderId);
    exit;
} else {
    header('Location: orders.php');
    exit;
}