<?php
$pageTitle = 'About Us - BookStore';
require_once 'partials/header.php';
?>

<section class="container section">
    <div class="auth-section" style="min-height: auto; padding: 30px 0;">
        <div class="auth-card" style="width: min(700px, 100%);">
            <h1>About Us</h1>
            <p class="auth-description">Mengenal lebih dekat platform e-commerce bookstore digital pilihan terbaik Anda.</p>
            
            <div style="line-height: 1.8; color: #555;">
                <p style="margin-bottom: 15px;">
                    <strong>BookStore</strong> adalah platform toko buku online terpercaya yang menyediakan berbagai koleksi buku berkualitas dari berbagai kategori, mulai dari fiksi, motivasi, hingga buku menarik lainnya.
                </p>
                <p style="margin-bottom: 15px;">
                    Kami berkomitmen untuk memberikan pengalaman berbelanja buku yang mudah, cepat, dan aman bagi seluruh pencinta literasi di Indonesia dengan dukungan sistem transaksi modern dan pilihan pembayaran yang fleksibel.
                </p>
                <p>
                    Terima kasih telah memilih BookStore sebagai mitra membaca Anda. Temukan buku favoritmu dan mulailah membaca hari ini!
                </p>
            </div>
        </div>
    </div>
</section>

<?php require_once 'partials/footer.php'; ?>